#!/bin/bash

#VaryingVariables
	gctiLog='/opt/GCTI/logs/gctiboot_$(date '+%Y%m%d_%H%M%S').log'
	gctiArray=(DBServer ConfServer MS LCA)
	gctiIndex=0
	gctiStart='echo "$gctiArray[gctiIndex++]} eaten at $(date '+%X')" >> $gctiLog'

#FunFunFunction
        logGCTIboot()
        {
                echo "${gctiArray[$gctiIndex]} eaten at $(date '+%Y%m%d_%H%M%S')" >>"$gctiLog"
                (( ++gctiIndex ))
        }

#StartYourEngines
		
	cd /opt/GCTI/$gctiS/ || return
	./multiserver -host ctilabtrfw3 -port 2020 -app cfg_dbserver &
	
	[[ -d /opt/GCTI/$gctiS/ ]] && ( cd /opt/GCTI/$gctiS/; ./multiserver -host ctilabtrfw3 -port 2020 -app cfg_dbserver & ) or something?
	
startGCTI()
	{
		cd /opt/GCTI/"${gctiArray[$gctiIndex]}/run.sh"
			(( ++gctiIndex ))
	}