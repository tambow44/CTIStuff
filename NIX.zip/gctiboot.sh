#! /bin/bash
#
# gctiboot       bring up/down Genesys applications
#
# chkconfig: 2345 10 90
# description: Genesys Applications - start/stop ALL
#
### BEGIN INIT INFO
# Provides: $gctiboot
# Short-Description: Bring up/down Genesys applications
# Description: Bring up/down Genesys applications
### END INIT INFO

# Source function library.
. /etc/init.d/functions



# VARIABLES
LOGFILE='/opt/GCTI/logs/scripts/gctiboot_initd.log'
STARTSCRIPT=$(echo "init.d script start at $(date '+%X on %x') by $(whoami)" >> $LOGFILE)
STOPSCRIPT=$(echo "init.d script stop at $(date '+%X on %x') by $(whoami)" >> $LOGFILE)
DONE='echo "... Done!"'

case "$1" in

'start')
# run Genesys start script
	echo "Starting Genesys..."
	$STARTSCRIPT
	runuser -l genesys -c "/opt/GCTI/scripts/gctiservices start"
	$DONE
	;;

# kill all genesys apps
'stop')
	echo "Stopping Genesys..."
	$STOPSCRIPT
        runuser -l genesys -c "/opt/GCTI/scripts/gctiservices stop"
	$DONE
        ;;
*)
        echo "Usage: $0 { start | stop}"
        exit 1
        ;;
esac
exit 0
