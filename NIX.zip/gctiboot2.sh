        # STARTING DBSERVER
        echo "[$(date '+%X on %x')] Starting DBServer at: /opt/GCTI/dbserver/" >> $LOG
        if [ -e /var/lock/subsys/multiserver ]; then
                echo "[$(date '+%X on %x')] multiserver is already running." >> $LOG;
                return 1
        fi
        cd /opt/GCTI/dbserver/
        ./multiserver -host ctilabarfw1 -port 2020 -app cfg_dbserver &
        sleep 20

        # STARTING CONFSERVER
        echo "[$(date '+%X on %x')] Starting confserv at /opt/GCTI/confserv/" >> $LOG
        if [ -e /var/lock/subsys/confserv ]; then
                echo "[$(date '+%X on %x')] confserv is already running." >> $LOG;
                return 1
        fi
        cd /opt/GCTI/confserv/
        ./confserv &

        # STARTING MESSAGESERVER
        echo "[$(date '+%X on %x')] Starting MessageServer at: /opt/GCTI/msgserv/" >> $LOG
        if [ -e /var/locl/subsys/MessageServer ]; then
                echo "[$(date '+%X on %x')] MessageServer is already running." >> $LOG;
                return 1
        fi
        cd /opt/GCTI/msgserv/
        ./MessageServer -host ctilabarfw1 -port 2020 -app "msgserv" &

        # STARTING SCSERVER
        echo "[$(date '+%X on %x')] Starting SCServer at: /opt/GCTI/scs/" >> $LOG
        if [ -e /var/locl/subsys/scs ]; then
                echo "[$(date '+%X on %x')] scs is already running." >> $LOG;
                return 1
        fi
        cd /opt/GCTI/scs/
        ./scs -host ctilabarfw1 -port 2020 -app "scserver" &

        # STARTING LCA
        echo "[$(date '+%X on %x')] Starting LCA at: /opt/GCTI/lca/" >> $LOG
        if [ -e /var/locl/subsys/lca ]; then
                echo "[$(date '+%X on %x')] lca is already running." >> $LOG;
                return 1
        fi
        cd /opt/GCTI/lca/
        ./lca 4999 &
