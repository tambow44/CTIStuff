#!/bin/bash

#VaryingVariables
gArApp=(lca dbs cs ms scs snmp)
gIndex=0
gLog=/opt/GCTI/logs/fuck.log

touch $gLog

#FunFunFunction
        sCTI()
{
        echo "starting '/opt/GCTI/apps/${gArApp[gIndex]}/run.sh' @ $(date '+%X on %x')" >> $gLog
        cd /opt/GCTI/apps/"${gArApp[gIndex]}"/ || return
#        sudo -H -u genesys bash -c ./run.sh &
#		runuser -l genesys bash -c "./run.sh &"
		runuser -l genesys -c "./run.sh &"

        sleep 5
        (( gArApp[gIndex++] ))
}

	#	LCA START
		sCTI
	#	DBS START
		sCTI
	#	CS START
		sCTI
	#	MS START
		sCTI
	#	SCS START
		sCTI
	#	SNMP START
		sCTI

	echo "done @ $(date '+%X on %x')" >> $gLog
	
exit

