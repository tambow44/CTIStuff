#!/bin/sh
# Usage: kat [string1, string2, string3]

Usage="Usage: kat [string] (max 3 inputs)"
declare -a stringlist
if [ "$#" == "0" ] || [ "$#" -gt "3" ]; then
        echo "$Usage"
        exit 1
fi

while (( "$#" )); do
        stringlist=(${stringlist[@]} $1)
        shift
done

echo "======================================================="
echo -e "\t showing host file results for: ${stringlist[@]}"
echo "======================================================="
echo

if [ ${#stringlist[@]} -eq 1 ]; then
        output="$(cat /etc/hosts | grep -i --color ${stringlist[0]})"
        echo "$output"
elif [ ${#stringlist[@]} -eq 2 ]; then
        output="$(cat /etc/hosts | grep -i ${stringlist[0]} | grep -i ${stringli                                                                                                                      st[1]})"

        echo "$output"
else
        output="$(cat /etc/hosts | grep -i ${stringlist[0]} | grep -i ${stringli                                                                                                                      st[1]} | grep -i ${stringlist[2]})"
        echo "$output"
fi

if [ -z "$output" ]; then
        echo -e "\t 0 results found"
fi

echo
