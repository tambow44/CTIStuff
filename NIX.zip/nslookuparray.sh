#!/bin/bash

# 8 servers in total
# 1. append prlsip0 with 1-8 (e.g. prilsip01, prilsip02 ... prilsip08)
# 3. run nslookup on each of the 8

# append prlsip0 with 1-8 (e.g. prilsip01, prilsip02 ... prilsip08)
countStart="1"
countEnd="8"
hostVar="prlsip0"

function FunAwk () {
awk 'BEGIN { 
		($1 == "Name:" { print $2 }) 
	&& 
		($2 == Address" { print $2 })
	} '

	};

while [ $countStart -lt $[$countEnd+1] ]; do
        nslookup "$hostVar$countStart"
        i=$CountStart
        countStart=$[$countStart+1]
        done
