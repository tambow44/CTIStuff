#!/bin/bash

arrHosts=(irkdcsip01 irkdcsip02 irkdcsip03 irdcasip01 irdcasip02 irdcasip03 irkdcors01 irkdcors02 irdcaors01 irdcaors02 irdcartg01 irkdcrtg01)

count=0
while [ "x${arrHosts[count]}" != "x" ]
	do
		count=$(( count + 1 ))
	done
	
rsync -Pav -e '~/scripts/autoarchive.sh ~/scripts/autoarchive.conf genesys@irdcaors02:~/scripts/'

rsync ... rsync://[genesys@]$arrHosts/home/genesys/scripts/

# WAIT, There's no rsync setup :(

 