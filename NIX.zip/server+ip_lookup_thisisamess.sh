#!/bin/bash
##################################################################
# 	Script to output server + ip from a list of servers
#	Output is tab deliminated and looks like this:
#		server1	10.1.1.1
#		server2	10.1.1.2
#	Credit to Thomas Blakely (Thomas.Blakely@vodafone.com), 2018
# 	Credit also to the Internet
##################################################################

ips=$1 #user passes arguments

#should none exist, prompt for one
if [ "$#" -eq 0 ]; then
        echo "Enter the file name for lookup (i.e. /tmp/filename.csv)"
        read ips
fi

#count lines in file
varConformComma=$(sed 's/,/ /g' < $ips)
varIPS=$varConformComma

echo "inserting $ips into lookup array"

index=0
while read line ; do
	var_Array_Servers[$index]="$line"
	index=$(($index+1))
done < $varIPS


for i in ${var_Array_Servers[*]}; do
		ping -nqc 1 $i | grep PING | awk '{print $2,"\t"$3}' | sed 's/[()]//g'
	done