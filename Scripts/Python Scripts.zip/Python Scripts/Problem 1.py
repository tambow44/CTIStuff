s = 'aqwerEsdfklghfjkdhiigsdhgaawgdhWert1'
numVowels = 0
for char in s:
    if char in 'aeiou':
        numVowels += 1
print('Number of vowels: ' + str(numVowels))
