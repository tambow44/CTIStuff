# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 19:02:20 2016

@author: tblakel
"""
"""
Write a program that prints the number of times the string 'bob' occurs in s. 
For example, if s = 'azcbobobegghakl', then your program should print:

	Number of times bob occurs is: 2

"""
s = str('aqwerEsdfklbobghfbobjkdhiigsdhgaawgdhWert1') # twice
numBobs = 0
for word in s:
    if char is 'b':
        numBobs += 1
print('Number of times bob occurs is: ' + str(numBobs))

s = 'obaboobobobobobobobobooobooekosbobb' # eight
numBobs = 0
for index in range(0,len(s)):
    if s[index:index+3] == 'bob':    
        numBobs += 1
print('Number of times bob occurs is: ' + str(numBobs))


obaboobobobobobobobobooobooekosbobb