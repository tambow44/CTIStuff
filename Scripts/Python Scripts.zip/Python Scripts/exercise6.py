# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 17:30:19 2016

@author: tblakel
"""

myStr = '6.00x'
for char in myStr:
    print(char)
print('done')

###

greeting = 'Hello!'
count = 0

for letter in greeting:
    count += 1
    if count % 2 == 0:
        print(letter)
    print(letter)

print('done')
    
###

school = 'Massachusetts Institute of Technology'
numVowels = 0
numCons = 0

for char in school:
    if char == 'a' or char == 'e' or char == 'i' \
       or char == 'o' or char == 'u':
        numVowels += 1
    elif char == 'o' or char == 'M':
        print(char)
    else:
        numCons -= 1

print('numVowels is: ' + str(numVowels))
print('numCons is: ' + str(numCons)) 

school = 'Massachusetts Institute of Technology'
numVowels = 0
numCons = 0

for char in school:
    print("\nTop of loop. char = '{}', numVowels = {}, numCons = {}".format(char, numVowels, numCons))
    if char == 'a' or char == 'e' or char == 'i' \
       or char == 'o' or char == 'u':
        print("inside if-statement")
        numVowels += 1
    elif char == 'o' or char == 'M':
        print("inside elif-statement")
        print(char)
    else:
        print("inside else-statement")
        numCons -= 1
    print("bottom of loop. numVowels = {} and numCons = {}".format(numVowels, numCons))
print('numVowels is: ' + str(numVowels))
print('numCons is: ' + str(numCons)) 