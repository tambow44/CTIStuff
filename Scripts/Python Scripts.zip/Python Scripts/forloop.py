# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 16:14:20 2016

@author: tblakel
"""

"""
1. Convert the following code into code that uses a for loop.

prints 2
prints 4
prints 6
prints 8
prints 10
prints "Goodbye!"
"""
x=0
for x in range(2,11,2):
    print(x)
print("Goodbye!")

for count in range(11):
    if count != 0 and count % 2 == 0:
        print(count)
print("Goodbye!")

for count in range(2,11,2):
    print(count)    
print("Goodbye!")

"""
2. Convert the following code into code that uses a for loop.

prints "Hello!"
prints 10
prints 8
prints 6
prints 4
prints 2
"""

print("Hello!")
for count in range(10,0,-2):
    print(count)

"""
3. Write a for loop that sums the values 1 through end, inclusive. 
end is a variable that we define for you. 
So, for example, if we define end to be 6, your code should print out the result:
    21
which is 1 + 2 + 3 + 4 + 5 + 6.

For problems such as these, do not include input statements 
or define variables we will provide for you. 

"""

end=10
x = 0
y = 1
for count in range(y,end,1):
    x += y
    y += 1
x += end
print(x)

# Here is one of a few ways to solve this problem:
# end=10
x = 0
for next in range(1, end+1):
    x += next
print(x)

# Here is another:
# end=10
x = end
for next in range(end):
    x += next
print(x)


