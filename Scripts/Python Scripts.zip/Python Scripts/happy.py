# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 21:32:13 2016

@author: tblakel
"""

"""
Write a piece of Python code that prints out the string 'hello world' 
if the value of an 'integer variable', happy, is *strictly greater* than 2.

"""

Var1 = 'hello world'
Var2 = 'happy'

if len(Var2) > 2:
    print(Var1)

...

if len('happy') > 2:
    print('hello world')
    

...
happy = len(happy)
if happy > 2:
    print('hello world')