# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 16:46:40 2016

@author: tblakel
"""

x = int(input('enter a number: '))
ans = 0
itersLeft = x
while (itersLeft != 0):
	ans = ans + x
	itersLeft = itersLeft - 1
print(str(x) + '*' + str(x) + ' = ' + str(ans))