# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 17:03:41 2016

@author: tblakel
"""
# question 1
num = 10
for num in range(5):
    print(num)
print(num)

# question 2
divisor = 2
for num in range(0, 10, 2):
    print(num/divisor)

# question 3
for variable in range(20):
    if variable % 4 == 0:
        print(variable)
    if variable % 16 == 0:
        print('Foo!')
        
# question 4
for letter in 'hola':
    print(letter)

# question 5    
count = 0
for letter in 'Snow!':
    print('Letter # ' + str(count) + ' is ' + str(letter))
    count += 1
    break
print(count)

x = 0
x = 10
x +=1
print(x)