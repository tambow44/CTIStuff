# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 14:31:45 2016

@author: tblakel
"""

"""
Assume that two variables, varA and varB, are assigned values, either numbers or strings.

Write a piece of Python code that prints out one of the following messages:

- "string involved" if either varA or varB are strings
- "bigger" if varA is larger than varB
- "equal" if varA is equal to varB
- "smaller" if varA is smaller than varB
"""

if str(VarA, VarB):
    print("string involved")
    if VarA > VarB:
        print("bigger")
    elif VarA < VarB 
        print ("smaller")
    elif VarA == VarB:
        pring ("equal")
        
if type(varA) == str or type(varB) == str:
    print('string involved')
elif varA > varB:
    print('bigger')
elif varA == varB:
    print('equal')
else:
    # If none of the above conditions are true,
    # it must be the case that varA < varB
    print('smaller')
    
"""
Is type(varA) == str or type(varB) == str equivalent to type(varA) or type(varB) == str ? Those are not equivalent because of Python precedence (some operations have higher precedence than others). The == has higher precedence than the or so it will get evaluated first. Therefore:
type(varA) or type(varB) == str
Will evaluate to the following, if we explicitly put parentheses:
type(varA) or ( type(varB) == str )
True or ( type(varB) == str )
( True )
Because "anything" or "True" will just take the value of "True" (by boolean algebra).
And the other expression:
type(varA) == str or type(varB) == str
Will evaluate to the following, if we explicitly put parentheses:
( type(varA) == str ) or ( type(varB) == str )
So you will have to check each of the expressions in the parentheses to see whether they are true or not to determine the final result. So these two are not equal.
"""