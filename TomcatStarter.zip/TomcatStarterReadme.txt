Setup Tomcat 7/8 on Linux to monitored by SCI/SCS
 

Background: Due a limitation that Command Lines configured in GA/CME can be no longer than 256 characters, the ability to monitor third party applications is limited. This becomes a problem with many Third Party applications that use java and have a large number of command line arguments such as Cassandra and Tomcat (WFM, GRE, etc.).
 
Approach: The development team has written a CassandraStarter application for the purpose of allowing Cassandra to be controlled and monitored by GA/LCA to get around the above limitation. This CassandraStarter application can be re-purposed and reconfigured to start, stop, and monitor Tomcat. 
 
Disclaimer: Has only been tested on Tomcat 8.5.6 and Tomcat 7.0.69 and Java 1.8 on RHEL 6 but may work on other versions. 
 

File TomcatStarter.zip 
Contents:
TomcatStarter.ini - configuration file for TomcatStarter application
TomcatStarter - binary starter application (renamed version of latest CassandraStarter
tomcatstarter-restart - sample script that can be used as basis for scripts to restart Tomcat on server reboot (/etc/init.d/)
tomcat_control.sh - sample script to start tomcat via GA/GAX 
start_tomcat_grat.sh - another sample script to start tomcat that demonstrates setting environment variables.
TomcatStarterReadme.doc - word document for instructions
TomcatStarterReadme.txt - plain text version of instructions

 
Scenario 1 - Control Tomcat with Starter application 

1. Update TomcatStarter.ini file (TomcatStarter.zip):
[Service] section - Update AppTitle to match GA, update JVMPath if needed
 
[JavaArgs]section - add any additional arguments that need to be passed to java 
Note: To determine this value, Tomcat can be started via the regular startup.sh and using ps -ef  you can get the full list of arguments needed.
 
[Djava.class.path] section - verify the list of libs matches the libraries used by your particular tomcat distribution. 
 

2. Deploy Files 
TomcatStarter.ini - copy the apache-tomcat-x.x.x/bin/ directory on the Linux server.
TomcatStarter - copy the apache-tomcat-x.x.x/bin/ directory on the Linux server.
 

3. Create/Configure Application in GA: 
Create a Third Party Server application object in GA. Ensure the following configuration items under the Server Info section are correct:
 
Working Directory: This is the full path to the bin directory for Tomcat.
Example: /home/tomcat/apache-tomcat-8.5.6/bin
 
Command Line: The name of the TomcatStarter binary.
Example: ./TomcatStarter
 
Command Line Arguments: This is the host for config server, the port for config server, the name of the application in GA for Tomcat and the start command.
Note: Command Line and this line have to match what LCA sees in Linux for the command line associated with the Tomcat process.
 
Example: -host vmrbep -port 2020-app Tomcat8 start
 
Troubleshooting tip: run ps -ef | grep Tomcat in Linux to see this matches the above Command Line Argument.
Example output (Command Line + Command Line Arguments):
root      4498  2156  0 14:42 ?        00:00:09 ./TomcatStarter -host vmrbep -port 2020-app Tomcat8 start
 
4. Finished - use GA/SCI to start, monitor, stop Tomcat. 
 
 

Scenario 2 - Start Tomcat and Set Environment Variables
Note: In some situations there is a need to setup environment variables before starting Tomcat. For example the LD_LOAD_LIBRARY variable needs to be setup when using the APR module with Tomcat or some Genesys applications that run inside of Tomcat require certain environment variables. 
 
Follow Steps 1-3 above in the Scenario 1 procedure.
 
4. Create a startup script with environment variables
See the file called "tomcat_control.sh" or "start_tomcat_grat.sh" inside the TomcatStarter.zip for an example script.
 
5. In GA setup start_stop section with start/stop commands in the "Annex"
In GA under the "Options" tab choose "Advanced View (Annex)" from the drop-down in the upper right corner of the screen.
 
Create new start Option:
Location: Annex
Section: start_stop
Value (example): /home/tomcat/apache-tomcat-7.0.69/bin/tomcat_control.sh start
 

Create new stop Option:
Same as above but with the follwing value
Value (example): /home/tomcat/apache-tomcat-7.0.69/bin/tomcat_control.sh stop
 
Note: Since LCA tracks the PID of the application the second option to stop may not be required.
 
6. Finished - use GA/SCI to start, monitor, stop Tomcat. 
 

Additional Notes
•	This approach bypasses the startup.sh, catalina.sh, and setenv.sh if it exists. So if there are configurations such as environment variables that get created by these script then these will need to be set up manually (likely in the /etc/profile file). Scenario 2 above describes how to handle this.
•	If Tomcat is setup to restart on server reboot then init.d script needs to start Tomcat with the TomcatStarter to ensure command line matching works properly with SCS/LCA. (See tomcatstarter-restart sample script in TomcatStarter.zip file).
•	The TomcatStarter.ini file contains the java parameters so future changes to Tomcat parameters must be made in this .ini file. This includes setting up Java memory, GC settings etc.
•	Ensure there are no spaces at the of each line in the .ini file. This starter program is finicky when it comes to extra spaces in the .ini file.
•	The TomcatStarter binary file can be renamed to suit your situation but the .ini file name must match binary name (+ .ini).

