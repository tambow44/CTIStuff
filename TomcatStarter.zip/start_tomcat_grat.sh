LD_LIBRARY_PATH=/usr/local/apr/lib:/Application/apache-tomcat-7.0.69/lib
JAVA_HOME=/Application/jdk1.8.0_91
CATALINA_BASE=/Application/apache-tomcat-7.0.69
CATALINA_HOME=/Application/apache-tomcat-7.0.69
CATALINA_TMPDIR=/Application/apache-tomcat-7.0.69/temp
JRE_HOME=/Application/jdk1.8.0_91/jre
CLASSPATH=/Application/apache-tomcat-7.0.69/bin/bootstrap.jar:/Application/apache-tomcat-7.0.69/bin/tomcat-juli.jar

export LD_LIBRARY_PATH
export JAVA_HOME    
export CATALINA_BASE
export CATALINA_HOME  
export CATALINA_TMPDIR
export JRE_HOME     
export CLASSPATH

cd /Application/apache-tomcat-7.0.69/bin
exec ./TomcatStarter -host ConfigServer -port 2020 -app GRE_TOMCAT start
