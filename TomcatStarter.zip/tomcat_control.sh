#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/apr/lib

APP_PATH=/home/tomcat/apache-tomcat-7.0.69/bin 
APP_NAME=TomcatStarter

case "$1" in
	start)
		cd $APP_PATH
		exec "./$APP_NAME" -host vmrbep -port 8888 -app Tomcat8 start 
		;;
	stop)
		var=`ps -aef | grep $APP_NAME | grep -v sh| grep -v grep| awk '{print $2}'`
		if [ -z "$var" ]
		then
  		  echo $APP_NAME process is not running 
		else
		  kill -9 $var
		fi
		;;
		
	*)
		echo "Usage: "$1" {start|stop}"
		exit 1
	
esac

exit 0	
