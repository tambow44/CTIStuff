Myzamir (Interaction server log file analyzer)

Pre-requirements
----------------

You must have .NET Framework 3.5 installed on your box. And you have to copy both exe file and the dll to run the application.

Application start
-----------------

Just start it as any other windows application. You can use log files names (with paths) as parameters to open them on start stage.

Some tips 
---------

1. Use Help to understand the interface

2. If you use Textpad as external log file viewer be sure to uncheck Textpad option 

[General]/'Allow multiply instances to run'

to avoid opening of extra Textpad windows.

3. The internal log file viewer component has a built-in keys-map help. Press Ctrl-H to show it. 

4. Graph. I do not advise to check all diagrams at once - there is a chance you get an overloaded picture which is difficult for understanding. Zoom option if very helpful to see details on critical graph parts. First of all - check delays with Ixn clients requests. If you see some - check DB requests, time of wait in cache. If it is ok - most probably delays come from external service providers - use thresholds to locate the problematic events.

5. Thresholds. I don't recommend to use a few thresholds at once - otherwise you can see some marked items in Ixn ID list, but from first view you can't see which of thresholds triggered for an interaction. To 'disable' one of thresholds - just assign it some unreal big value.

6. There is a hardcoded filter for Messages which are shown for Interaction queues list. As the queues usually have a lot of related messages - to lighten the messages list, the below messages are filtered out for queues:

EventPropertiesChanged
EventAttachedDataChanged
RequestDistributeEvent
EventPartyAdded
EventPartyRemoved

7. If you have big delays working in EL DB mode it is recommended to build indexes in EL DB:

	table RPT_INTERACTION - by field SEQID 
	table RPT_ESP - by field SEQID

8. See the program updates in Release Notes file

9. Please let me know if you want to get emails about Myzamir updates, I will add your email address to the list.
("Sergey Lebedev"<lebedev@genesyslab.com>)

Limitations
----------

1. Log file timestamps must be in format 'hh:mm:ss.msc'. 
Note - starting from 7.6.104.12 timestamp format 'yyyy-mm-dd hh:mm:ss.msc' is suppotred,
'dd/mm/yyyy hh:mm:ss.msc' is supported from 8.0.101.03.

2. Supported versions of Interaction server logs - 7.2, 7.5, 7.6.0, 7.6.1, 8.0, 8.0.1

3. Amount of processed logs size directly depends on the host physical memory. Tests showed that a host with 1Gb allows to process max up to 700-800Gb logs at ones. After that you can see side effects like the application freeze.

4. The log files loaded together must have different names.

5. ELDB mode limitations:

	- Log files mode and Database mode can not be used together at once. To switch from one to another you have to use 'Clear All'
	- Threshold by amount of Conn ID is not applicable
	- Threshold by Request delay marks only Message records of ESP 
	- Button 'Space' in Messages list (to find relative message) works only for Message records of ESP 
	- Top menu item 'View/Hide all reporting events' is disabled
	- External viewer is not applicable
	- If you have big delays working in EL DB mode it is recommended to build indexes in EL DB:
		table RPT_INTERACTION - by field SEQID 
		table RPT_ESP - by field SEQID

6. Refresh doesn't work if log files are read from shared unix folder(samba)
		
Sergey Lebedev
lebedev@genesyslab.com

