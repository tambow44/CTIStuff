SIP Log Visualizer

SIP Log Visualizer provides a graphical representation of SIP Server log

1. Startup

SIP Log Visualizer is provided as a .jar file. To run it use following command (java should be installed in placed into PATH)

java -jar logvisualizer.jar [options] [log file name or directory containing log files]

For handling large amount of log files, increase java VM heap sizes, etc.

java -Xms512m -Xmx1024m -jar logvisualizer.jar

2. Command line options

-d <callId> <file/folder name> - show only messages related to specified SIP callID. Example:
	-d 4E359F3F-8936-4555-9349-425FB42DEC8B-108@172.25.59.86 "C:\Projects\Logs\Sip\SR\7.6\logs"

-c <callUUID/connID> <file/folder name> - show only messages related to specified Genesys UUID. Example:
	-c N0KVS0TN252DD63OKNMJT9O9QS00002R "C:\Projects\Logs\Sip\SR\7.6\logs"
	-c 008201bfaff0e002 "C:\Projects\Logs\Sip\SR\7.6\1.log"

-s <folder name> - [EXPERIMENTAL] create statistic output files statistics.csv and statistics_anomalies.txt. statistics.csv provides statistical information (number of dialogs, delays, anomalies counts). statistics_anomalies.txt provides list of call-ID that had:
	- INVITE retransmissions
	- Simultaneous re-INVITE (491 Request Pending)
	- 481 Call Leg/Transaction Does Not Exist to INVITE
	- INVITE is CANCEL-ed

-a <folder name> - [EXPERIMENTAL] show only SIP dialogs that have anomalies
-m <folder name> - multisite logs or primary and backup logs

-l4 <folder name> - read 20 latest logs from the specified folder. For sip-link-type=4 mode when each thread outputs own log
-l3 <folder name> - read 3 latest logs from the specified folder. For sip-link-type=3 mode when each thread outputs own log
-l <folder name> - read 1 latest logs from the specified folder. For sip-link-type=0 mode.

3. User Interface

Clicking any message show details of the message.
Right-click a message to hide a call or display on a call

4. Unsupported feature

Edit - Copy to clipboard menu is not currently supported.
