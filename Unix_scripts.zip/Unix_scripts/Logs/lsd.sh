#Author  : Dirk Berlin
#Date    : 08/03/98
#Function: IF no argument 
#	   THEN
#		list directories in the current directory
#          ELSE
#		list directories in $1
#
if [ $# -eq 0 ]
then
	echo "Directory listing of `pwd`" 
	echo "Permission  Ln Owner    Group    File Sz Last Access  Directory name"
	echo "----------  -- -----    -----    ------- -----------  --------------"
	find . -type d \! -name . -prune -exec ls -ld {} \; | sort -k 9
else
	echo "Directory listing of $1" 
	echo "Permission  Ln Owner    Group    File Sz Last Access  Directory name"
	echo "----------  -- -----    -----    ------- -----------  --------------"
	find $1/* -type d \! -name $1 -prune -exec ls -ld {} \; | sort -k 9
fi


