#!/bin/ksh

#lists 20 most current logs in current directory

ls -ot $1 | head -20

