#!/bin/bash
#Rowan Barrie 13/3/14
#autoTail: Tailing script that automatically jumps to new log files.

#Check that a file parameter is given, otherwise echo usage.
if [[ $# -ne 1 ]]
then
        echo "usage: file."
        echo -e "\t Input file parameter can be the prefix of a log file,"
        echo -e "\t e.g. 'autoTail ss_od' begins tailing ss_ods_p.20140314_073335_638.log."
        echo -e "\t Use >> (append) when redirecting grep to a file to prevent overwrites,"
        echo -e "\t e.g. 'tail ss_ods | grep Server >> myLog'."
        exit 1
fi

#Find the latest log file with the name prefix given in 1st argument, not containing 'snapshot' in the name
logFilePrefix="$(echo $1 | cut -d'.' -f1)\."
latestLogFile=$(ls -t | grep $logFilePrefix | grep -v snapshot | head -1)
currentLogFile=$latestLogFile

#Check if such a log file exists
if [[ -z $latestLogFile ]]
then
        echo "No such log file."
        exit 1
fi

#Tell user auto-tailing is starting
echo "**Auto-tailing $latestLogFile**"

#Only want to begin logging new entries as they come in,
#so set totalLinesNow = totalLinesPrev when initialising.
totalLinesNow=$(wc -l $currentLogFile | awk '{print $1}')
totalLinesPrev=$totalLinesNow

#Main loop enabling indefinite tailing
while :
do
        #Find the latest log file, not containing 'snapshot' in the name
        latestLogFile=$(ls -t | grep $logFilePrefix | grep -v snapshot | head -1)
        #Check if this is newer than the log file currently open
        if [ $latestLogFile != $currentLogFile ]
        then
                #Update the current log file to be the latest one
                currentLogFile=$latestLogFile
                #Will want to output entirety of newer log file
                totalLinesPrev=0
        fi

        #Find the total number of lines in the current log file
        totalLinesNow=$(wc -l $currentLogFile | awk '{print $1}')

        #Check if new lines have been added
        if [[ $totalLinesNow -gt $totalLinesPrev ]]
        then
                newLineCount=`expr $totalLinesNow - $totalLinesPrev`
                #Tail any new lines that have been added
                #tail -$newLineCount $currentLogFile
                tail -$newLineCount $currentLogFile
                totalLinesPrev=$totalLinesNow
        fi


        #Sleep for 1 second
        sleep 1
done
