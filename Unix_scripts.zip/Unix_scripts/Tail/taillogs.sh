#!/bin/ksh

prog_name=`basename $0`
if [ $# = 0 ]
then
  echo "Use this script to monitor log files etc."
  echo "The script tails the latest instance of "
  echo "the file name prefix in the argument."
  echo "Use Wildcards without *. ie \"ts_ccs\" instead of \"ts_ccs*\""
  echo
  echo "Usage: $prog_name <filename_prefix>"
else
  tail -f `ls -ot $1*.log | grep -v snapshot | head -1 | awk '{print $8}'`
fi

