#!/bin/sh
#/**
# *
# * Automatic log file zipper - Version 1.6.1 (RHEL)
# * By Nick Tait (mailto:nick.tait@telstraclear.co.nz)
# * Copyright 2009 TelstraClear Ltd
# *
# * Modified by Thom Blakely (mailto:Thomas.Blakely@vodafone.com):
# * 1. Added condition to check/create logdirectory
# * 2. complied to POSIX syntax

# * Manages log files by performing the following steps:
# * 1. Compresses (gzips) all log files except those that are currently being read from or written to.
# * 2. Deletes the oldest compressed log files until there is a predefined percentage of disk space available.
# * 3. Moves log files older than the archive days parameter in the conf file to an archive subdirectory.
# *
# * Command line syntax:
# * ./autoarchive.sh
# * ./autoarchive.sh -r
# * ./autoarchive.sh -?
# *
# * Where:
# * 	-r is used to redirect output to a log file named based on timestamp
# * 	-? is used for help (this text)
# *
# * Parameters that control which files are archive are stored in the file autoarchive.conf, which resides in the same directory as this script.
# *
# */

# Set PATH as required by script.
PATH=/usr/sbin:/usr/bin:/bin:/sbin

# Read parameters from configuration file.
conffile=$(echo "$0" | sed -e 's/\.sh$//').conf

if [ -f "$conffile" ]; then
	directory=$(sed -e '/^#/ d; /^directory=/ !d; s/^[^=]*=//' "$conffile")
	files=$(sed -e '/^#/ d; /^files=/ !d; s/^[^=]*=//' "$conffile")
	threshold=$(sed -e '/^#/ d; /^threshold=/ !d; s/^[^=]*=//' "$conffile")
	outputsubdir=$(sed -e '/^#/ d; /^outputsubdir=/ !d; s/^[^=]*=//' "$conffile")
	archivedir=$(sed -e '/^#/ d; /^archivedir=/ !d; s/^[^=]*=//' "$conffile")
	archiveage=$(sed -e '/^#/ d; /^archiveage=/ !d; s/^[^=]*=//' "$conffile")
else
	echo "Configuration file $conffile doesn't exist"
	exit 1
fi

# Process command-line arguments.
case "$#" in
0)
	;;
1)
	case "$1" in
	"-?")
		sed -e '/^#\/\*\*$/,/^# \*\/$/ !d; /^#\/\*\*$/ d; /^# \*\/$/ d; s/^# \* \{0,1\}//' "$0"
		exit 0
		;;
	"-r")
        	# Creates logdirectory if not already
                if [ ! -d "$directory/$outputsubdir/" ]; then
                        mkdir -p "$directory/$outputsubdir/"
                fi

		logfile=$directory/$outputsubdir/$(echo "$0" | sed -e 's/^.*\///; s/\.sh$//').$(date "+%Y%m%d_%H%M%S").log
		while [ -f "$logfile" ] && [ -f "$logfile.gz" ]; do
			echo "Output file already exists - sleeping for 1 second"
			sleep 1
			logfile=$directory/$outputsubdir/$(echo "$0" | sed -e 's/^.*\///; s/\.sh$//').$(date "+%Y%m%d_%H%M%S").log
		done

		shift
		echo "Restarting script and redirecting output to $logfile"
		exec "$0" "$*" >> "$logfile" 2>&1

		echo "Restart failed! Carrying on without redirection"
		;;
	*)
		echo "Invalid arguments (use \\'$0 -?\\' for help)"
		
		exit 2
		;;
	esac
	;;
*)
	echo "Invalid arguments (use \\'$0 -?\\' for help)"
	exit 2
	;;
esac

# Print current date and time.
echo "Script running at $(date) with PID $$"

# Check that there are no other instances running.
pidfile=/tmp/$(echo "$0" | sed -e 's/^.*\///; s/\.sh$//').pid
echo $$ >> "$pidfile"
pidcheck=$(head -1 "$pidfile")

if [ "$pidcheck" -eq "$$" ]; then
	echo "PID check was successful - no other instances running"
elif [ -d "/proc/$pidcheck" ]; then
	echo "PID check FAILED - other instance(s) running"
	exit 1
else
	echo "PID check FAILED - but other instance ($pidcheck) is not running"

	echo "Deleting PID check file"
	rm "$pidfile"
	echo "Sleeping for 2 seconds"
	sleep 2
	echo "Restarting"
	exec "$0" "$*"

	echo "Restart failed! Exiting"
	exit 1
fi

# Check mandatory parameters.
if [ ! -d "$directory" ]; then
	echo "Error: directory parameter doesn't refer to an existing directory"
	exit 1;
elif [ -z "$files" ]; then
	echo "Error: files parameter is blank"
	exit 1;
elif [ -n "$archivedir" -a ! $threshold -gt 0 ]; then
	echo "Error: threshold parameter is not greater than zero"
	exit 1;
fi

# Print disk space.
diskspace=$(df -h $directory | grep $directory | sed 's/^/x/' | awk '{print $5+0}')
echo "Disk capacity before compression is $diskspace%"

# Compress files that aren't currently in use.
echo "Compressing uncompressed files"
t=$files
while [ -n "$t" ]
do
	h=$(echo "$t" | sed -e 's/ .*$//')
	t=$(echo "$t" | sed -e 's/^[^ ]* *//')

	d=$(echo "$directory/$h" | sed -e 's/\/[^/]*$//')
	p=$(echo "$h" | sed -e 's/^.*\///')
	echo "Looking for files in directory $d matching pattern $p"
	for i in $(find $d/. -name . -o -prune -type f -name "$p" -print)
	do
		u=$(fuser "$i")
		if [ -z "$u" ]; then
			echo "Compressing $i"
			nice gzip -f "$i"
		else
			echo "Skipping $i"
		fi
	done

	if [ -n "$archivedir" ]; then
		d=$d/$archivedir
		echo "Looking for files in directory $d matching pattern $p"
		for i in `find $d/. -name . -o -prune -type f -name "$p" -print`
		do
			u=$(fuser "$i")
			if [ -z "$u" ]
			then
				echo "Compressing $i"
				nice gzip -f "$i"
			else
				echo "Skipping $i"
			fi
		done
	fi
done

# Print disk space.
diskspace=$(df -h $directory | grep $directory | sed 's/^/x/' | awk '{print $5+0}')
echo "Disk capacity after compression is $diskspace%"

# Delete oldest compressed files.
# This originally used ls -1rt, but was changed due to ls failing if there are too many files.
echo "Deleting compressed files"
for n in 365 270 180 150 120 90 60 45 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0
do
	diskspace=$(df -h $directory | grep $directory | sed 's/^/x/' | awk '{print $5+0}')
	if [ $diskspace -gt $threshold ]; then
		echo "Deleting compressed files older than $n days"

		t=$files
		while [ -n "$t" ]
		do
			h=$(echo "$t" | sed -e 's/ .*$//')
			t=$(echo "$t" | sed -e 's/^[^ ]* *//')

			d=$(echo "$directory/$h" | sed -e 's/\/[^/]*$//')
			p=$(echo "$h" | sed -e 's/^.*\///').gz
			echo "Looking for files in directory $d matching pattern $p older than $n days"
			for i in $(find $d/. -name . -o -prune -type f -name "$p" -mtime +$n -print)
			do
				u=$(fuser "$i")
				if [ -z "$u" ]
				then
					echo "Deleting $i"
					rm "$i"
				else
					echo "Skipping $i"
				fi
			done

			if [ -n "$archivedir" ]; then
				d=$d/$archivedir
				echo "Looking for files in directory $d matching pattern $p older than $n days"
				for i in $(find $d/. -name . -o -prune -type f -name "$p" -mtime +$n -print)
				do
					u=$(fuser "$i")
					if [ -z "$u" ]
					then
						echo "Deleting $i"
						rm "$i"
					else
						echo "Skipping $i"
					fi
				done
			fi
		done
	else
		break
	fi
done

# Move files older than $archiveage days to archive subdirectory if they are not already in an archive subdirectory.
if [ -n "$archivedir" ]; then
	echo "Archiving compressed files older than $archiveage days"

	t=$files
	while [ -n "$t" ]; 
	do
		h=`echo "$t" | sed -e 's/ .*$//'`
		t=`echo "$t" | sed -e 's/^[^ ]* *//'`

		d=`echo "$directory/$h" | sed -e 's/\/[^/]*$//'`
		p=`echo "$h" | sed -e 's/^.*\///'`.gz
		echo "Looking for files in directory $d matching pattern $p older than $archiveage days"
		for i in `find $d/. -name . -o -prune -type f -name "$p" -mtime +$archiveage -print | grep -v "/$archivedir/\\./"`
		do
			u=`fuser "$i"`
			if [ -z "$u" ]; then
				a=`echo "$i" | sed -e 's/\/[^/]*$//'`/$archivedir
				echo "Archiving $i to $a"
				mkdir -p "$a"
				mv "$i" "$a/."
			else
				echo "Skipping $i"
			fi
		done
	done
fi

# Print disk space and current date and time.
echo "Disk capacity after deletion is $diskspace%"
echo "Script finished at `date`"

# Remove PID file.
rm $pidfile
