#!/bin/ksh
#=============================================================================
# This scripts monitors the  disk space on the host
# If the FS has filled up to to MAX_FS_PERCENT_USED value, the script will 
# send an email to the Service Desk and to Dirk.
#
# This script was produced to monitor FS space when VQConnect was turned on 
#
# The script is started by cron 5 min after midnight every day and terminates
# itself at 1 sec after midnight the following day
#
#=============================================================================
#
# By Dirk Berlin (dirk.berlin2@vodafone.com)
#
#=============================================================================
#
#Global definitions/Constants/initializations etc
#
#echo "Initialising...."
ERRCHKINTERVAL=1800                                      # check interval in seconds
MAX_FS_PERCENT_USED=90
HOSTNAME=`hostname`
WKDIR=/home/genesys/scripts
FS_TO_CHECK="opt"
CURR_FS_PERCENT_USED=`df -k | grep $FS_TO_CHECK | grep -v grep  | awk '{print $5}' | sed "s/%//g"`
REAL_FS_NAME=` df -k | grep $FS_TO_CHECK | grep -v grep  | awk '{print $6}'`
EMAILHEADER="IR File System space utilisation alert ..."
EMAILMSG="Increase in File System utilisation  detected"
SENDER="$HOSTNAME"
EMERG_RECIPIENTS="dirk.berlin2@vodafone.com DMZGlobal.Support@vodafone.com"  # space separated for multiple recipients
RECIPIENTS="dirk.berlin2@vodafone.com"            # space separated for multiple recipients
EMAILBODYTXTFILE=$WKDIR/`basename $0`_email.txt


#echo "CURR_FS_PERCENT_USED = $CURR_FS_PERCENT_USED"
#echo `basename $0`

#
#main body of this script
#iterate while it is still today (cron starts a new instance each day!)
#
START_DAY=`date +%u`
TODAY=`date +%u`

while [ $TODAY -eq $START_DAY ]
do
  #echo "Running while loop..."
  CURR_FS_PERCENT_USED=`df -k | grep $FS_TO_CHECK | grep -v grep  | awk '{print $5}' | sed "s/%//g"`
  if [ $CURR_FS_PERCENT_USED -gt $MAX_FS_PERCENT_USED ]
  then
    echo "FS too large, CURR_FS_PERCENT_USED = $CURR_FS_PERCENT_USED" 
    echo "$EMAILMSG on `date +%d/%m/%Y` at `date +%r`\n" > $EMAILBODYTXTFILE
    echo "File System \"$REAL_FS_NAME\" is at $CURR_FS_PERCENT_USED% and has exceeded the threshold!!!\n" >> $EMAILBODYTXTFILE
    echo "There is an issue that has the potential to bring the entire IR Contact Centre down\n " >> $EMAILBODYTXTFILE
    echo "PLEASE CALL DIRK BERLIN ON 029 920 3813 IMMEDIATELY !!!!\n" >> $EMAILBODYTXTFILE
    #echo "Sending email to $EMERG_RECIPIENTS ...." 
    #cat $EMAILBODYTXTFILE | mailx -s "$EMAILHEADER" -r $SENDER $EMERG_RECIPIENTS
    cat $EMAILBODYTXTFILE | mailx -s "$EMAILHEADER" -r $SENDER $RECIPIENTS
    #echo "Done!!!"
  else
    echo "$EMAILMSG on `date +%d/%m/%Y` at `date +%r`\n" > $EMAILBODYTXTFILE
    echo "File System \"$REAL_FS_NAME\" is at $CURR_FS_PERCENT_USED%" >> $EMAILBODYTXTFILE
    #echo "Sending email to $RECIPIENTS ...."
    cat $EMAILBODYTXTFILE | mailx -s "$EMAILHEADER" -r $SENDER $RECIPIENTS
    #echo "Done!!!"
  fi
  rm $EMAILBODYTXTFILE
  sleep $ERRCHKINTERVAL
  TODAY=`date +%u`
done

