#!/bin/nawk -f
BEGIN {
	OFS=",";
	print "time","error","call","dn","device","description";
}

/ Collected jtapi\[1\] tevent/ {
	event=$0;
	sub(/^.* tevent\([0-9a-f]*:/,"",event);
	detail=event;
	sub(/\).*$/,"",event);
	sub(/^[^)]*\)\(/,"",detail);
	sub(/\).*$/,"",detail);
	if (event == "ADDR_CREATED") {
		dn=detail;
		sub(/:.*$/,"",dn);
		device=detail;
		sub(/^.*:/,"",device);
		#print event,dn,device;
		map[dn] = device;
	}
}

/ JTAPI ERROR / {
	time=$0;
	sub(/^@/,"",time);
	sub(/ .*$/,"",time);
	error=$0;
	sub(/^.* JTAPI ERROR /,"",error);
	sub(/ .*$/,"",error);
	call=$0;
	sub(/^.* in call /,"",call);
	sub(/,.*$/,"",call);
	dn=$0;
	sub(/^.* dn /,"",dn);
	sub(/:.*$/,"",dn);
	desc=$0;
	sub(/^.*: */,"",desc);
	gsub(/"/,"\"\"",desc);
	print time,error,call,dn,map[dn],"\"" desc "\"";
}
