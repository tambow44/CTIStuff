#!/bin/bash
PATH=/usr/bin
# ae 11-nov-12
# Display all the meaningful licences. This is run via the License tool.
# And don't worry about those ones that end in ACAA
if [[ $1 ]]; then
  /opt/GCTI/flexlm/lmstat -f "$1" -c /opt/GCTI/flexlm/license.dat | egrep "start|issued"
else
  /opt/GCTI/flexlm/lmstat -a -c /opt/GCTI/flexlm/license.dat | grep issued | grep -v "AA:" | grep -v 999999
fi
