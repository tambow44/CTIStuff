regex='Route.*\[57:'
encRE="Route.-2A-5C-5B57-3A"
mailto="ctiengineers@vodafone.com"
perhour=4
