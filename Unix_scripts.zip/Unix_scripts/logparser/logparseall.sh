#!/bin/bash
/home/genesys/scripts/logparser2-1.sh dca1 /opt/GCTI/logs/ts_ccm ts_ccm_dca1
/home/genesys/scripts/logparser2-1.sh dca2 /opt/GCTI/logs/ts_ccm ts_ccm_dca2
/home/genesys/scripts/logparser2-1.sh mnk /opt/GCTI/logs/ts_ccm ts_ccm_mnk
