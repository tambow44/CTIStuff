#!/bin/bash
PATH=/usr/bin
# logparser2.sh - Process log files and find known errors
# Andrew Mar-2013
#
# PARAM 1  unique instance name (no spaces) 
# PARAM 2  target dir of log files
# PARAM 3  prefix of log file
# Run like:
#              ./logparser2.sh mnk /genesyslogs/ts_ccm ts_ccm_mnk
#
# Look for all the .log files in the target directory. For each one, check their size (number of lines)
# compared to the last time we ran this script.
# If the file's size has changed, or it is a new log file, process ONLY the new bit.
#
# Search through the resultant chunk  with a regex search and, if we find a likely candidate, send an email alarm.
#
# IMPORTANT: This must run **just** before Nick's autoarchive script. Autoarchive.sh does not touch open log
# files so we are safe, unless there is too long a gap between this running and autoarchive.sh running.
# If the log file happens to get closed (reaches the 50M limit and Genesys closes it) in the fraction of the 
# second between this script running and autoarchive.sh running, AND one of the sought errors occurs then,
# then that log would be zipped up and so would never get checked. So we would miss that error.
#
# Special use
# PARAM 1 PATTERN
# PARAM 2 unique instance name
# PARAM 3 encoded regular expression of string (use ascii hex codes like "-3F", see decode function below)
# PARAM 4 mail to - who gets mailed when fault detected
# PARAM 5 per-hour - how many times does this fault need to be detected in a hour to trigger a mail
#
# e.g.     ./logparser2.sh PATTERN mnk Route.-2A-5C-5B57-3A "andrew.earl@tcl.co.nz" 4
#           will load the regex "Route.*\[57:" in to the pattern
# Saves that rule into the logparser pattern dir. 
#
# New rule engine:
# patternfile has the list of regexes of all the patterns. The xgrep can use this direct.
# then each one has its own sh file and soln file of the encoded name. The sh file is run to set the variables to process
# pattern: regex again (same as patternfile)
# mailto: who to mail (def )
# perhour: how many detects in an hour before alarming (def=1, means always)

function log {
  echo $1
  echo $1 >> $logfile
}

function decode() {
  # decode specials. exceptions: !()-.=@^_~
  t="${1//-25/%}"
  t="${t//-2B/+}"
  t="${t//-20/ }"
  t="${t//-2A/*}"
  t="${t//-22/\"}"
  t="${t//-5C/\\}"
  t=${t//-23/\#}
  t=${t//-24/\$}
  t=${t//-27/\'}
  t=${t//-60/\`}
  t=${t//-2F/\/}
  t=${t//-3B/\;}
  t=${t//-3A/\:}
  t=${t//-26/&}
  t=${t//-7C/|}
  t=${t//-3C/<}
  t=${t//-3E/>}
  t=${t//-5B/[}
  t=${t//-5D/]}
  t=${t//-3F/?}
  t=${t//-7E/~}
  echo "$t"
}

# ==== START HERE =============
# -x is display every line, -e stops when $? is non-zero, -u stops on uninit variables
#set -x
set -u
# set -e
ourlogdir=/opt/GCTI/logs/logparser
patternroot=`dirname $0`/logparser

# Check for new pattern
if [ "$1" == "PATTERN" ] ; then
  patterndir=$patternroot/$2
  Enc=$3
  Lraw=`decode $Enc`
  mkdir -p $patterndir
  echo "regex='$Lraw'">$patterndir/$Enc.sh
  echo "encRE=\"$Enc\"">>$patterndir/$Enc.sh
  echo "mailto=\"$4\"">>$patterndir/$Enc.sh
  echo "perhour=$5">>$patterndir/$Enc.sh
  rm $patterndir/pattern.live
  for f in $patterndir/*.sh; do
    . $f
    echo "$regex">>$patternfile/pattern.live
  done
  exit
fi

unique=$1
logdir=$2
logprefix=$3

# Defaults - overridden by the fault
mailto=ctiengineers@vodafone.com
perhour=1

patterndir=$patternroot/$unique
patternfile=$patterndir/pattern.live

tmppattern=$patterndir/pattern.tmp
tmptopdir=/tmp/logparser
tmpdir=$tmptopdir/$unique
tmpchunk=$tmpdir/chunk.tmp
tmprunning=$tmpdir/running
tmp=$tmpdir/tmp.tmp
tmp2=$tmpdir/tmp2.tmp
tmpfile=$tmpdir/file.tmp
tmpfound=$tmpdir/found.tmp

datestamp=`date +%y%m%d-%H%M`
hourstamp=`date +%d%H`
min10stamp=$((`date +%M`/10))

logfile=$ourlogdir/$unique-`date +%y%m%d`.day

log "`date +%H:%M:%S`--start-$patterndir----$$-------"

mkdir -p $tmpdir
mkdir -p $patterndir
mkdir -p $ourlogdir

# Must be a pattern file
if [ ! -f $patternfile ] ; then
  log "No pattern file: $patternfile"
  exit
fi

# We don't want multiple instances of this running
# (this can happen if cron goes mad)
if [ -f $tmprunning ] ; then
  ps -ef | grep $(cat $tmprunning) | grep -v grep
  if [ $? -eq 0 ] ; then
    log "Instance of $unique already running ($(cat $tmprunning))"
    exit
  fi
fi

echo $$>$tmprunning

# FIND CHANGED LOGS
# Find all the files that have changed (different lengths) since last run
echo "Find all logs changed since last time"
tocopy=
for F in `ls -1 $logdir | egrep "$logprefix.*[0-9]\.log$"`; do
  oldsize=0
  # newsize=`du -k $logdir/$F | cut -f 1`
  newsize=`wc -l < $logdir/$F`
  if [ -f $tmpdir/$F ] ; then
    oldsize=`cat $tmpdir/$F`
  fi
  if [ "$oldsize" -ne "$newsize" ]; then
    tocopy="$tocopy $F"
  fi
done

# delete the filthy tmps from last time
rm -f $tmpdir/*.tmp

# Search preliminaries
ourgrep="/usr/xpg4/bin/grep -i -E"
echo "Error" >$tmpfound

# SEARCH LOGS
gomail=0
echo "To be searched: $tocopy"
if [ "${#tocopy}" -gt 1 ] ; then
  for F in $tocopy ; do
    cp $logdir/$F $tmpfile
    #echo "$logdir/$F ==================.">>$tmpfound
    oldsize=1
    if [ -f $tmpdir/$F ] ; then
      oldsize=`cat $tmpdir/$F`
    fi
    tail +$oldsize $tmpfile > $tmpchunk
    log "Scanning $F chunk (`wc -l < $tmpchunk` lines) with pattern file $patternfile"
    $ourgrep -f $patternfile $tmpchunk >$tmp
    if [ $? -eq 0 ] ; then
       log "Pattern found"
       # If ANY of the strings in the pattern are in the chunk, loop through the all the
       # patterns in the patterndir, and find one detected
       for foal in $patterndir/*.sh ; do
         # run the pattern sh file which loads regex, encRE, mailto and perhour
         . $foal
         $ourgrep "$regex" $tmpchunk > $tmp2
         if [ $? -eq 0 ] ; then
           log "Process $regex "
           ff="$patterndir/$encRE.m$hourstamp-$min10stamp"
           h=`$ourgrep -c "$regex" $tmpchunk`
           echo "hrsum=\$((\$hrsum + $h))">>$ff
           echo "logerr=\"\$logerr $logdir/$F\"">>$ff
           e="`head -n 2 $tmp`"
           echo "errortxt=\"${e//\"/\\\"}\"">>$ff
         fi
       done
    else
       log "no errors found"
    fi
    newsize=`wc -l < $tmpfile`
    echo $newsize>$tmpdir/$F
  done
fi

for foal in $patterndir/*.sh ; do
  # run the pattern sh file which loads regex, encRE, mailto and perhour
  . $foal
  # Sum hrsum
  hrsum=0 
  logerr=" "
  for ((i=0; i<6; i++)); do
     [ -f $patterndir/$encRE.m$hourstamp-$i ] && . $patterndir/$encRE.m$hourstamp-$i
  done
  [ $hrsum -gt 0 ] && log "$regex $hrsum times"
  if [ $hrsum -ge $perhour ] ; then
    echo "$(uname -n) Fault: regex=\"$regex\" ---------------------------.">$tmpfound
    echo "Found in: $logerr">>$tmpfound
    echo $errortxt>>$tmpfound
    echo "Solution:">>$tmpfound
    cat $patterndir/$encRE.soln>>$tmpfound
    cat $tmpfound>>$tmpdir/mail-`date +%d`.log
#mailto=andrew.earl@vodafone.com
    log "Fault regex $regex (hrsum=$hrsum ge perhour=$perhour): mail to $mailto"
    cat $tmpfound | mailx -r logparser -s "Logparser detected error: $unique ** $hrsum ************" $mailto
    rm $patterndir/$encRE.m$hourstamp-?
  fi
done

# Delete old stamp, tmp and day logs 
find $patterndir -name *.m????-? -type f -mtime +7 -exec rm {} \;
find $tmpdir -name *.log -type f -mtime +30 -exec rm {} \;
find $ourlogdir -name *.day -type f -mtime +90 -exec rm {} \;
rm $tmprunning
log "`date +%H:%M:%S`--finish--------------------"

