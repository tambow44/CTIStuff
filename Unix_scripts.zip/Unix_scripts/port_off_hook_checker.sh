#!/bin/ksh

#=============================================================================
# This scripts monitors the DMS TServer logs for 'Agent Position is busy'
# which indicates that a GVP port has rmained in an off-hook state in the DMS
# but the URS is still routing calls to that port.
# If this error is found, the script sends an email alert to the CTI team
# who then should either log out the agent that is associated with that port
# or disable that port in CME.
# To recover a port that is in that off-hook state, use 'pstndiag' in the VCS
# to reset the port and then log the agent back in or enable the port in CME
# If multiple ports are affected it is easier to restart the GVP and Dialogic
# processes in the VCS
#
# The script is started by cron 5 min after midnight every day and terminates
# itself at 1 sec after midnight the following day
#
#=============================================================================
#
# By Dirk Berlin (dirk.berlin@telstraclear.co.nz)
#
#=============================================================================
#
#Global definitions/Constants/initializations etc
#
HOSTNAME=`hostname`
WKDIR=/opt/GCTI/logs/ts_dms                         # location of TS log file and also working directory for this script
#WKFILE=$WKDIR/`ls -l | grep ts | head -1 | sed "s/\./\ /g" | awk '{print $9}'`*                       # TS log file name
WKFILE=$WKDIR/ts_A100_n*                       		# TS log file name
TMPFILE_1=$WKDIR/`basename $0`_tmp1.txt                 # tmp file to hold previous TS log file names
TMPFILE_2=$WKDIR/`basename $0`_tmp2.txt                 # tmp file to hold current TS log file names
DIFF_FILE=$WKDIR/`basename $0`_diff.txt                 # tmp file to hols TS log file names to check
ERRFILE=$WKDIR/`basename $0`_err.txt                    # tmp file to hold TS file names that contain error
THIS_HOSTNAME=`hostname`                                # Server name
SEARCHSTR="Agent position is busy"                         # KVP to search for
EMAILBODYTXTFILE=$WKDIR/email.txt                       # contents in this file is included in email message
EMAILHEADER="IR GVP port off-hook error alert ..."               # email subject mesg
EMAILMSG="\"GVP port - Agent position is busy\" detected"         # email notification mesg (date and time are added later in script)
SENDER="$HOSTNAME"                                           # From ARIA@server.domain
#RECIPIENTS="dirk.berlin@telstraclear.co.nz CTIEngineers@telstraclear.co.nz"            # space separated for multiple recipients
#RECIPIENTS="dirk.berlin@telstraclear.co.nz"            # space separated for multiple recipients
RECIPIENTS="dirk.berlin2@vodafone.com Sam.Wu@vodafone.com"            # space separated for multiple recipients
ERRCHKINTERVAL=600                                      # check interval in seconds
LOGIINSTRUCT=/home/genesys/scripts/`basename $0`_log_cap.txt


#
#main body of this script
#iterate while it is still today (cron starts a new instance each day!)
#
START_DAY=`date +%u`
TODAY=`date +%u`

while [ $TODAY -eq $START_DAY ]
do
  ls -ot $WKFILE | head -30 > $TMPFILE_1
  if [ -f $TMPFILE_2 ]
  then
    diff $TMPFILE_1 $TMPFILE_2 | grep "<" | awk '{print $9}' > $DIFF_FILE
  else
    cat $TMPFILE_1 | awk '{print $8}' > $DIFF_FILE
  fi

  for FILENAME in `cat $DIFF_FILE`
  do
    echo "$FILENAME" >> $ERRFILE
#    echo "Searching $FILENAME"
#    gzgrep -in "$SEARCHSTR" $FILENAME | grep "$ERRSTR" >> $ERRFILE
    gzgrep -in "$SEARCHSTR" $FILENAME  >> $ERRFILE
    echo "-----------------------------"  >> $ERRFILE
#    echo "Done with  $FILENAME"
  done
  #ERRCNTR=`grep "$ERRSTR" $ERRFILE | wc -l`
  ERRCNTR=`grep "$SEARCHSTR" $ERRFILE | wc -l`
#  if [ -f $ERRFILE -a -s $ERRFILE ]
  if [  $ERRCNTR -gt 0  ]
  then
#    cp $ERRFILE `basename $0`_`date +%Y%m%d_%H%M%S`_err.txt
## echo "Wrinting email contents..."
    echo "$EMAILMSG on `date +%d/%m/%Y` at `date +%r`" > $EMAILBODYTXTFILE
    cat $LOGIINSTRUCT >> $EMAILBODYTXTFILE
    cat $ERRFILE >> $EMAILBODYTXTFILE
    cat $EMAILBODYTXTFILE | mailx -s "$EMAILHEADER" -r $SENDER $RECIPIENTS
    rm $EMAILBODYTXTFILE
  fi
  rm $ERRFILE
  cp $TMPFILE_1 $TMPFILE_2
  sleep $ERRCHKINTERVAL
  TODAY=`date +%u`
done

