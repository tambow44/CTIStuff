#!/bin/bash
# jtapilogger fixer
# ae jun-2014
# The Genesys Jtapi logger uses the stupid java rotating logger. This means after 100 files, the log files
# get over-written. Currently, this happens in LESS THAN ONE day. 
# So this script goes through and renames the jtapi logs in a format such that we can keep them for months 
# (like we do with other Genesys logs).
# Does a gzip as well.
#
# Set this to run once every two hours during the day. 

# The main problem here is that we don't want to process the log files that are currently being written.
# This is achieved by checking the mod date of the index file and not touching a log file if it
# is newer than that (using find -newer).

PATH=/bin:/usr/bin:/usr/sbin:/usr/local/bin
echo "=========================================================="
date "+%d-%h-%y %H:%M:%S"

if [ -z "$1" ] ; then
  echo "Mandatory param 1: full directory path to the jtapi logs dir. (like /opt/GCTI/logs/ts_ccm/jtapi)"
  exit
fi
cd $1

# Move gz files to archivedir if older than arcdays
archivedir=archive
arcdays=1
# Delete archivedir files if older than deldays
deldays=14

for f in *jtapi*.log ; do
  # ls -E gives the full datetime. The awk print bit gets the 6th and 7th parts (date and time)
  d=$(ls -E $f|awk '{print $6 "_" $7}')
  # remove the : (from time) and - (from date), and the ${d%.*} bit chops out everything from . to end
  d=${d//:/}; d=${d%.*}; d=${d//-/}
  # f2 is the name of the new log file (ts_ccm_itn1_jtapi.20140620_1234.log)
  f2=${f%i*}i.${d}.log
  # f3 is the name of this log file's associated index file (ts_ccm_itn1_jtapi.index)
  f3=${f%_*}_jtapi.index
  # This find checks the current file ($f) and only use it if it is NOT newer than the index file (f3)
  # the "! -name . -prune" bit stops find descending into subdirectories
  # $fs is the size
  fl=$(find . ! -name . -prune -name $f ! -newer $f3)
  fs=$(ls -E $f|awk '{print $5}')
  # echo $f $fl ${#fl}
  if [ -z "$fl" ] ; then
    echo "$f is still being written to ($fs)"
  else
    echo "mv $f ($fs) -> $f2 -> .gz"
    mv $f $f2
    nice gzip $f2
  fi
done

# Move all files $arcdays or more days old to archive
mkdir -p $archivedir
files=$(find . ! -name . -prune -name \*jtapi\*.log.gz -mtime +$arcdays)
for f in $files ; do
  echo "mv $f $archivedir"
  mv $f $archivedir
done

# Delete all logs older than $deldays days in archive
files=$(find $archivedir -name \*.log.gz -mtime +$deldays)
for f in $files ; do
  echo "rm -f $f"
  rm -f $f
done

date "+%d-%h-%y %H:%M:%S"
