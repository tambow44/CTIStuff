#!/bin/sh

#=============================================================================
# This scripts monitors the DMS TServer logs for KVP TRANSFER_REASON
# that is attached by the GVP. If this contains the value of 'Vxml_error'
# we it sends an email alert to 'CTI Engineers' to retrieve the GVP logs
#
# The script is started by cron 5 min after midnight every day and terminates
# itself at 1 sec after midnight the following day
#
#=============================================================================
#
# By Dirk Berlin (dirk.berlin@team.telstraclear.co.nz)
#
#=============================================================================
#
#Global definitions/Constants/initializations etc
#
WKDIR=/opt/GCTI/logs/is                        	# location of TS log file and also working directory for this script
WKFILE=$WKDIR/ts_ir_gvp_ak100_ak*			# TS log file name
TMPFILE_1=$WKDIR/`basename $0`_tmp1.txt			# tmp file to hold previous TS log file names
TMPFILE_2=$WKDIR/`basename $0`_tmp2.txt			# tmp file to hold current TS log file names
DIFF_FILE=$WKDIR/`basename $0`_diff.txt			# tmp file to hols TS log file names to check
ERRFILE=$WKDIR/`basename $0`_err.txt			# tmp file to hold TS file names that contain error
THIS_HOSTNAME=`hostname`				# Server name
SEARCHSTR="\[TRANSFER_REASON\]"				# KVP to search for
ERRSTR="String(Vxml Error)"				# KVP value for error
EMAILBODYTXTFILE=$WKDIR/email.txt                       # contents in this file is included in email message
EMAILHEADER="IR GVP VXML error alert ..."               # email subject mesg
EMAILMSG="\"VXML Error in GVP TRANSFER_REASON\" detected"    # email notification mesg (date and time are added later in script)
SENDER="IR_A100_IServer"                                           # From ARIA@server.domain
RECIPIENTS="dirk.berlin@telstraclear.co.nz"        	# space separated for multiple recipients
ERRCHKINTERVAL=600                                      # check interval in seconds
HOSTNAME=`hostname`
LOGIINSTRUCT=/home/genesys/scripts/vmxl_err_log_cap.txt


#
#main body of this script
#iterate while it is still today (cron starts a new instance each day!)
#
START_DAY=`date +%u`
TODAY=`date +%u`

rm /home/genesys/`basename $0`_*err.txt
while [ $TODAY -eq $START_DAY ]
do
  ls -ot $WKFILE | head -30 > $TMPFILE_1
  if [ -f $TMPFILE_2 ]
  then
    diff $TMPFILE_1 $TMPFILE_2 | grep "<" | awk '{print $9}' > $DIFF_FILE
  else
    cat $TMPFILE_1 | awk '{print $8}' > $DIFF_FILE
  fi

  for FILENAME in `cat $DIFF_FILE`
  do
    echo "$FILENAME" >> $ERRFILE
#    echo "Searching $FILENAME"
    gzgrep -in "$SEARCHSTR" $FILENAME | grep "$ERRSTR" >> $ERRFILE
    echo "-----------------------------"  >> $ERRFILE
#    echo "Done with  $FILENAME"
  done

  ERRCNTR=`grep "$ERRSTR" $ERRFILE | wc -l`
#  if [ -f $ERRFILE -a -s $ERRFILE ]
  if [  $ERRCNTR -gt 0  ]
  then 
    cp $ERRFILE `basename $0`_`date +%Y%m%d_%H%M%S`_err.txt
## echo "Wrinting email contents..."
    echo "$EMAILMSG on `date +%d/%m/%Y` at `date +%r`" > $EMAILBODYTXTFILE
    cat $LOGIINSTRUCT >> $EMAILBODYTXTFILE
    cat $ERRFILE >> $EMAILBODYTXTFILE
    cat $EMAILBODYTXTFILE | mailx -s "$EMAILHEADER" -r $SENDER $RECIPIENTS
    rm $EMAILBODYTXTFILE
  fi
  rm $ERRFILE
  cp $TMPFILE_1 $TMPFILE_2
  sleep $ERRCHKINTERVAL
  TODAY=`date +%u`  
done
