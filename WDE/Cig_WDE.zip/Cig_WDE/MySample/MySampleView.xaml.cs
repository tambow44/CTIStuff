﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Genesyslab.Desktop.Modules.Windows.Common.DimSize;
using Genesyslab.Desktop.Modules.Core.Model.Interactions;
using Genesyslab.Desktop.Modules.Core.Model.Agents;
using Genesyslab.Desktop.Infrastructure.DependencyInjection;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Desktop.Infrastructure.Configuration;
using System.Diagnostics;

namespace Genesyslab.Desktop.Modules.ExtensionSample.MySample
{
	/// <summary>
	/// Interaction logic for MySampleView.xaml
	/// </summary>
	public partial class MySampleView : UserControl, IMyExtensionSampleView
	{
        //static  double dThen = 0.0;
        static string CASEID = "";
        static string URL3 = "";
        static int iProcNum = 0;
        static ILogger log;

        public  MySampleView(IMyExtensionSampleViewModel mySampleViewModel )
		{
			this.Model = mySampleViewModel;

			InitializeComponent();

			Width = Double.NaN;
			Height = Double.NaN;
			MinSize = new MSize() { Width = 400.0, Height = 400.0 };
        }

        private static string sGetElement(string sIn, string sFind) {
            /* Hypermedia JSON string has elements like this:
             * { {"rel":"find" }, { "href":"result" } }
             * Given "find", we want to return "result"
             * */
            // kill all space (the @ means don't need to escape)
            sIn = Regex.Replace(sIn, @"\s+", "");
            sFind = Regex.Replace(sFind, @"\s+", "");
            // find the "rel" bit
            int i = sIn.IndexOf("rel\":\"" + sFind);
            // find the "href" after the "rel"
            int i2 = sIn.IndexOf("href", i + 2);
            // find the 2nd quote after the href's bit
            int i3 = sIn.IndexOf("\"", i2 + 7);  // len of string 'href":"' is 7
            // ... to get our string
            string s = sIn.Substring(i2 + 7, i3 - i2 - 7 );
            return s;
        }

        public static bool Condition(ref object context) {
            IDictionary<string, object> contextDictionary = context as IDictionary<string, object>;
            List<string> slFormID2KVP = new List<string>();
              
            //object caseView;
            //contextDictionary.TryGetValue("CaseView", out caseView);

            // Initialize logger
            log = ContainerAccessPoint.Container.Resolve<ILogger>();
            log = log.CreateChildLogger("Hypermedia");
            log.Info("xbr");

            object caseObject;
            contextDictionary.TryGetValue("Case", out caseObject);
            
            ICase myCase = caseObject as ICase;
            if (myCase != null)  {
                if (myCase.MainInteraction != null)  {
                    try  {
                        string thisCaseId = myCase.CaseId as string;
                        if (CASEID.Equals(thisCaseId))  {
                            log.Info("case id "+thisCaseId+" repeated");
                        } else {
                            CASEID = thisCaseId;
                            IInteraction ixnMain = myCase.MainInteraction;
                            string sConnid="0123456789ABCDEF";
                            sConnid = myCase.MainInteraction.EntrepriseInteractionCurrent.Id;
                            sConnid = sConnid.ToLower();
                            log.Info("connid="+sConnid);

                            string sPopURL = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.popurl") as string;
                            string sURL1 = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.url1") as string;

                            if ((sURL1 == null) || (sPopURL == null) || (sURL1.Length < 4) || (sPopURL.Length < 4)) {
                                log.Info("hypermedia.popurl or url1 not defined ");
                            } else {
                                log.Info("thisCaseId=" + thisCaseId);
                                string sPerson = ixnMain.Agent.UserName;
                                log.Info("agent & place: " + sPerson + " " + ixnMain.Agent.Place );

                                string sBrowser = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.browser") as string;
                                // Default to internet explorer
                                if (sBrowser == null || sBrowser.Length < 2) sBrowser = "IEXPLORE.EXE";

                                string sLogin = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.api-login") as string;
                                string sPassword = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.api-password") as string;
                                log.Info("API authentication login & password: '" + sLogin + "' '" + sPassword + "'");

                                log.Info("Hyper seq 1: url=" + sURL1);

                                var client = new WebClient();

                                // This is supposed to authenticate to the target webserver, but it is notoriously unreliable
                                client.UseDefaultCredentials = true;
                                client.Credentials = new NetworkCredential(sLogin, sPassword);
                                // Note that if the login/password are wrong, the user will get a 401 popup

                                // No point in doing the Hypermedia sequence on every call, so we can
                                // skip this bit if URL3 is already set.
                                if (URL3.Length < 2) {

                                    string sElement1 = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.element1") as string;
                                    string sElement2 = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.element2") as string;
                                    log.Info("Hypermedia Element1=" + sElement1 + "  Element2=" + sElement2);
                                    
                                    string sRes1 = client.DownloadString(sURL1);

                                    string sURL2 = sGetElement( sRes1, sElement1 );
                                    if (sURL2.Length < 3) log.Info("Cant find element " + sElement1 + " in " + sRes1);
                                    log.Info("Hyper seq 2: url=" + sURL2);
                                    string sRes2 = client.DownloadString(sURL2);

                                    URL3 = sGetElement( sRes2, sElement2 );
                                    if (URL3.Length < 3) log.Info("Cant find element " + sElement2 + " in " + sRes2);
                                }
                                log.Info("Hyper seq 3: url=" + URL3);

                                /*
                                 * Construct the query string for POST to URL3
                                 */
                                int iKVP = 0;
                                bool bKVPgood = true;
                                string sVal, sParams, sParam, sKVPName1, sKVPName2;
                                object oKVP;
                                
                                sParams = "ConnID=" + sConnid + "&TMRID=" + sPerson;
                                for (iKVP=1; iKVP<=64; iKVP++) {
                                    sParam = ContainerAccessPoint.Container.Resolve<IConfigManager>().GetValue("hypermedia.param"+iKVP) as string;
                                    if (sParam==null) break;
                                    if (!sParam.Contains(",")) break;
                                    sKVPName2 = "";
                                    sKVPName1 = sParam.Split(',')[1];
                                    if (sParam.Split(',').Length > 2) sKVPName2 = sParam.Split(',')[2];
                                    log.Info("KVP " + sKVPName1 + " " +sKVPName2);
                                    oKVP = ixnMain.GetAttachedData(sKVPName1);
                                    if (oKVP == null) {
                                        log.Info("KVP '" + sKVPName1 + "' not set");
                                        if (sKVPName2.Length > 1) {
                                            log.Info("using alternative: " + sKVPName2);
                                            oKVP = ixnMain.GetAttachedData(sKVPName2);
                                        }
                                    }
                                    if (oKVP == null) { 
                                        if (sKVPName2.Length > 1) log.Info("KVP alternative '" + sKVPName2 + "' not set neither");
                                        // If any KVP is missing, we regard this as a bad call...
                                        // NOTE: this will be changes for Part two of the project
                                        bKVPgood = false;
                                        break;
                                    } else {
                                        sVal = oKVP.ToString(); 
                                        sParams = sParams + "&" + sParam.Split(',')[0] + "=" + Uri.EscapeDataString(sVal);
                                    }
                                }

                                // Don't do the POST unless we have all the KVP data.
                                if (bKVPgood) {
                                    log.Info("Params:" + sParams);
                                    client.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                                    string sRes3 = client.UploadString(URL3, sParams);
                                    log.Info("result:" + sRes3);
                                    client.Dispose();

                                    /* START BROWSER - or don't, if it's already running. */
                                    if (iProcNum == 0 || Process.GetProcessById(iProcNum) == null) {
                                        /*
                                         We don't bother testing for 404s or other web errors. 
                                         The browser will be popped with the URL already displaying the bad page.
                                          */
                                        Process pBrowser = new Process();
                                        log.Info("Start " + sBrowser + " with url: " + sPopURL);
                                        pBrowser.StartInfo.FileName = sBrowser;
                                        pBrowser.StartInfo.Arguments = sPopURL;
                                        pBrowser.Start();
                                        iProcNum = pBrowser.Id;
                                        log.Info("Browser proc ID=" + iProcNum);
                                        //pBrowser.Start(sBrowser, sPopURL);
                                    } else {
                                        log.Info(sBrowser + " running ("+iProcNum+"). Don't pop.");
                                    }
                                } else {
                                    log.Info("Missing KVPs, so don't POST nor pop browser");
                                    client.Dispose();
                                }
                            }
                        }
                    }
                    catch (Exception ee)  {
                        MessageBox.Show("Error: " + ee.Message);
                        log = ContainerAccessPoint.Container.Resolve<ILogger>();
                        log = log.CreateChildLogger("Hypermedia");
                        log.Info("ERROR: " + ee.Message);
                    }
                }
            }
            // Yes, false. Must be false. DON'T ASK ME WHY !!!!
            return false;

        }


		#region IMySampleView Members

		/// <summary>
		/// Gets or sets the model.
		/// </summary>
		/// <value>The model.</value>
		public IMyExtensionSampleViewModel Model
		{
			get { return this.DataContext as IMyExtensionSampleViewModel; }
			set { this.DataContext = value; }
		}


		#endregion

		#region IView Members

		/// <summary>
		/// Gets or sets the context.
		/// </summary>
		/// <value>The context.</value>
		public object Context { get; set; }

		/// <summary>
		/// Creates this instance.
		/// </summary>
		public void Create()
		{
			ObservableCollection<IMyListItem> collection = new ObservableCollection<IMyListItem>();
			collection.Add(new MyListItem() { LastName = "Doe", FirstName = "John" });
			collection.Add(new MyListItem() { LastName = "Dupont", FirstName = "Marcel" });

			Model.MyCollection = collection;
		}

		/// <summary>
		/// Destroys this instance.
		/// </summary>
		public void Destroy()
		{
		}

		#endregion
		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		#endregion
		MSize _MinSize;
		public MSize MinSize
		{
			get { return _MinSize; }  // (MSize)base.GetValue(MinSizeProperty); }
			set
			{
				_MinSize = value; // base.SetValue(MinSizeProperty, value);
				OnPropertyChanged("MinSize");
			}
		}


        public void Add(IComponent component, string name)
        {
            throw new NotImplementedException();
        }

        public void Add(IComponent component)
        {
            throw new NotImplementedException();
        }

        public ComponentCollection Components
        {
            get { throw new NotImplementedException(); }
        }

        public void Remove(IComponent component)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }


	class MyListItem : IMyListItem
	{

		#region IMyListItem Members

		string firstName;
		public string FirstName
		{
			get
			{
				return firstName;
			}
			set
			{
				if (value != firstName) { firstName = value; OnPropertyChanged("FirstName"); }
			}
		}

		string lastName;
		public string LastName
		{
			get
			{
				return lastName;
			}
			set
			{
				if (value != lastName) { lastName = value; OnPropertyChanged("LastName"); }
			}
		}

		#endregion

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		#endregion


	}
}
