﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using Genesyslab.Desktop.Infrastructure.Commands;
using Genesyslab.Desktop.Infrastructure.DependencyInjection;
using Genesyslab.Desktop.Modules.Core.Model.Interactions;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Desktop.Modules.Voice.Model.Interactions;
using System.Data.SqlClient;
using System.Data;
using System;
using Genesyslab.Enterprise.Commons.Collections;
using System.Diagnostics;
using System.Configuration;
using Genesyslab.Desktop.Modules.Voice.Model.Agents;
using System.Threading;
using Genesyslab.Desktop.Modules.Windows.Views;
using Genesyslab.Desktop.Modules.Windows.Interactions;
using System.Reflection;
using Genesyslab.Desktop.Modules.ExtensionSample.MySample;
using Genesyslab.Desktop.Modules.Contacts.ContactDetail;
using Genesyslab.Desktop.Modules.Contacts.ContactNotepad;
using Genesyslab.Desktop.Modules.Contacts;
using Genesyslab.Desktop.Modules.Contacts.ContactInformation;
using Genesyslab.Desktop.Modules.Contacts.IWInteraction;
using Microsoft.Practices.Unity;
using Genesyslab.Desktop.Modules.Core.Model.Agents;
using System.Text;
using Microsoft.Practices.Composite.Events;
using Genesyslab.Desktop.Infrastructure.Events;
using Genesyslab.Desktop.Modules.OpenMedia.Model.Interactions.Chat;
using Genesyslab.Desktop.Infrastructure.Configuration;
using Genesyslab.Desktop.Infrastructure.ViewManager;


namespace Genesyslab.Desktop.Modules.ExtensionSample.CustomCommand
{
    class BundleCloseCommand : IElementOfCommand
    {
        readonly IObjectContainer container;
        ILogger log;
        ICommandManager commandManager;
        IViewManager viewManager;
        string validationflag = string.Empty;
        public BundleCloseCommand(IObjectContainer container, ICommandManager commandManager1)
        {
            this.container = container;
            this.commandManager = commandManager1;
            // Initialize the trace system
            this.log = container.Resolve<ILogger>();

            // Create a child trace section
            this.log = log.CreateChildLogger("BundleCloseCommand");

            log.Info("Initialise BeforeBundleClose command");
        }

        /// <summary>
        /// Gets the name of the command. This is optional.
        /// </summary>
        /// <value>The command name.</value>
        public string Name { get { return "BundleCloseCommand"; } set { } }        

        /// <summary>
        /// Executes the command.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="progress">The progress.</param>
        /// <returns></returns>
        /// 
        public bool Execute(IDictionary<string, object> parameters, IProgressUpdater progress)
        {
            // To go to the main thread
            if (Application.Current.Dispatcher != null && !Application.Current.Dispatcher.CheckAccess())
            {
                object result = Application.Current.Dispatcher.Invoke(DispatcherPriority.Send, new ExecuteDelegate(Execute), parameters, progress);
                return (bool)result;
            }
            else
            {
                log.Info("Execute on bundle close event...");
                bool result = false;
                string connid = string.Empty;
                string caseId = string.Empty;
                IInteractionsWindow iIntecractionsWindow = default(IInteractionsWindow);
                IInteractionsWindowViewModel iInteractionsWindowViewModel = default(IInteractionsWindowViewModel);
                object objWindow = null;
                try
                {
                    if (parameters != null)
                    {
                        log.Debug("OnBundleClose Keys");
                        foreach (var item in parameters.Keys)
                        {
                            log.DebugFormat("Key Name : {0}", item.ToString());
                            //log.DebugFormat("Type Name : {0}", item.GetType().FullName.ToString());
                        }
                        log.Debug("OnBundleClose Values");
                        foreach (var item in parameters.Values)
                        {
                            log.DebugFormat("Value Name : {0}", item.ToString());
                            log.DebugFormat("Type Name : {0}", item.GetType().FullName.ToString());
                            if (item.GetType().FullName.ToString().Equals("System.Windows.Controls.Button"))
                            {
                                System.Windows.Controls.Button btnBundleClose = item as System.Windows.Controls.Button;
                                log.DebugFormat("btnBundleClose.Content : {0}", btnBundleClose.Content.ToString());
                            }
                        }
                    }
                    IInteractionsBundle interactionBundle = parameters["CommandParameter"] as IInteractionsBundle;
                    if (parameters.ContainsKey("ConfirmParentWindow"))
                    {
                        parameters.TryGetValue("ConfirmParentWindow", out objWindow);
                        //iInteractionsWindow = parameters["ConfirmParentWindow"] as IInteractionsWindow;
                        //if (iInteractionsWindow != null)
                        //    log.Debug("iInteractionsWindow is not null");
                        //else
                        //    log.Debug("iInteractionsWindow is null");

                        if (objWindow != null && objWindow.GetType().FullName.ToString().Equals("Genesyslab.Desktop.Modules.Windows.Interactions.InteractionsWindow"))
                            iIntecractionsWindow = objWindow as IInteractionsWindow;
                    }
                    if (interactionBundle != null)
                    {
                        if (interactionBundle.MainInteraction.Type != null)
                        {
                            KeyValueCollection kv = interactionBundle.MainInteraction.GetAllAttachedData();
                            string strUsername = interactionBundle.MainInteraction.Agent.UserName.ToString();
                            if (kv != null)
                            {
                                string[] array = kv.AllKeys;
                                string entireKVPair = "";
                                for (int cnt = 0; cnt < kv.Count; cnt++)
                                {
                                    string kvpair = kv.GetAsString(array[cnt]);
                                    entireKVPair = entireKVPair + array[cnt] + "=" + kvpair;
                                    if (cnt % 2 == 0)
                                        entireKVPair += Environment.NewLine;
                                    else
                                        entireKVPair += "                 ";
                                }
                                log.DebugFormat("Entire KVP on bundle close event: {0}", entireKVPair);
                                //log.DebugFormat("CallType : {0}", strCallType);
                            }
                            log.Debug("Interaction bundle is not Null");
                            caseId = interactionBundle.MainInteraction.CaseId.ToUpper().ToString();
                            try
                            {
                                log.Debug("Inside checking the Socket Data Validation");
                                log.DebugFormat("Dictionary Count : {0}", GlobalObjects.dictsmartlink.Count.ToString());
                                string outputValue = string.Empty;
                                if (GlobalObjects.dictsmartlink.ContainsKey(interactionBundle.MainInteraction.CaseId.ToString().Trim()))
                                {
                                    GlobalObjects.dictsmartlink.TryGetValue(interactionBundle.MainInteraction.CaseId.ToString().Trim(), out outputValue);
                                }
                                else
                                {
                                    log.Debug("Dict does not contains key : ");
                                }
                                
                                log.DebugFormat("dictISReleaseUpdated Key : {0} --> Value : {1}", interactionBundle.MainInteraction.CaseId.ToString().ToUpper().Trim(), outputValue.ToString());
                                if (!string.IsNullOrEmpty(outputValue) && outputValue.Trim().Equals("true"))
                                    //GlobalObjects.IsSocketDatReceived = true;
                                    validationflag = "true";
                                else
                                    //GlobalObjects.IsSocketDatReceived = false;
                                    validationflag = "false";
                                try
                                {
                                    if ((interactionBundle.MainInteraction.MonitoringMode == SupervisorMode.BargeIn) || (interactionBundle.MainInteraction.MonitoringMode == SupervisorMode.Coaching)
                                        || (interactionBundle.MainInteraction.MonitoringMode == SupervisorMode.SilentMonitoring) || (interactionBundle.MainInteraction.IsObserver == true))
                                    {
                                        log.Debug("Inside Checking mark done flag button ");
                                        log.Debug("validation Flag : "+validationflag);//Added by Niranjan on 07-04-2016
                                        //GlobalObjects.IsSocketDatReceived = true;
                                        validationflag = "true";
                                        //interactionBundle.MainInteraction.SetAttachedData("cti_reasons", "Niranjan");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    log.ErrorFormat("Error at  : {0}", ex.ToString());
                                }
                                log.DebugFormat("Caseid : {0} --> Dictionay Result : {1} --> ", interactionBundle.MainInteraction.CaseId.ToString().ToUpper().Trim(), outputValue.ToString());
                                if (!string.IsNullOrEmpty(validationflag)&& validationflag.Equals("true"))
                                {
                                    result = false;
                                    //GlobalObjects.dictISReleaseUpdated.RemoveSafe(interactionBundle.MainInteraction.CaseId.ToUpper().Trim());
                                    //log.DebugFormat("dictISReleaseUpdated Dictionary Count: {0}", GlobalObjects.dictISReleaseUpdated.Count.ToString());
                                    try
                                    {
                                        //log.Debug("Before making agent ready");
                                        //IAgent agentManager = container.Resolve<IAgent>();
                                        //agentManager.FirstMediaVoice.Ready();
                                        log.Debug("Received Flag and closing Window "+validationflag);
                                        //Genesyslab.Desktop.Modules.ExtensionSample.DispositionCodeEx.DispositionCodeExView disv = default(Genesyslab.Desktop.Modules.ExtensionSample.DispositionCodeEx.DispositionCodeExView);
                                        //string subcat = disv.cmbsubcat.Text.ToString();
                                        //string cat = disv.cmbcat.Text.ToString();
                                        //string reason = disv.cmbreason.Text.ToString();
                                        //string caller = disv.cmbdisp.Text.ToString();
                                        //string remarks = disv.txtRemarks.Text.ToString();

                                    }
                                    catch (Exception s)
                                    {
                                        log.Error("Exception at making agent ready : " + s.ToString());
                                    }
                                }
                                else
                                {
                                    result = true;
                                    //MessageBox.Show("Click the Submit Button from the Right Side", "Mark Done", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                                    ContainerAccessPoint.Container.Resolve<IEventAggregator>().GetEvent<AlertEvent>().Publish(new Alert()
                                    {
                                        Section = interactionBundle.CaseId.ToString(),
                                        Severity = SeverityType.Warning,
                                        Id = "Please update the dispositions before clicking Mark Done.",
                                        ClosedAutomatically = true
                                    });
                                }
                            }
                            catch(Exception ex)
                            {
                                log.Error("Exception at bundle close command :"+ex.ToString());
                            }
                        }
                    }
                }
                catch (Exception excp)
                {
                    log.Debug("Exception at bundle close Event : "+excp.ToString());
                }
                return result;
            }
        }
        delegate bool ExecuteDelegate(IDictionary<string, object> parameters, IProgressUpdater progressUpdater);
    }
}
