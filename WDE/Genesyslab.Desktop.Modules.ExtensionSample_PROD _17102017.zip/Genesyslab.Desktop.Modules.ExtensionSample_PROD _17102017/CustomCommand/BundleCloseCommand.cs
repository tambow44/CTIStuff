﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using Genesyslab.Desktop.Infrastructure.Commands;
using Genesyslab.Desktop.Infrastructure.DependencyInjection;
using Genesyslab.Desktop.Modules.Core.Model.Interactions;
using Genesyslab.Platform.Commons.Logging;
using System;
using Genesyslab.Enterprise.Commons.Collections;
using Genesyslab.Desktop.Infrastructure.ViewManager;
using Genesyslab.Desktop.Modules.Core.Model.Agents;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Desktop.Modules.ExtensionSample.DispositionCodeEx;



namespace Genesyslab.Desktop.Modules.ExtensionSample.CustomCommand
{
    class BundleCloseCommand : IElementOfCommand
    {
        readonly IObjectContainer container;
        ILogger log;
        ICommandManager commandManager;
        
        string validationflag = string.Empty;
          // Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.IConfService cfgService;
        //Genesyslab.Desktop.Modules.Core.SDK.Configurations.IConfigurationService configurationService = ContainerAccessPoint.Container.Resolve<IConfigurationService>();

           


        public BundleCloseCommand(IObjectContainer container, ICommandManager commandManager1)
        {
            this.container = container;
            this.commandManager = commandManager1;

          
            // Initialize the trace system
            
            this.log = container.Resolve<ILogger>();

            // Create a child trace section
            this.log = log.CreateChildLogger("BundleCloseCommand");

            log.Info("Initialise BeforeBundleClose command");
        }

        /// <summary>
        /// Gets the name of the command. This is optional.
        /// </summary>
        /// <value>The command name.</value>
        public string Name { get { return "BundleCloseCommand"; } set { } }        

        /// <summary>
        /// Executes the command.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="progress">The progress.</param>
        /// <returns></returns>
        /// 
        public bool Execute(IDictionary<string, object> parameters, IProgressUpdater progress)
        {
            // To go to the main thread

          
           
            if (Application.Current.Dispatcher != null && !Application.Current.Dispatcher.CheckAccess())
            {
                object result = Application.Current.Dispatcher.Invoke(DispatcherPriority.Send, new ExecuteDelegate(Execute), parameters, progress);
                return (bool)result;
            }
            else
            {
                log.Info("Execute on bundle close event...");
                bool result = false;
                string connid = string.Empty;
                string CaseId = string.Empty;
                //IInteractionsWindow iIntecractionsWindow = default(IInteractionsWindow);
               // IInteractionsWindowViewModel iInteractionsWindowViewModel = default(IInteractionsWindowViewModel);
                
                try
                {
                    if (parameters != null)
                    {
                        log.Debug("OnBundleClose Keys");
                        foreach (var item in parameters.Keys)
                        {
                            log.DebugFormat("Key Name : {0}", item.ToString());
                            //log.DebugFormat("Type Name : {0}", item.GetType().FullName.ToString());
                        }
                        log.Debug("OnBundleClose Values");
                        foreach (var item in parameters.Values)
                        {
                            log.DebugFormat("Value Name : {0}", item.ToString());
                            log.DebugFormat("Type Name : {0}", item.GetType().FullName.ToString());
                            if (item.GetType().FullName.ToString().Equals("System.Windows.Controls.Button"))
                            {
                                System.Windows.Controls.Button btnBundleClose = item as System.Windows.Controls.Button;
                                log.DebugFormat("btnBundleClose.Content : {0}", btnBundleClose.Content.ToString());
                            }
                        }
                    }

                    IInteraction ITN = default(IInteraction);
                    IInteractionsBundle interactionBundle = parameters["CommandParameter"] as IInteractionsBundle;
                    ITN = interactionBundle.MainInteraction;

                    CaseId = interactionBundle.MainInteraction.CaseId;

                    log.Debug("CasedId : " + CaseId);






                    //   String Disposition = DispositionCodeStaticClass.ParentDisposition + DispositionCodeStaticClass.SubDisposition + DispositionCodeStaticClass.SecondSubDisposition;
                    // String Disposition = DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"] + DispositionCodeStaticClass.StClass[CaseId + ".SubDisposition"] + DispositionCodeStaticClass.StClass[CaseId + ".SecondSubDisposition"];


                    log.Info("ParentDispositionCount :" + DispositionCodeStaticClass.StClass[CaseId + ".ParentDispositionCount"]);
                    log.Info("ParentDisposition :" + DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"]);

                    DispositionCodeStaticClass.ParentDispositionCount = Convert.ToInt32(DispositionCodeStaticClass.StClass[CaseId + ".ParentDispositionCount"]);


                    if (DispositionCodeStaticClass.ParentDispositionCount > 0 && DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"] != "")
                    {
                        try
                        {
                            DispositionCodeStaticClass.IsInboundCall = Convert.ToBoolean(DispositionCodeStaticClass.StClass[CaseId + ".IsInboundCall"]);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching IsInboundCall" + ex.Message);
                        }
                        try
                        {
                            DispositionCodeStaticClass.ParentDisposition = DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"];
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching ParentDisposition" + ex.Message);
                        }
                        try
                        {
                            DispositionCodeStaticClass.SubDisposition = DispositionCodeStaticClass.StClass[CaseId + ".SubDisposition"];
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching SubDisposition" + ex.Message);
                        }
                        try
                        {
                            DispositionCodeStaticClass.SecondSubDisposition = DispositionCodeStaticClass.StClass[CaseId + ".SecondSubDisposition"];
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching SecondSubDisposition" + ex.Message);
                        }
                        try
                        {
                            DispositionCodeStaticClass.ParentDispositionCount = Convert.ToInt32(DispositionCodeStaticClass.StClass[CaseId + ".ParentDispositionCount"]);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching ParentDispositionCount" + ex.Message);
                        }
                        try
                        {
                            DispositionCodeStaticClass.SubDispositionCount = Convert.ToInt32(DispositionCodeStaticClass.StClass[CaseId + ".SubDispositionCount"]);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching SubDispositionCount" + ex.Message);
                        }
                        try
                        { 
                        DispositionCodeStaticClass.SecondSubDispositionCount = Convert.ToInt32(DispositionCodeStaticClass.StClass[CaseId + ".SecondSubDispositionCount"]);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Fetching SecondSubDispositionCount" + ex.Message);
                        }


                    }
                    else
                    {
                        MessageBox.Show("You cannot close the Interaction without selecting a Disposition Code", "Disposition Code", MessageBoxButton.OK);
                        return true;
                    }



                    if (DispositionCodeStaticClass.IsInboundCall == true || interactionBundle.MainInteraction.Type == "InteractionWorkItem")
                    {
                       if ((DispositionCodeStaticClass.ParentDisposition == "" && DispositionCodeStaticClass.ParentDispositionCount > 0) || (DispositionCodeStaticClass.SubDisposition == "" && DispositionCodeStaticClass.SubDispositionCount > 0) || (DispositionCodeStaticClass.SecondSubDisposition == "" && DispositionCodeStaticClass.SecondSubDispositionCount > 0))
                        {
                                  
                                MessageBox.Show("You cannot close the Interaction without selecting a Disposition Code", "Disposition Code", MessageBoxButton.OK);
                                return true;
                         }
                        }

                    String Disposition = DispositionCodeStaticClass.ParentDisposition + DispositionCodeStaticClass.SubDisposition + DispositionCodeStaticClass.SecondSubDisposition;
                    log.Debug("Disposition :" + Disposition);

                    if (interactionBundle != null)
                    {
                        if (interactionBundle.MainInteraction.Type != null)
                        {

                            if (interactionBundle.MainInteraction.Type == "InteractionWorkItem")
                            {
                                KeyValueCollection kv = interactionBundle.MainInteraction.GetAllAttachedData();
                                string strUsername = interactionBundle.MainInteraction.Agent.UserName.ToString();
                                if (kv != null)
                                {
                                    string[] array = kv.AllKeys;
                                    string entireKVPair = "";
                                    for (int cnt = 0; cnt < kv.Count; cnt++)
                                    {
                                        string kvpair = kv.GetAsString(array[cnt]);
                                        entireKVPair = entireKVPair + array[cnt] + "=" + kvpair;
                                        if (cnt % 2 == 0)
                                            entireKVPair += Environment.NewLine;
                                        else
                                            entireKVPair += "                 ";
                                    }
                                    log.DebugFormat("Entire KVP on bundle close event: {0}", entireKVPair);
                                    //log.DebugFormat("CallType : {0}", strCallType);
                                }




                                //String Disposition = Application.Current.Properties["ParentDisposition"].ToString() + Application.Current.Properties["SubDisposition"].ToString() + Application.Current.Properties["SecondSubDisposition"].ToString();
                                //String Disposition = "500503";
                                
                                    

                                  

                                log.Debug("Setting Disposition Code " + Disposition);

                                interactionBundle.MainInteraction.SetAttachedData("Business Result", Disposition);
                              

                                log.Debug("setting Business result" + Disposition);

                                if (DispositionCodeStaticClass.courts != "")
                                {
                                    log.Debug("setting courts attached data" + DispositionCodeStaticClass.courts);
                                    interactionBundle.MainInteraction.SetAttachedData("Courts", DispositionCodeStaticClass.courts);
                                }

                                //     interactionBundle.MainInteraction.SelectDispositionCodeSetAttachedData(Disposition);

                                //     log.Debug("setting Disposition Code" + Disposition);


                                DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDisposition");
                               DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDisposition");
                                DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDisposition");
                                DispositionCodeStaticClass.courts = "";
                                DispositionCodeStaticClass.ParentDisposition = "";
                                DispositionCodeStaticClass.SubDisposition = "";
                                DispositionCodeStaticClass.SecondSubDisposition = "";
                                DispositionCodeStaticClass.courts = "";

                               result = false;
                            }
                            else if (interactionBundle.MainInteraction.Type == "InteractionVoice" || interactionBundle.MainInteraction.Type == "voice")
                            {
                                CaseId = interactionBundle.MainInteraction.CaseId.ToUpper().ToString();


                                try
                                {
                                    if (ITN != null)
                                    {
                                        String Connid = interactionBundle.MainInteraction.GetAttachedData("CONN_ID").ToString();
                                        IAgent agentManager = ContainerAccessPoint.Container.Resolve<IAgent>();
                                        log.Debug("agent manager is not null");
                                        IMedia agent = agentManager.FirstMediaVoice;
                                       
                                        String Extension = "";
                                        Genesyslab.Desktop.Modules.Core.Model.Agents.IPlace place = agentManager.Place;

                                       
                                        if (place != null)
                                        {
                                            log.DebugFormat("Place: {0} ", place.PlaceName);
                                        }
                                        else
                                            log.Debug("Place object is null");

                                        Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgPlace cfgPlace = place.ConfPlace;
                                        if (cfgPlace != null)
                                        {
                                            ICollection<Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgDN> cfgDNs = default(ICollection<Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgDN>);
                                            cfgDNs = cfgPlace.DNs;
                                            if (cfgDNs != null)
                                            {
                                                IEnumerator<Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgDN> dnEnum = cfgDNs.GetEnumerator();
                                                Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgDN dn;
                                                while (dnEnum.MoveNext())
                                                {
                                                    dn = dnEnum.Current;
                                                    if (dn != null)
                                                    {
                                                        log.DebugFormat("Extension Name : {0} ", dn.Name);
                                                        log.DebugFormat("Extension NUmber :{0} ", dn.Number);
                                                        //log.DebugFormat("Extension Name : {0} ", );
                                                        Extension = dn.Number;
                                                        break;
                                                    }
                                                }
                                            }
                                            else
                                                log.Debug("cfg dn enumerator is null");
                                        }

                                       
                                        Enterprise.Model.Channel.IClientChannel channel = agent.Channel;
                                        Platform.Commons.Protocols.IProtocol protocol = channel.Protocol;
                                        Platform.Voice.Protocols.ConnectionId thisConnid = new Platform.Voice.Protocols.ConnectionId(Connid);
                                        Platform.Commons.Collections.KeyValueCollection kvc = new Genesyslab.Platform.Commons.Collections.KeyValueCollection();
                                        Platform.Voice.Protocols.TServer.Requests.Special.RequestSendEvent request = Genesyslab.Platform.Voice.Protocols.TServer.Requests.Special.RequestSendEvent.Create();
                                        // log.Debug("str connid : " + _ixnvoice.TConnectionId.ToString());


                                        // String Disposition = DispositionCodeStaticClass.ParentDisposition + DispositionCodeStaticClass.SubDisposition + DispositionCodeStaticClass.SecondSubDisposition;
                                       
                                        kvc.Add("Business Result", Disposition);

                                        if (DispositionCodeStaticClass.courts != "")
                                        {
                                            
                                            kvc.Add("Courts", DispositionCodeStaticClass.courts);
                                            log.Debug("setting Courts attached data" + DispositionCodeStaticClass.courts);
                                        }

                                        Platform.Voice.Protocols.TServer.CommonProperties userevent = Platform.Voice.Protocols.TServer.CommonProperties.Create();
                                        if (thisConnid != null)
                                            userevent.ConnID = thisConnid;
                                        userevent.UserData = kvc;

                                        userevent.ThisDN = Extension;
                                        userevent.UserEvent = Platform.Voice.Protocols.TServer.Events.EventUserEvent.MessageId;
                                        request.UserEvent = userevent;
                                        log.Debug("Setting Voice Disposition Code " + Disposition);
                                        protocol.Request(request);
                                        protocol.Send(request);
                                       
                                    }


                                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDisposition");
                                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDisposition");
                                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDisposition");
                                    DispositionCodeStaticClass.ParentDisposition = "";
                                    DispositionCodeStaticClass.SubDisposition = "";
                                    DispositionCodeStaticClass.SecondSubDisposition = "";
                                    DispositionCodeStaticClass.courts = "";
                                   
                                }
                                catch (Exception Ex)
                                {
                                    log.Debug("Exception while setting disposition for voice");
                                }
                            }

                                                }
                    }
                }
                catch (Exception excp)
                {
                    log.Debug("Exception at bundle close Event : "+excp.ToString());
                }
                return result;
            }
        }
        delegate bool ExecuteDelegate(IDictionary<string, object> parameters, IProgressUpdater progressUpdater);
    }
}
