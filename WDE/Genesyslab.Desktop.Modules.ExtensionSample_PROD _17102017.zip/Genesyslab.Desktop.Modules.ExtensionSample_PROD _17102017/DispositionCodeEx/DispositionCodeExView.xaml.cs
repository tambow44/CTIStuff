﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using Genesyslab.Desktop.Infrastructure.ViewManager;
using Genesyslab.Desktop.Modules.Core.Model.Interactions;
using Genesyslab.Desktop.Modules.Windows.Views.Interactions.CaseView.DispositionCodeView;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries;
using Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects;
using Genesyslab.Desktop.Infrastructure.DependencyInjection;
using Genesyslab.Desktop.Infrastructure.StatFormatting;
using Genesyslab.Desktop.Modules.Core.SDK.Configurations;
using Genesyslab.Platform.Commons.Collections;
using Genesyslab.Desktop.Modules.OpenMedia.Model.Interactions;
using System.Windows.Data;
using System.Collections.ObjectModel;
using System.Linq;
using Genesyslab.Desktop.Infrastructure.Configuration;
using Genesyslab.Platform.Commons.Logging;
using Genesyslab.Desktop.Modules.Core.Model.Agents;

namespace Genesyslab.Desktop.Modules.ExtensionSample.DispositionCodeEx
{
    /// <summary>
    /// Interaction logic for DispositionCodeExView.xaml
    /// </summary>
    public partial class DispositionCodeExView : UserControl, IDispositionCodeView
	{
        ILogger log;
        readonly IViewManager viewManager;
        readonly IObjectContainer container;
        bool isEnabledChangeAttachedData;
       
        Boolean IsParentLoaded = false;
        
        Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.IConfService cfgService;
        Genesyslab.Desktop.Modules.Core.SDK.Configurations.IConfigurationService configurationService = ContainerAccessPoint.Container.Resolve<IConfigurationService>();
        

        List<KeyValuePair<string,string>> KvListParent = new List<KeyValuePair<string, string>>();
        List<KeyValuePair<string, string>> KvListSub = new List<KeyValuePair<string, string>>();
        List<KeyValuePair<string, string>> KvpList = new List<KeyValuePair<string, string>>();
        List<KeyValuePair<string, string>> KvpType = new List<KeyValuePair<string, string>>();
        String CaseId = "";


        public DispositionCodeExView(IDispositionCodeViewModel dispositionCodePresentationModel, IViewManager viewManager, IObjectContainer container)
		{
            
			this.viewManager = viewManager;
           
			this.Model = dispositionCodePresentationModel;
            this.container = container;

            // Initialize the trace system
            this.log = container.Resolve<ILogger>();

            // Create a child trace section
            this.log = log.CreateChildLogger("DispositionCodeExViewLog");

            log.Info("Initialise DispositionCodeExViewLog command");
            

            isEnabledChangeAttachedData = true;

			InitializeComponent();


            

            var interactionManager = ContainerAccessPoint.Container.Resolve<IInteractionManager>();

            if (interactionManager != null)
            {
                //Receive interaction events
           //     interactionManager.InteractionEvent += interactionManager_InteractionEvent;
            }
            
            Width = Double.NaN;
			Height = Double.NaN;
                      
        }

        

        #region IView Members

        public object Context { get; set; }

        public int ParentDispositionCount
        {
            get => ParentDisposition.Items.Count;
        }

        public int SecondDispositionCount
        {
            get => SubDisposition.Items.Count;
        }
        public int SecondSubDispositionCount
        {
            get => SecondSubDisposition.Items.Count;
        }

        public void Create()
		{
            LoadCourtData();
            cmbCourts.Visibility = Visibility.Hidden;
            lblCourts.Visibility = Visibility.Hidden;
            try
            {
                IDictionary<string, object> contextDictionary = (Context as IDictionary<string, object>);
                object caseObject;

                log.Info("Printing Context : " + contextDictionary.ToString());

                if (contextDictionary.TryGetValue("Case", out caseObject))
                {
                    ICase theCase = caseObject as ICase;
                    // Get the URL from the interaction attached data
                    string DNIS = "";
                    String MediaType = "";
                   

                    try
                    {
                        DNIS = theCase.MainInteraction.GetAttachedData("DNIS") as string;
                        log.Info("DNIS Received : " + DNIS);
                    }
                    catch (Exception ex)
                    {
                        log.Debug("Error While Getting DNIS " + ex.Message);
                    }
                    try
                    {
                        MediaType = theCase.MainInteraction.Type as String;
                       
                        log.Info("MediaType : " + MediaType);
                    }
                    catch (Exception ex)
                    {
                        log.Debug("Error While Getting MediaType " + ex.Message);
                    }

                    try
                    {
                        CaseId = theCase.MainInteraction.CaseId;
                        
                        log.Info("CaseId : " + CaseId);
                    }
                    catch (Exception ex)
                    {
                        log.Debug("Error While Getting Conn_ID " + ex.Message);
                    }
                   


                    String TaskSkill = "0";
                    String VoiceSkill = "0";
                    List<String> TaskSkillList = new List<string>();
                    List<String> VoiceSkillList = new List<string>();

                    IAgent agentManager = ContainerAccessPoint.Container.Resolve<IAgent>();
                    cfgService = configurationService.ConfigService;
                    Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries.CfgTransactionQuery transactionquery = new CfgTransactionQuery();
                    Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.CfgObjects.CfgAgentInfo agentInfo = agentManager.ConfPerson.AgentInfo;

                    int dbid = 755;
                    transactionquery.Dbid = dbid;

                    CfgTransaction configTransaction = cfgService.RetrieveObject<CfgTransaction>(transactionquery);

                        if (MediaType == "InteractionWorkItem")
                       {
                        string ProductType = "";
                        try
                        {
                           ProductType = theCase.MainInteraction.GetAttachedData("IWD_ext_productType").ToString();
                           log.Debug("ProductType : " + ProductType);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Getting ProductType " + ex.Message);
                        }


                        KeyValueCollection TaskTypeQuery = configTransaction.UserProperties.GetAsKeyValueCollection("TaskTypes");

                        foreach (string optionName in TaskTypeQuery.Keys)
                        {
                            KvpType.Add(new KeyValuePair<string, string>(optionName, TaskTypeQuery[optionName].ToString()));
                        }

                        cmbType.ItemsSource = KvpType;
                        cmbType.DisplayMemberPath = "Key";
                        cmbType.SelectedValuePath = "Value";

                        if (configTransaction != null)
                        {
                            KeyValueCollection kvTransaction = configTransaction.UserProperties.GetAsKeyValueCollection("ProductType");
                            String StrProductType = kvTransaction.GetAsString(ProductType);
                            if (StrProductType != "")
                            {
                                cmbType.SelectedIndex = cmbType.Items.IndexOf(StrProductType);
                                cmbType.Text = StrProductType;
                            }
                        }

                       

                        /*  IConfigManager configManager = container.Resolve<IConfigManager>();
                          if(configManager!=null)
                          {
                              string keyname = "";
                              keyname= configManager.GetValue("DispositionCode.label").ToString();
                              MessageBox.Show("DN1 " + keyname);
                          }*/

                        //     IInteractionOpenMedia interactionOm = contextDictionary["Interaction"] as IInteractionOpenMedia;



                    }
                    else if(MediaType == "InteractionVoice" || MediaType == "voice")
                    {
                        string SystemCallType = "";
                        object objcalltype;
                        string ServiceType = "";
                        try
                        {
                            objcalltype = theCase.MainInteraction.GetAttributeInteraction("AttributeCallType");
                            SystemCallType = theCase.MainInteraction.GetIWCallType();
                            log.Debug("SystemCallType : " + SystemCallType);
                            log.Debug("ObjectCallType : " + Formatting.GetStringValue(SystemCallType));
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Getting AttributeCallType " + ex.Message);
                        }
                        try
                        {
                            ServiceType = theCase.MainInteraction.GetAttachedData("ServiceType").ToString();
                            log.Debug("ServiceType : " + ServiceType);
                        }
                        catch (Exception ex)
                        {
                            log.Debug("Error While Getting ServiceType " +ex.Message );
                        }

                        if (ServiceType != "")
                        {
                            //DispositionCodeStaticClass.IsInboundCall = true;
                            if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".IsInboundCall"))
                            {
                                DispositionCodeStaticClass.StClass.Remove(CaseId + ".IsInboundCall");
                                DispositionCodeStaticClass.StClass.Add(CaseId + ".IsInboundCall", "true");
                            }
                            else
                            {
                                DispositionCodeStaticClass.StClass.Add(CaseId + ".IsInboundCall", "true");
                            }
                        
                            if (configTransaction != null)
                            {
                                log.Debug("Inside Voice Skill");
                                KeyValueCollection VoiceTypeQuery = configTransaction.UserProperties.GetAsKeyValueCollection("VoiceTypes");
                                foreach (string optionName in VoiceTypeQuery.Keys)
                                {
                                    KvpType.Add(new KeyValuePair<string, string>(optionName, VoiceTypeQuery[optionName].ToString()));
                                }

                                cmbType.ItemsSource = KvpType;
                                cmbType.DisplayMemberPath = "Key";
                                cmbType.SelectedValuePath = "Value";

                                if (ServiceType == "")
                                {
                                    KeyValueCollection kvTransaction = configTransaction.UserProperties.GetAsKeyValueCollection("DNIS_Queue");
                                    KeyValueCollection kvVisibleCourts = configTransaction.UserProperties.GetAsKeyValueCollection("DNIS_Courts");
                                    String StrQueue = kvTransaction.GetAsString(DNIS);
                                    String strCourtVisible = kvVisibleCourts.GetAsString(DNIS);
                                    if (strCourtVisible == "1")
                                    {
                                        cmbCourts.Visibility = Visibility.Visible;
                                        lblCourts.Visibility = Visibility.Visible;
                                    }
                                    if (StrQueue != "")
                                    {
                                        cmbType.SelectedIndex = cmbType.Items.IndexOf(StrQueue);
                                        cmbType.Text = StrQueue;
                                    }
                                }
                                else
                                {
                                    log.Debug("Inside Service Type Mapping");
                                    KeyValueCollection kvVisibleCourts = configTransaction.UserProperties.GetAsKeyValueCollection("ServiceTypeMapping");
                                    KeyValueCollection ServiceTypeCoutsVisibility = configTransaction.UserProperties.GetAsKeyValueCollection("ServiceTypeCoutsVisibility");
                                    String strServiceType = kvVisibleCourts.GetAsString(ServiceType);
                                    String strCourtVisible = ServiceTypeCoutsVisibility.GetAsString(ServiceType);

                                    if (strCourtVisible == "1")
                                    {
                                        log.Debug("Setting Courts Visible");
                                        cmbCourts.Visibility = Visibility.Visible;
                                        lblCourts.Visibility = Visibility.Visible;
                                    }
                                    if (strServiceType != "")
                                    {
                                        log.Debug("Setting ServiceType :" + strServiceType);
                                        cmbType.SelectedIndex = cmbType.Items.IndexOf(strServiceType);
                                        cmbType.Text = strServiceType;
                                    }
                                }
                            }
                        }
                        else
                        {
                          //  DispositionCodeStaticClass.IsInboundCall = false;
                            if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".IsInboundCall"))
                            {
                                DispositionCodeStaticClass.StClass.Remove(CaseId + ".IsInboundCall");
                                DispositionCodeStaticClass.StClass.Add(CaseId + ".IsInboundCall", "false");
                            }
                            else
                            {
                                DispositionCodeStaticClass.StClass.Add(CaseId + ".IsInboundCall", "false");
                            }
                            HideDispositionControls();
                        }
                    }
                    else
                    {
                        
                    }
                    
                }
            }
            catch (Exception ex)
            {
              log.Debug("error whiule loading data " + ex.Message);
            }

            Model.Load();

           
        }

       
        public void HideDispositionControls()
        {
            cmbType.Visibility = Visibility.Hidden;
            lblType.Visibility = Visibility.Hidden;
            cmbCourts.Visibility = Visibility.Hidden;
            lblCourts.Visibility = Visibility.Hidden;
            schParent.Visibility = Visibility.Hidden;
            schSecond.Visibility = Visibility.Hidden;
            schSub.Visibility = Visibility.Hidden;
            ParentDisposition.Visibility = Visibility.Hidden;
            SubDisposition.Visibility = Visibility.Hidden;
            SecondSubDisposition.Visibility = Visibility.Hidden;
        }
      

		public void Destroy()
		{
            if (Model.Interaction != null)
            {
                INotifyPropertyChanged notifyPropertyChanged = Model.Interaction as INotifyPropertyChanged;
                if (notifyPropertyChanged != null)
                    notifyPropertyChanged.PropertyChanged -= new PropertyChangedEventHandler(notifyPropertyChanged_PropertyChanged);
            }
			Model.Unload();
		}

		#endregion

		#region IDispositionCodeView Members

		public IDispositionCodeViewModel Model
		{
			get { return this.DataContext as IDispositionCodeViewModel; }
			set { this.DataContext = value; }

		}

		#endregion

		void notifyPropertyChanged_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
            if (!Dispatcher.CheckAccess())
                Dispatcher.BeginInvoke(new PropertyChangedEventHandler(notifyPropertyChanged_PropertyChanged), sender, e);
            else
            {
				if (e.PropertyName == "IsIdle")
				{
					isEnabledChangeAttachedData = false;

					if (!Model.Interaction.IsChildInteraction)
					{
						if (Model.Interaction.DispositionCode != null)
						{
							if (Model.Interaction.DispositionCode.IsReadOnlyOnIdle)
							{
								//listOfDispositionCodeValueItemsControl.IsEnabled = false;
               
							}
						}
					}
				}
            }
		}

		private void radioButton_Checked(object sender, RoutedEventArgs e)
        {
            IInteraction interaction = Model.Interaction;

            if (isEnabledChangeAttachedData)
            {
                if (Model.Interaction != null)
                    if (Model.Interaction.DispositionCode.SelectedDispositionCodeValue != null)
                        interaction.SetAttachedData(interaction.DispositionCode.CodeKeyName, interaction.DispositionCode.SelectedDispositionCodeValue.Name);
                    else
                        interaction.RemoveAttachedData(interaction.DispositionCode.CodeKeyName);
            }
        }

        public void LoadCourtData()
        {
            try
            {
                cfgService = configurationService.ConfigService;

                Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries.CfgTransactionQuery transactionquery = new CfgTransactionQuery();
                int dbid = 755;

                transactionquery.Dbid = dbid;
                List<KeyValuePair<string, string>> kvCourtsList = new List<KeyValuePair<string, string>>();


                CfgTransaction configTransaction = cfgService.RetrieveObject<CfgTransaction>(transactionquery);


                if (configTransaction != null)
                {

                    KeyValueCollection kvTransaction = configTransaction.UserProperties.GetAsKeyValueCollection("Courts");

                    if (kvTransaction != null)
                    {

                        try
                        {
                            cmbCourts.ItemsSource = null;
                        }
                        catch (Exception ax)
                        { }

                        kvCourtsList.Clear();


                        foreach (string optionName in kvTransaction.Keys)
                        {

                            kvCourtsList.Add(new KeyValuePair<string, string>(optionName, kvTransaction[optionName].ToString()));
                            // iListbox.Items.Insert(Convert.ToInt32(optionName), kvTransaction[optionName]);
                        }

                        cmbCourts.ItemsSource = kvCourtsList;
                        cmbCourts.DisplayMemberPath = "Value";
                        cmbCourts.SelectedValuePath = "Key";



                    }

                }
            }
            catch (Exception ex)
            {
                log.Debug("Error while loading courts data " + ex.Message);
            }
        }
       

        private void ParentDisposition_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //clearing SubDisposition and SecondSubDisposition
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SubDisposition"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDisposition");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDisposition","");
                }
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDisposition"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDisposition");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDisposition", "");
                }

                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SubDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDispositionCount","0");
                }
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDispositionCount", "0");
                }
                //clearing SubDisposition and SecondSubDisposition

                AddDispositionCodeToList(0, 2, ParentDisposition.SelectedValue.ToString(), Convert.ToInt32(cmbType.SelectedValue), "L2", SubDisposition,  KvListSub);

                KvpList.Clear();
                SecondSubDisposition.ItemsSource = KvpList;
                SecondSubDisposition.SelectedValuePath = "Value";
                SecondSubDisposition.DisplayMemberPath = "Key";


                log.Info("ParentCode :" + ParentDisposition.SelectedValue.ToString());

               

                if (SubDisposition.Items.Count > 1)
                {
                    if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".ParentDisposition"))
                    {
                        DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDisposition");
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", ParentDisposition.SelectedValue.ToString());
                    }
                    else
                    {
                        
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", ParentDisposition.SelectedValue.ToString());
                                             
                    }
                    
               //     DispositionCodeStaticClass.ParentDisposition = ParentDispostion.SelectedValue.ToString();
                }
                else
                {
                    //DispositionCodeStaticClass.ParentDisposition = ParentDispostion.SelectedValue.ToString() + "0000";
                    if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".ParentDisposition"))
                    {
                        DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDisposition");
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", ParentDisposition.SelectedValue.ToString() + "0000");
                    }
                    else
                    {
                        
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", ParentDisposition.SelectedValue.ToString() + "0000");
                    }

                }


                

                //DispositionCodeStaticClass.SubDispositionCount = SubDisposition.Items.Count;
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SubDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDispositionCount", SubDisposition.Items.Count.ToString());
                }
                else
                {
                    
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDispositionCount", SubDisposition.Items.Count.ToString());
                }
                log.Info("ParentDisposition :" + DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"]);
                log.Info("SubDispositionCount :" + DispositionCodeStaticClass.StClass[CaseId + ".SubDispositionCount"]);

            

              

            }
            catch (Exception Ex)
            {
                log.Info("Parent Disposition Selection Exception " + Ex.Message);
            }

            
        }

        private void SubDisposition_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            try
            {

                //Clearing SecondSubDisposition box and count
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDisposition"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDisposition");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDisposition","");
                }
                
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDispositionCount","0");
                }

                String SubDispositionCode = "";
                if (cmbType.Text == "DC_Trib")
                {
                    AddDispositionCodeToList(0, 2, "", Convert.ToInt32(cmbType.SelectedValue), "L3_01", SecondSubDisposition,  KvpList);
                    SubDispositionCode = SubDisposition.SelectedValue.ToString();
                }
                else
                {
                    AddDispositionCodeToList(0, 4, SubDisposition.SelectedValue.ToString(), Convert.ToInt32(cmbType.SelectedValue), "L3", SecondSubDisposition,  KvpList);
                    SubDispositionCode = SubDisposition.SelectedValue.ToString();
                    
                }
                log.Info("SubDisposition Code :" + SubDispositionCode);

               



                if (SecondSubDisposition.Items.Count > 1)
                {
                    // DispositionCodeStaticClass.SubDisposition = SubDispositionCode.Substring(2, 2);
                    if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SubDisposition"))
                    {
                        DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDisposition");
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDisposition", SubDispositionCode.Substring(2, 2));
                    }
                    else
                    {
                       
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDisposition", SubDispositionCode.Substring(2, 2));
                    }
                }
                else
                {
                    // DispositionCodeStaticClass.SubDisposition = SubDispositionCode.Substring(2, 2) + "00";
                    if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SubDisposition"))
                    {
                        DispositionCodeStaticClass.StClass.Remove(CaseId + ".SubDisposition");
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDisposition", SubDispositionCode.Substring(2, 2) + "00");
                    }
                    else
                    {
                        
                        DispositionCodeStaticClass.StClass.Add(CaseId + ".SubDisposition", SubDispositionCode.Substring(2, 2) + "00");
                    }
                }
                log.Info("SubDisposition Code After Trim :" + DispositionCodeStaticClass.StClass[CaseId + ".SubDisposition"]);

               


                // DispositionCodeStaticClass.SecondSubDispositionCount = SecondSubDisposition.Items.Count;
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDispositionCount", SecondSubDisposition.Items.Count.ToString());
                }
                else
                {
                    
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDispositionCount", SecondSubDisposition.Items.Count.ToString());
                }
            }
            catch (Exception ex)
            {
                log.Debug("Exception While selecting SubDisposition " + ex.Message);
            }
        }

        private void SubDisposition_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
                
          
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
            IInteraction interaction = Model.Interaction;


                if (Model.Interaction != null)
                {
                    MessageBox.Show("Setting Attached Data");
                    // interaction.SetAttachedData("WRAPUP_CODE", "0" + ParentDispostion.SelectedIndex + "0" + SubDisposition.SelectedIndex + "0" + SecondSubDisposition.SelectedIndex);
                    interaction.SetAttachedData("DispositionCode_CRO", "0" + ParentDisposition.SelectedIndex + "0" + SubDisposition.SelectedIndex + "0" + SecondSubDisposition.SelectedIndex);
                    MessageBox.Show("Attached Data WRAPUP_CODE : " + "0" + ParentDisposition.SelectedIndex + "0" + SubDisposition.SelectedIndex + "0" + SecondSubDisposition.SelectedIndex + " is set");

                }
                else
                {
                    
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }


        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void AddDispositionCodeToList(int position,int FilterLength,string FilterKey,int idbid,string iAnnex,ListBox iListbox,List<KeyValuePair<string,string>> KvList)
        {
            try
            {
               
               
             //   Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.IConfService cfgService;
              //  Genesyslab.Desktop.Modules.Core.SDK.Configurations.IConfigurationService configurationService = ContainerAccessPoint.Container.Resolve<IConfigurationService>();
                cfgService = configurationService.ConfigService;

                Genesyslab.Platform.ApplicationBlocks.ConfigurationObjectModel.Queries.CfgTransactionQuery transactionquery = new CfgTransactionQuery();
                int dbid = idbid;

                transactionquery.Dbid = dbid;
                
                
                CfgTransaction configTransaction = cfgService.RetrieveObject<CfgTransaction>(transactionquery);

               
                if (configTransaction != null)
                {

                    KeyValueCollection kvTransaction = configTransaction.UserProperties.GetAsKeyValueCollection(iAnnex);

               
                    if (kvTransaction != null)
                    {
                        
                        try {
                            iListbox.ItemsSource = null;
                        }
                        catch( Exception ax)
                        { }
                       
                        KvList.Clear();
                      
                        String ListIndex = "";
                      
                        foreach (string optionName in kvTransaction.Keys)
                        {
                           
                            if (FilterKey == "")
                            {
                               
                                KvList.Add(new KeyValuePair<string, string>(optionName, kvTransaction[optionName].ToString()));
                                 // iListbox.Items.Insert(Convert.ToInt32(optionName), kvTransaction[optionName]);


                            }
                            else
                            {
                                
                                ListIndex = optionName.Substring(Convert.ToInt32(position), FilterLength);
                                if (ListIndex == FilterKey.Substring(0, FilterLength))
                                {
                                    //MessageBox.Show(Convert.ToInt32(optionName) + " " + optionName + " " + kvTransaction[optionName]);
                                    //iListbox.Items.Insert(Convert.ToInt32(ListIndex), kvTransaction[optionName]);

                                    KvList.Add(new KeyValuePair<string, string>(optionName, kvTransaction[optionName].ToString()));
                                    //  iListbox.Items.Add(kvTransaction[optionName]);
                                   // DispositionCodeReturn = FilterKey;
                                    //MessageBox.Show("Disp code : " + DispositionCodeReturn);
                                }
                            }
                        }

                        iListbox.ItemsSource = KvList;
                        iListbox.DisplayMemberPath = "Value";
                        iListbox.SelectedValuePath = "Key";
                   


                    }

                }
            }
            catch (Exception ex)
            {
                log.Debug("Error While function add disposition code" + ex.Message);
            }
        }

        private void cmbType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {

                //KvListSub.Clear();
                //KvpList.Clear();

                //SubDisposition.ItemsSource = KvListSub;
                //SubDisposition.SelectedValuePath = "Key";
                //SubDisposition.DisplayMemberPath = "Value";
                //SecondSubDisposition.ItemsSource = KvpList;
                //SecondSubDisposition.SelectedValuePath = "Value";
                //SecondSubDisposition.DisplayMemberPath = "Key";
                SubDisposition.ItemsSource = null;
                SecondSubDisposition.ItemsSource = null;
                AddDispositionCodeToList(0,2,"", Convert.ToInt32(cmbType.SelectedValue),"L1", ParentDisposition,  KvListParent);
                //  DispositionCodeStaticClass.ParentDispositionCount = ParentDispostion.Items.Count;

                if (!DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".ParentDisposition"))
                {
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", "");
                }
                else
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDisposition");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDisposition", "");
                }
                log.Debug("ParentCount" + DispositionCodeStaticClass.StClass[CaseId + ".ParentDisposition"]);

                if (!DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".ParentDispositionCount"))
                {
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDispositionCount", ParentDisposition.Items.Count.ToString());
                }
                else
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".ParentDispositionCount");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".ParentDispositionCount", ParentDisposition.Items.Count.ToString());
                }
                log.Debug("ParentCount" + DispositionCodeStaticClass.StClass[CaseId + ".ParentDispositionCount"]);

            }
            catch (Exception ex)
            {
               log.Debug("Error while selecting Type " + ex.Message);
            }
        }

       

        private void UserControl_Initialized(object sender, EventArgs e)
        {
            if (IsParentLoaded == false)
            {

               
            

            }
        }

        private void SecondSubDisposition_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                String SecondSubDispositionCode = "";
                SecondSubDispositionCode = SecondSubDisposition.SelectedValue.ToString();
                log.Info("SecondSubDisposition Code :" + SecondSubDispositionCode.ToString());
                log.Info("SecondSubDisposition Code After Trim :" + SecondSubDispositionCode.Substring(4, 2));
                //  DispositionCodeStaticClass.SecondSubDisposition = SecondSubDispositionCode.Substring(4, 2);
                if (DispositionCodeStaticClass.StClass.ContainsKey(CaseId + ".SecondSubDisposition"))
                {
                    DispositionCodeStaticClass.StClass.Remove(CaseId + ".SecondSubDisposition");
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDisposition", SecondSubDispositionCode.Substring(4, 2));
                }
                else
                {
                    
                    DispositionCodeStaticClass.StClass.Add(CaseId + ".SecondSubDisposition", SecondSubDispositionCode.Substring(4, 2));
                }
            }
            catch (Exception ex)
            {
                log.Debug("Exception while selecting Secondary Sub Disposition " + ex.Message);
            }
        }

        private void schParent_TextChanged(object sender, TextChangedEventArgs e)
        {

            string txtOrig = schParent.Text;
            string upper = txtOrig.ToUpper();
            string lower = txtOrig.ToLower();

            var empFiltered = from Emp in KvListParent
                              let ename = Emp.Value.ToLower()
                              where
                             
                               ename.StartsWith(lower)
                               || ename.StartsWith(upper)
                               || ename.Contains(txtOrig)
                              select Emp;

            ParentDisposition.ItemsSource = empFiltered;
        }

        private void schSub_TextChanged(object sender, TextChangedEventArgs e)
        {
            string txtOrig = schSub.Text;
            string upper = txtOrig.ToUpper();
            string lower = txtOrig.ToLower();

            var empFiltered = from Emp in KvListSub
                              let ename = Emp.Value.ToLower()
                              where
                               ename.StartsWith(lower)
                               || ename.StartsWith(upper)
                               || ename.Contains(txtOrig)
                              select Emp;

            SubDisposition.ItemsSource = empFiltered;
        }

        private void schSecond_TextChanged(object sender, TextChangedEventArgs e)
        {
            string txtOrig = schSecond.Text;
            string upper = txtOrig.ToUpper();
            string lower = txtOrig.ToLower();

            var empFiltered = from Emp in KvpList
                              let ename = Emp.Value.ToLower()
                              where
                               ename.StartsWith(lower)
                               || ename.StartsWith(upper)
                               || ename.Contains(txtOrig)
                              select Emp;

            SecondSubDisposition.ItemsSource = empFiltered;
        }

        private void cmbCourts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            DispositionCodeStaticClass.courts = cmbCourts.SelectedValue.ToString();
        }

       
       
    }

}
