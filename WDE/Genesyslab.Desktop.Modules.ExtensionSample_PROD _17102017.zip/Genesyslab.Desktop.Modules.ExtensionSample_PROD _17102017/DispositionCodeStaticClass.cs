﻿using System.Collections.Generic;

namespace Genesyslab.Desktop.Modules.ExtensionSample
{
    internal class DispositionCodeStaticClass
    {
        public static Dictionary<string, string> StClass = new Dictionary<string, string>();
      
        public static string ParentDisposition = "";
        public static string SubDisposition = "";
        public static string SecondSubDisposition = "";
        public static string courts = "";
        public static string Extension = "";
        public static int ParentDispositionCount = 0;
        public static int SubDispositionCount = 0;
        public static int SecondSubDispositionCount = 0;
        public static bool IsInboundCall = false;
       

    

   }
}