﻿
namespace Genesyslab.Desktop.Modules.ExtensionSample.MySample
{
	/// <summary>
	/// The MySampleMenuView interface
	/// </summary>
	public interface IMySampleMenuView
	{
	}
}
