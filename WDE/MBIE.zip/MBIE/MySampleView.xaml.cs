﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using Genesyslab.Desktop.Modules.Windows.Common.DimSize;
using Genesyslab.Desktop.Modules.Core.Model.Interactions;
using Genesyslab.Desktop.Infrastructure.DependencyInjection;
using Genesyslab.Platform.Commons.Logging;

namespace Genesyslab.Desktop.Modules.ExtensionSample.MySample
{
	/// <summary>
	/// Interaction logic for MySampleView.xaml
	/// </summary>
	public partial class MySampleView : UserControl, IMyExtensionSampleView
	{
        //static  double dThen = 0.0;
        static string caseId = "";
        static ILogger log;

        public  MySampleView(IMyExtensionSampleViewModel mySampleViewModel )
		{
			this.Model = mySampleViewModel;

			InitializeComponent();

			Width = Double.NaN;
			Height = Double.NaN;
			MinSize = new MSize() { Width = 400.0, Height = 400.0 };
        }

        public static bool Condition(ref object context)
        {
            IDictionary<string, object> contextDictionary = context as IDictionary<string, object>;
            //object caseView;
            //contextDictionary.TryGetValue("CaseView", out caseView);
            object caseObject;
            contextDictionary.TryGetValue("Case", out caseObject);
            ICase myCase = caseObject as ICase;
            if (myCase != null)
            {
                if (myCase.MainInteraction != null)
                {
                    try
                    {
                        string thisCaseId = myCase.CaseId as string;
                        // TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
                        //double dNow = t.TotalSeconds;
                        if (!caseId.Equals(thisCaseId))
                        {
                            //dThen = dNow;
                            caseId = thisCaseId;
                            IInteraction i = myCase.MainInteraction;
                            string url = i.GetAttachedData("POPURL") as string;
                            //string iid = i.InteractionId as string;
                            if ((url != null) && (url.Length > 4))
                            {
                                // Sanity check - add http if forgotten
                                if (!url.ToLower().StartsWith("http")) url = "http://" + url;
                                // log log
                                log = ContainerAccessPoint.Container.Resolve<ILogger>();
                                log = log.CreateChildLogger("call URL");
                                log.Info("Start system browser with url: " + url);
                                log.Info("thisCaseId="+thisCaseId);
                                /* START BROWSER
                                 We don't bother testing for 404s or other web errors. 
                                 The browser will be popped with the URL already displaying the bad page.
                                 We also don't worry if the browser's not associated. 
                                 In these cases, it will start an external program, or just die.
                                 */
                                System.Diagnostics.Process.Start("IEXPLORE.EXE",url);
                            }
                        }
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show("Error: " + ee.Message);
                    }
                }
            }
            // Yes, false. DON'T ASK ME WHY !!!!
            return false;

        }


		#region IMySampleView Members

		/// <summary>
		/// Gets or sets the model.
		/// </summary>
		/// <value>The model.</value>
		public IMyExtensionSampleViewModel Model
		{
			get { return this.DataContext as IMyExtensionSampleViewModel; }
			set { this.DataContext = value; }
		}


		#endregion

		#region IView Members

		/// <summary>
		/// Gets or sets the context.
		/// </summary>
		/// <value>The context.</value>
		public object Context { get; set; }

		/// <summary>
		/// Creates this instance.
		/// </summary>
		public void Create()
		{
			ObservableCollection<IMyListItem> collection = new ObservableCollection<IMyListItem>();
			collection.Add(new MyListItem() { LastName = "Doe", FirstName = "John" });
			collection.Add(new MyListItem() { LastName = "Dupont", FirstName = "Marcel" });

			Model.MyCollection = collection;
		}

		/// <summary>
		/// Destroys this instance.
		/// </summary>
		public void Destroy()
		{
		}

		#endregion
		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		#endregion
		MSize _MinSize;
		public MSize MinSize
		{
			get { return _MinSize; }  // (MSize)base.GetValue(MinSizeProperty); }
			set
			{
				_MinSize = value; // base.SetValue(MinSizeProperty, value);
				OnPropertyChanged("MinSize");
			}
		}


        public void Add(IComponent component, string name)
        {
            throw new NotImplementedException();
        }

        public void Add(IComponent component)
        {
            throw new NotImplementedException();
        }

        public ComponentCollection Components
        {
            get { throw new NotImplementedException(); }
        }

        public void Remove(IComponent component)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }


	class MyListItem : IMyListItem
	{

		#region IMyListItem Members

		string firstName;
		public string FirstName
		{
			get
			{
				return firstName;
			}
			set
			{
				if (value != firstName) { firstName = value; OnPropertyChanged("FirstName"); }
			}
		}

		string lastName;
		public string LastName
		{
			get
			{
				return lastName;
			}
			set
			{
				if (value != lastName) { lastName = value; OnPropertyChanged("LastName"); }
			}
		}

		#endregion

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		#endregion


	}
}
