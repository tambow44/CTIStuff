package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.protocol.ProtocolException;

import genesys.AgentInfo;
import genesys.CfgSvcInitialization;
import genesys.TenantInfo;
import genesys.TransactionObject;

@WebServlet(name = "Admin", urlPatterns = { 
		"/admin" ,"/admin_edit_tenant", "/admin_delete_tenant", "/admin_new_tenant", "/admin_add_tenant_action",
		"/admin_list_objects", "/admin_edit_list_object", "/admin_delete_list_object", "/admin_add_list_object_action",
		"/admin_add_list_object", "/admin_edit_section", "/admin_edit_option", "/admin_option_update", 
		"/admin_add_option_type_action", "/admin_copy_section_options", "/admin_cleanup_section",
		"/admin_changes", "/admin_section_update", "/admin_section_order_update"})
public class Admin extends HttpServlet {

	private static final long serialVersionUID = 186814L;

	@Override
	public void doGet(HttpServletRequest request, 
			HttpServletResponse response)
					throws IOException, ServletException {
		try {
			process(request, response);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void doPost(HttpServletRequest request, 
			HttpServletResponse response)
					throws IOException, ServletException {
		try {
			process(request, response);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void process(HttpServletRequest request,
			HttpServletResponse response) 
					throws IOException, ServletException, InterruptedException, ConfigException, SQLException, ClassNotFoundException {

		String uri = request.getRequestURI();
		/*
		 * uri is in this form: /contextName/resourceName, 
		 * for example: /app10a/product_input. 
		 * However, in the case of a default context, the 
		 * context name is empty, and uri has this form
		 * /resourceName, e.g.: /product_input
		 */
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex + 1); 
		String dispatchUrl = null;

		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();

		HttpSession session = request.getSession();

		Enumeration<String> session_test = session.getAttributeNames();

		if (session_test.hasMoreElements()){

			if ((Boolean) session.getAttribute("isAdmin")) {

				IConfService confService = (IConfService) session.getAttribute("confService");

				if (action.equals("admin")){

					session.removeAttribute("tenantDBID");
					session.removeAttribute("tenantName");
					session.removeAttribute("tenantList");
					session.removeAttribute("transObjectDBID");
					session.removeAttribute("listObjectName");
					session.removeAttribute("transObjectList");
					session.removeAttribute("sectionID");
					session.removeAttribute("sectionName");
					session.removeAttribute("sectionList");
					session.removeAttribute("optionID");
					session.removeAttribute("optionName");
					session.removeAttribute("listObjectDBID");
					session.removeAttribute("newOptionTypeName");
					session.removeAttribute("newOptionAdded");
					session.removeAttribute("sectionCopiedOptionNum");
					session.removeAttribute("copySectionID");

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminMain.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_edit_tenant")){

					int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));
					session.setAttribute("tenantDBID", tenantDBID);

					String tenantName = TenantInfo.getTenantName(tenantDBID, confService);
					session.setAttribute("tenantName", tenantName);


					session.removeAttribute("transObjectDBID");
					session.removeAttribute("listObjectName");
					session.removeAttribute("transObjectList");
					session.removeAttribute("sectionID");
					session.removeAttribute("sectionName");
					session.removeAttribute("sectionList");
					session.removeAttribute("optionID");
					session.removeAttribute("optionName");
					session.removeAttribute("listObjectDBID");
					session.removeAttribute("newOptionTypeName");
					session.removeAttribute("newOptionAdded");
					session.removeAttribute("sectionCopiedOptionNum");
					session.removeAttribute("copySectionID");

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditTenant.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_delete_tenant")){
					int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));
					String tenantName = request.getParameter("tenantName");

					session.setAttribute("tenantName", tenantName);
					session.setAttribute("tenantDBID", tenantDBID);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminDeleteTenant.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_new_tenant")){

					Map<Integer,String> tenantList = TenantInfo.getTenants(confService);

					session.setAttribute("tenantList", tenantList);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);

					request.getRequestDispatcher("WebContent/adminAddTenant.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_add_tenant_action")){
					int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));
					int testAgGrpDbid = Integer.parseInt(request.getParameter("testAgGrpDbid"));
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					TenantInfo.addTenant(tenantDBID, testAgGrpDbid, confService, dbConn);

					response.sendRedirect("admin");

				} else if (action.equals("admin_edit_list_object")){


					session.removeAttribute("transObjectList");
					session.removeAttribute("sectionID");
					session.removeAttribute("sectionName");
					session.removeAttribute("sectionList");
					session.removeAttribute("optionID");
					session.removeAttribute("optionName");
					session.removeAttribute("newOptionTypeName");
					session.removeAttribute("newOptionAdded");
					session.removeAttribute("sectionCopiedOptionNum");
					session.removeAttribute("copySectionID");

					// read List Object DBID from link
					int listObjectDBID = Integer.parseInt(request.getParameter("listObjectID"));

					session.setAttribute("transObjectDBID", listObjectDBID);
					int tenantDBID = (Integer) session.getAttribute("tenantDBID");
					String listObjectName = TransactionObject.getListObjectName(listObjectDBID, tenantDBID, confService);

					session.setAttribute("listObjectName", listObjectName);

					// Pass list object id etc to function and return array of section names.
					ArrayList<String> sectionList = TransactionObject.getSections(listObjectDBID, tenantDBID, confService);

					session.setAttribute("sectionList", sectionList);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditListObject.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				} else if (action.equals("admin_add_list_object")){

					int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));

					Map<Integer,String> transObjectList = TransactionObject.getTransObjectList(tenantDBID, confService);

					session.setAttribute("transObjectList", transObjectList);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);

					request.getRequestDispatcher("WebContent/adminAddListObject.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_add_list_object_action")){

					int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));
					int listObjectDBID = Integer.parseInt(request.getParameter("listObjectDBID"));
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					int ctiOnly;

					if (request.getParameter("CTIOnly") == null) {
						ctiOnly = 0;
					} else {
						ctiOnly = 1;
					}

					TransactionObject.addTransObject(tenantDBID, listObjectDBID, ctiOnly, confService, dbConn);

					response.sendRedirect("admin_edit_tenant?tenantDBID=" + tenantDBID);

				} else if (action.equals("admin_delete_list_object")){

					int listObjectDBID = Integer.parseInt(request.getParameter("listObjectDBID"));
					String listObjectName = request.getParameter("listObjectName");

					session.setAttribute("listObjectName", listObjectName);
					session.setAttribute("listObjectDBID", listObjectDBID);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminDeleteListObject.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_edit_section")){

					session.removeAttribute("sectionList");
					session.removeAttribute("optionID");
					session.removeAttribute("optionName");
					session.removeAttribute("newOptionTypeName");
					session.removeAttribute("newOptionAdded");
					session.removeAttribute("sectionCopiedOptionNum");
					session.removeAttribute("copySectionID");

					int sectionID = Integer.parseInt(request.getParameter("sectionID"));
					int transObjectDBID = Integer.parseInt(request.getParameter("transObjectDBID"));
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					session.setAttribute("sectionID", sectionID);
					session.setAttribute("transObjectDBID", transObjectDBID);

					int tenantDBID = (Integer) session.getAttribute("tenantDBID");

					// Pass list object id etc to function and return array of section names.
					ArrayList<String> optionList = TransactionObject.getOptions(transObjectDBID, sectionID, tenantDBID, confService, dbConn);

					String sectionName = TransactionObject.getSectionName(sectionID, dbConn);

					session.setAttribute("sectionName", sectionName);
					session.setAttribute("optionList", optionList);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditSection.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_edit_option")){

					session.removeAttribute("newOptionTypeName");
					session.removeAttribute("newOptionAdded");
					session.removeAttribute("sectionCopiedOptionNum");
					session.removeAttribute("copySectionID");

					int optionID = Integer.parseInt(request.getParameter("optionID"));
					int sectionID = Integer.parseInt(request.getParameter("sectionID"));
					int transObjectDBID = (Integer) session.getAttribute("transObjectDBID");
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					session.setAttribute("optionID", optionID);
					session.setAttribute("sectionID", sectionID);

					String optionName = TransactionObject.getOptionName(optionID, dbConn);
					session.setAttribute("optionName", optionName);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditOption.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_option_update")){
					int optionID = (Integer) session.getAttribute("optionID");
					int optionTypeID = Integer.parseInt(request.getParameter("optionTypeID"));
					int oldTypeID = Integer.parseInt(request.getParameter("oldTypeID"));
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					boolean optionTypeUpdated = TransactionObject.updateOption(optionID, optionTypeID, dbConn);

					if (optionTypeUpdated) {
						String username = (String) session.getAttribute("username");
						TransactionObject.adminChange(username,optionID,oldTypeID,optionTypeID, dbConn);
						session.setAttribute("optionID", optionID);
						request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/adminOptionUpdate.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					} else {
						System.out.println("eep! option failed to update.");
					}

				} else if (action.equals("admin_edit_option_types")){

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditOptionTypes.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_add_option_type_action")){

					boolean optionAdded = false;
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					String optionTypeName = request.getParameter("option_type_name");
					String optionType = request.getParameter("option_type");
					String optionTypeDescription = request.getParameter("option_type_description");

					Map<String,String> optionValues = new HashMap<String,String>();
					
					String paramName = "";
					String paramValue = "";
					String paramAltName = "";
					String paramAltValue = "";

					if (optionType.equals("SELECT")){
						Enumeration<String> paramNames = request.getParameterNames();
						while(paramNames.hasMoreElements()) {
							paramName = (String)paramNames.nextElement();

							if (paramName.startsWith("select_value")){
								paramValue = request.getParameter(paramName);
								paramAltName = paramName.replace("select_value", "select_alt_value");
								paramAltValue = request.getParameter(paramAltName);
								optionValues.put(paramValue,paramAltValue);
							}
						}

						optionAdded = TransactionObject.addSelectObjectType(optionTypeName, optionTypeDescription, optionValues, dbConn);

					} else if (optionType.equals("LIST")){
						String listDelimiter = request.getParameter("list_delimiter");

						optionAdded = TransactionObject.addListObjectType(optionTypeName, optionTypeDescription, listDelimiter, dbConn);
					} else if (optionType.equals("KVLIST")){
						String kvlistDelimiter = request.getParameter("kvlist_delimiter");
						String kvDelimiter = request.getParameter("kv_delimiter");

						optionAdded = TransactionObject.addKVListObjectType(optionTypeName, optionTypeDescription, kvlistDelimiter, kvDelimiter, dbConn);
					} else {

					}

					session.setAttribute("newOptionTypeName", optionTypeName);
					session.setAttribute("newOptionAdded", optionAdded);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminAddOptionTypeAction.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_delete_option_type")){

				} else if (action.equals("admin_copy_section_options")){
					Connection dbConn = (Connection) session.getAttribute("dbConnection");

					int copySectionID = Integer.parseInt(request.getParameter("copySectionID"));
					int thisSectionID = (Integer) session.getAttribute("sectionID");

					int sectionCopiedOptionNum =  TransactionObject.copySection(thisSectionID, copySectionID, dbConn);

					session.setAttribute("sectionCopiedOptionNum", sectionCopiedOptionNum);
					session.setAttribute("copySectionID", copySectionID);

					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminCopySectionOptions.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

				} else if (action.equals("admin_cleanup_section")) {
					Connection dbConn = (Connection) session.getAttribute("dbConnection");
					int tenantDBID = (Integer) session.getAttribute("tenantDBID");
					int transObjectDBID = Integer.parseInt(request.getParameter("transObjectDBID"));
					int sectionID = Integer.parseInt(request.getParameter("sectionID"));
					String sectionName = TransactionObject.getSectionName(sectionID, dbConn);
					
					session.setAttribute("transObjectDBID", transObjectDBID);
					session.setAttribute("sectionID", sectionID);
					session.setAttribute("sectionName", sectionName);
					
					
					int optionsRemoved = TransactionObject.cleanUpSection(tenantDBID, transObjectDBID, sectionID, confService, dbConn);
					
					session.setAttribute("optionsRemoved", optionsRemoved);
					
					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminCleanUpOptions.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					
				} else if (action.equals("admin_changes")){
					Connection dbConn = (Connection) session.getAttribute("dbConnection");
					
					int offset = Integer.parseInt(request.getParameter("offset"));
					int tenantDBID = (Integer) session.getAttribute("tenantDBID");
					int prev_offset = offset - 40;
					int next_offset = offset + 40;
					
					session.setAttribute("prev_offset",prev_offset);
					session.setAttribute("next_offset",next_offset);
					
					String table = "ADMIN_CHANGES";
					
					ArrayList<String> changes = TransactionObject.getChanges(offset, table, dbConn, tenantDBID);
					
					session.setAttribute("changes", changes);
					
					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminChanges.jsp").include(request, response);   	
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				
				} else if (action.equals("admin_section_update")) {
					Connection dbConn = (Connection) session.getAttribute("dbConnection");
					
					int optionsUpdated = 0;
					int optionsToUpdate = 0;
					
					Map<Integer, Integer> optionTypes = new HashMap<Integer, Integer>();
					
					int sectionID = 0;
					int optionID = 0;
					int typeID = 0;
					String name;
					String value;
					Enumeration<String> e = request.getParameterNames();
					
					while (e.hasMoreElements()) {
						name = (String) e.nextElement();
						value = request.getParameter(name).toString();
						if (name.equals("sectionID")){
							sectionID = Integer.parseInt(value);
						} else {
							typeID = Integer.parseInt(value);
							optionID = Integer.parseInt(name);
							optionTypes.put(optionID, typeID);
						}
						
					}
					optionsToUpdate = optionTypes.size();
					optionsUpdated = TransactionObject.updateSection(sectionID, optionTypes, dbConn);
					
					session.setAttribute("optionsUpdated", optionsUpdated);
					session.setAttribute("optionsToUpdate", optionsToUpdate);
					
					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditSection.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					
				} else if (action.equals("admin_section_order_update")) {
					Connection dbConn = (Connection) session.getAttribute("dbConnection");
					
					int sectionsUpdated = 0;
					int sectionsToUpdate = 0;
					
					Map<Integer, Integer> sectionOrders = new HashMap<Integer, Integer>();
					
					int transObjectDBID = 0;
					int sectionID = 0;
					int sectionOrder = 0;
					String name;
					String value;
					Enumeration<String> e = request.getParameterNames();
					
					while (e.hasMoreElements()) {
						name = (String) e.nextElement();
						value = request.getParameter(name).toString();
						if (name.equals("transObjectDBID")){
							transObjectDBID = Integer.parseInt(value);
						} else {
							sectionOrder = Integer.parseInt(value);
							sectionID = Integer.parseInt(name);
							sectionOrders.put(sectionID, sectionOrder);
						}
						
					}
					sectionsToUpdate = sectionOrders.size();
					sectionsUpdated = TransactionObject.updateSectionOrders(transObjectDBID, sectionOrders, dbConn);
					
					session.setAttribute("sectionsUpdated", sectionsUpdated);
					session.setAttribute("sectionsToUpdate", sectionsToUpdate);
					
					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/adminEditListObject.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					
				}

			}
		}

		else {
			session.invalidate();
			request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
			request.getRequestDispatcher("WebContent/logout.jsp").include(request, response);
			request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
		}
	}
}
