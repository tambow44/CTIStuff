package controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.configuration.protocol.types.CfgObjectType;

import genesys.AgentGroupObject;
import genesys.AgentInfo;
import genesys.CfgSvcInitialization;
import genesys.FolderObject;
import genesys.SkillObject;
import genesys.TenantInfo;
import genesys.TransactionObject;

@WebServlet(name = "ControllerServlet", urlPatterns = { 
		"/login_form", "/login_action", "/trans_form", "/trans_list", "/trans_update", 
		"/edit_option", "/trans_form_tenant", "/tenant_form", "/logout",
		"/tenant_changes", "/skill_expression_list", "/skill_expression_edit",
		"/skill_expression_update", "/skill_expression_new", "/skill_expression_create", 
		"/skill_expression_test", "/get_agents_with_skill_exp", "/get_skills_in_folder",
		"/get_agents_with_skill_exp_string", "/get_agents_with_complex_skill_exp", 
		"/skill_complex_expression_create", "/list_agents_in_group", 
		"/del_skill_exp", "/tenant_changes_export", "/test_stuff"})
public class ControllerServlet extends HttpServlet {

	private static final long serialVersionUID = 863153L;

	@Override
	public void doGet(HttpServletRequest request, 
			HttpServletResponse response)
					throws IOException, ServletException {
		try {
			process(request, response);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void doPost(HttpServletRequest request, 
			HttpServletResponse response)
					throws IOException, ServletException {
		try {
			process(request, response);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void process(HttpServletRequest request,
			HttpServletResponse response) 
					throws IOException, ServletException, InterruptedException, ConfigException, SQLException, ClassNotFoundException {

		String uri = request.getRequestURI();
		/*
		 * uri is in this form: /contextName/resourceName, 
		 * for example: /app10a/product_input. 
		 * However, in the case of a default context, the 
		 * context name is empty, and uri has this form
		 * /resourceName, e.g.: /product_input
		 */
		int lastIndex = uri.lastIndexOf("/");
		String action = uri.substring(lastIndex + 1); 
		String dispatchUrl = null;

		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();

		HttpSession session = request.getSession();	
		
		Enumeration<String> session_test = session.getAttributeNames();

		if (action.equals("login_form") || action.equals("login_action") || session_test.hasMoreElements()){

			if (action.equals("login_form") || action.equals("")) {
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/loginForm.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
			} 

			else if (action.equals("login_action")) {

				String rand = Long.toHexString(Double.doubleToLongBits(Math.random()));
				String cfgsrvEndpointName = "ConfAcc#" + rand;

				String cfgsrvHost = request.getParameter("host");

				String username = request.getParameter("username");
				String password = request.getParameter("password");

				try {
					int    cfgsrvPort = Integer.parseInt(request.getParameter("port"));
					IConfService thisConfService = CfgSvcInitialization.initializeConfigService(
							cfgsrvEndpointName,
							cfgsrvHost,
							cfgsrvPort,
							username,
							password);

					session.setAttribute("confService", thisConfService);
					
					int personDbid = AgentInfo.getPersonDbid(username, thisConfService);

					boolean isSuperAdmin = AgentInfo.checkSuperAdmin(personDbid, thisConfService);

					session.setAttribute("username", username);
					
					

					if (isSuperAdmin) {
						session.setAttribute("isAdmin", true);
						request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/selectTenantForm.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					} else {
						int tenantDBID = AgentInfo.getPersonTenant(username, thisConfService);
						session.setAttribute("tenantDBID", tenantDBID);
						String tenantName = TenantInfo.getTenantName(tenantDBID, thisConfService);
						session.setAttribute("tenantName", tenantName);
						
						request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/transForm.jsp").include(request, response);
						request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
					}

				} catch (Throwable e) {
					e.printStackTrace();
					String errorMessage = e.toString();
					/*writer.print("<html><head></head>"
                        + "<body>"
                        + errorMessage
                        + "</body></html>");*/
					session.setAttribute("errorMessage", errorMessage);
					request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/badLogin.jsp").include(request, response);
					request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				} 

				try {
					ResourceBundle properties;
					String driverName;

					try {
						properties = new PropertyResourceBundle(new FileInputStream("/opt/GCTI/apache-tomcat-7.0.32/webapps/db.properties"));
						driverName = "org.apache.derby.jdbc.EmbeddedDriver";
					} catch (Exception ex) {
						properties = new PropertyResourceBundle(new FileInputStream("d:/GLOT/db.properties"));
						driverName = "org.apache.derby.jdbc.ClientDriver";
					}
					
					Class.forName(driverName);

					String fileLocation = properties.getString("fileLocation");
					String url = "jdbc:derby:" + fileLocation;
					String dbusername = properties.getString("dbusername");
					String dbpassword = properties.getString("dbpassword");
					

					Connection dbConnection = DriverManager.getConnection(url, dbusername, dbpassword);
					
					
					Object tenantIdObj =  session.getAttribute("tenantDBID");
					
					if (tenantIdObj != null){
						int tenantId = (Integer) tenantIdObj;
						int testAgentGroupDbid = TenantInfo.getTenantTestAgentGroupDbid(tenantId, dbConnection);
						session.setAttribute("testAgentGroupDbid", testAgentGroupDbid);
					}
					
					session.setAttribute("dbConnection", dbConnection);
				} catch (ClassNotFoundException e) {
					// Could not find the database driver
					System.out.println("Could not find the database driver");
				} catch (SQLException e) {
					// Could not connect to the database
					System.out.println("Could not connect to the database");
				}
			} else if (action.equals("tenant_form")) {
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/selectTenantForm.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

			} else if (action.equals("trans_form")) {
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/transForm.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

			} else if  (action.equals("trans_form_tenant")) {
				IConfService thisConfService = (IConfService) session.getAttribute("confService");
				Connection dbConnection = (Connection) session.getAttribute("dbConnection");
				int tenantDBID = Integer.parseInt(request.getParameter("tenantDBID"));
				session.setAttribute("tenantDBID", tenantDBID);
				String tenantName = TenantInfo.getTenantName(tenantDBID, thisConfService);
				session.setAttribute("tenantName", tenantName);
				int testAgentGroupDbid = TenantInfo.getTenantTestAgentGroupDbid(tenantDBID, dbConnection);
				session.setAttribute("testAgentGroupDbid", testAgentGroupDbid);

				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/transForm.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

			}else if (action.equals("trans_list")) {
				int listObjectDBID;
				Connection dbConn = (Connection) session.getAttribute("dbConnection");

				try {
					listObjectDBID = Integer.parseInt(request.getParameter("listObjectDBID"));
				}
				catch (Throwable t){
					listObjectDBID = (Integer) session.getAttribute("listObjectDBID");
				};

				session.setAttribute("listObjectDBID", listObjectDBID);
				IConfService confSerivce = (IConfService) session.getAttribute("confService");
				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				String listObjectName = TransactionObject.getListObjectName(listObjectDBID, tenantDBID, confSerivce);
				session.setAttribute("listObjectName", listObjectName);

				Map<String, Map<String, String>> transListOptions = TransactionObject.listTransactionOptions(listObjectDBID, tenantDBID, confSerivce, dbConn);

				session.setAttribute("transListOptions", transListOptions);

				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);

				request.getRequestDispatcher("WebContent/transList.jsp").include(request, response);

				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

			} else if (action.equals("trans_update")) {
				boolean listUpdated = false;
				int listObjectDBID = (Integer) session.getAttribute("listObjectDBID");
				String sectionName = (String) session.getAttribute("sectionName");
				String optionKey = (String) session.getAttribute("optionKey");
				String optionType = request.getParameter("option_type");
				String oldValue = request.getParameter("old_value");
				String username = (String) session.getAttribute("username");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");

				// Set option value for different option types.

				String optionValue = "";

				if (optionType.equals("DATE_RANGE")) {
					String startDate = request.getParameter("start_date");
					String endDate = request.getParameter("end_date");
					optionValue = startDate + "-" + endDate;
				} else if (optionType.equals("DATE_TIME")) {
					String date = request.getParameter("date");
					String time = request.getParameter("time");
					optionValue = date + " " + time;
				} else if (optionType.equals("DAY_RANGE")) {
					String startDay = request.getParameter("start_day");
					String endDay = request.getParameter("end_day");
					optionValue = startDay + "-" + endDay;
				} else if (optionType.equals("KVLIST")) {

					String list_delimiter = request.getParameter("list_delimiter");
					String kv_delimiter = request.getParameter("kv_delimiter");

					String thisOptionKeyName = "";
					String thisOptionKey = "";
					String thisOptionValueName = "";
					String thisOptionValue = "";

					int optionCounter = 1;

					while (thisOptionKey != null){
						thisOptionKeyName = "pair" + optionCounter + "_key";
						thisOptionValueName = "pair" + optionCounter + "_value";
						thisOptionKey = request.getParameter(thisOptionKeyName);
						thisOptionValue = request.getParameter(thisOptionValueName);
						if (thisOptionKey != null && !thisOptionKey.isEmpty()) {
							optionValue = optionValue + list_delimiter + thisOptionKey + kv_delimiter + thisOptionValue;
						}
						optionCounter++;
					}

					String thisNewOptionKeyName = "";
					String thisNewOptionKey = "";
					String thisNewOptionValueName = "";
					String thisNewOptionValue = "";

					optionCounter = 1;

					while (thisNewOptionKey != null){
						thisNewOptionKeyName = "new_pair" + optionCounter + "_key";
						thisNewOptionValueName = "new_pair" + optionCounter + "_value";
						thisNewOptionKey = request.getParameter(thisNewOptionKeyName);
						thisNewOptionValue = request.getParameter(thisNewOptionValueName);
						if (thisNewOptionKey != null && !thisNewOptionKey.isEmpty()) {
							optionValue = optionValue + list_delimiter + thisNewOptionKey + kv_delimiter + thisNewOptionValue;
						}
						optionCounter++;
					}

					optionValue = optionValue.substring(1);

				} else if (optionType.equals("LIST")) {
					String delimiter = request.getParameter("list_delimiter");
					String thisOptionName = "";
					String thisOptionValue = "";

					int optionCounter = 1;

					while (thisOptionValue != null){
						thisOptionName = "option" + optionCounter;
						thisOptionValue = request.getParameter(thisOptionName);
						if (thisOptionValue != null && !thisOptionValue.isEmpty()) {
							optionValue = optionValue + delimiter + thisOptionValue;
						}
						optionCounter++;
					}

					String thisNewOptionValue = "";

					optionCounter = 1;

					while (thisNewOptionValue != null){
						thisOptionName = "newoption" + optionCounter;
						thisNewOptionValue = request.getParameter(thisOptionName);
						if (thisNewOptionValue != null && !thisNewOptionValue.isEmpty()) {
							optionValue = optionValue + delimiter + thisNewOptionValue;
						}
						optionCounter++;
					}

					optionValue = optionValue.substring(1);

				} else if (optionType.equals("TIME_RANGE")) {
					String startTime = request.getParameter("start_time");
					String endTime = request.getParameter("end_time");
					optionValue = startTime + "-" + endTime;
				} else {
					optionValue = request.getParameter("option_value");
				}

				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				IConfService confSerivce = (IConfService) session.getAttribute("confService");

				listUpdated = TransactionObject.updateTransaction(listObjectDBID, sectionName, optionKey, optionValue, tenantDBID, confSerivce);

				TransactionObject.listObjectChange(username, listObjectDBID, sectionName, optionKey, oldValue, optionValue, dbConn);

				session.setAttribute("listUpdated", listUpdated);
				
				
				try {
					listObjectDBID = Integer.parseInt(request.getParameter("listObjectDBID"));
				}
				catch (Throwable t){
					listObjectDBID = (Integer) session.getAttribute("listObjectDBID");
				};

				session.setAttribute("listObjectDBID", listObjectDBID);
				String listObjectName = TransactionObject.getListObjectName(listObjectDBID, tenantDBID, confSerivce);
				session.setAttribute("listObjectName", listObjectName);

				Map<String, Map<String, String>> transListOptions = TransactionObject.listTransactionOptions(listObjectDBID, tenantDBID, confSerivce, dbConn);

				session.setAttribute("transListOptions", transListOptions);

				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				//request.getRequestDispatcher("WebContent/transUpdated.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/transList.jsp?listUpdated="+listUpdated).include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);

			} else if (action.equals("edit_option")) {
				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				IConfService confSerivce = (IConfService) session.getAttribute("confService");
				int listObjectDBID = Integer.parseInt(request.getParameter("listObjectDBID"));
				String listObjectName = TransactionObject.getListObjectName(listObjectDBID, tenantDBID, confSerivce);        	
				session.setAttribute("listObjectName", listObjectName);
				String sectionName = request.getParameter("section");
				session.setAttribute("sectionName", sectionName);
				String optionKey = request.getParameter("key");
				session.setAttribute("optionKey", optionKey);
				String optionValue = request.getParameter("value");
				session.setAttribute("optionValue", optionValue);


				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/editOption.jsp").include(request, response);   	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
			
			} else if (action.equals("tenant_changes")){
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				int offset = Integer.parseInt(request.getParameter("offset"));
				int prev_offset = offset - 40;
				int next_offset = offset + 40;
				
				session.setAttribute("prev_offset",prev_offset);
				session.setAttribute("next_offset",next_offset);
				
				String table = "CHANGES";
				
				ArrayList<String> changes = TransactionObject.getChanges(offset, table, dbConn, tenantDBID);
				
				session.setAttribute("changes", changes);
				
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/tenantChanges.jsp").include(request, response);   	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				
				
			} else if (action.equals("tenant_changes_export")){
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				String startdate = request.getParameter("startdate");
				String enddate = request.getParameter("enddate");
				
				String path = getServletContext().getRealPath("/");
				
				int offset = 0;
				int prev_offset = offset - 40;
				int next_offset = offset + 40;				
				session.setAttribute("prev_offset",prev_offset);
				session.setAttribute("next_offset",next_offset);
								
				String url = TransactionObject.writeChangesCSV(startdate, enddate, dbConn, path, tenantDBID);
				
				response.sendRedirect(url);
				
			} else if (action.equals("skill_expression_list")){ 
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/skillExpressionList.jsp").include(request, response);   	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
		    
			} else if (action.equals("skill_expression_new")){
		    	IConfService confSerivce = (IConfService) session.getAttribute("confService");
		    	int tenantDBID = (Integer) session.getAttribute("tenantDBID");
		    	Connection dbConn = (Connection) session.getAttribute("dbConnection");
		    	//int folderType = CfgObjectType.CFGSkill.ordinal();
		    	
		    	Map<String, Integer> rootSkillFolders = new TreeMap<String, Integer>();
		    	
		    	int folderType = CfgObjectType.CFGSkill.ordinal();
		    	
		    	rootSkillFolders = FolderObject.getRootFolders(confSerivce, folderType, tenantDBID);
		    	
		    	session.setAttribute("rootSkillFolders",rootSkillFolders);
		    	
		    	Map<String, Integer> skillExpressions = SkillObject.getSkillExpressions(tenantDBID, dbConn);
		    	
		    	session.setAttribute("skillExpressions",skillExpressions);
		    	
		    	request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/skillExpressionNew.jsp").include(request, response);   	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				
		    } else if (action.equals("get_skills_in_folder")){ 
		    	int folderDbid = Integer.parseInt(request.getParameter("folderDbid"));
		    	int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				IConfService confSerivce = (IConfService) session.getAttribute("confService");
				
				Map<String, Integer> folderSkills = SkillObject.getFolderSkills(folderDbid, tenantDBID, confSerivce);
				
				String string = JSON.getJSONString(folderSkills);
				
				session.setAttribute("string",string);
		    	request.getRequestDispatcher("WebContent/returnString.jsp").include(request, response);
				
		    } else if (action.equals("skill_expression_create")){ 
		    	String skill = request.getParameter("skill");
			    String operator = request.getParameter("operator");	
			    String level = request.getParameter("level");
			    
			    if (operator.equals("eq")){
			    	operator = "=";
			    } else if (operator.equals("gt")){
			    	operator = ">";
			    } else if (operator.equals("gte")){
			    	operator = ">=";
			    } else if (operator.equals("lt")){
			    	operator = "<";
			    } else if (operator.equals("lte")){
			    	operator = "<=";
			    }
			    
			    String skillExpressionCME = "Skill(\"" + skill + "\")" + operator + level;
			    String skillExpressionList = skill+operator+level;
			    
			    int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				
				boolean skillExpressionCreated = SkillObject.createSkillExpression(skillExpressionCME, skillExpressionList, tenantDBID, dbConn);
			    
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				if (skillExpressionCreated) {
					request.getRequestDispatcher("WebContent/skillExpressionNew.jsp?skill_expression_created=true").include(request, response);
				} else {
					request.getRequestDispatcher("WebContent/skillExpressionNew.jsp?skill_expression_created=false").include(request, response);
				}  	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				
		    } else if (action.equals("skill_complex_expression_create")){ 
		    	int tenantDbid = (Integer) session.getAttribute("tenantDBID");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				
		    	int skillExpId1 = Integer.parseInt(request.getParameter("skill_exp_1"));
			    int skillExpId2 = Integer.parseInt(request.getParameter("skill_exp_2"));	
			    String logicalOp = request.getParameter("logical_op");
			    
			    if (logicalOp.equals("AND")) {
			    	logicalOp = "&";
			    } else if (logicalOp.equals("OR")) {
			    	logicalOp = "|";
			    }
			    
			    String skillExpCME1 = SkillObject.getSkillExpressionCME(skillExpId1, tenantDbid, dbConn);
			    String skillExpCME2 = SkillObject.getSkillExpressionCME(skillExpId2, tenantDbid, dbConn);
			    
			    
			    String skillExpList1 = SkillObject.getSkillExpression(skillExpId1, tenantDbid, dbConn);
			    String skillExpList2 = SkillObject.getSkillExpression(skillExpId2, tenantDbid, dbConn);
			    
			    String complexSkillExpressionCME = "(" + skillExpCME1 + " " + logicalOp + " " + skillExpCME2 + ")";
			    
			    String complexSkillExpressionList = "(" + skillExpList1 + logicalOp + skillExpList2 + ")";
			    
			    boolean skillExpressionCreated = SkillObject.createSkillExpression(complexSkillExpressionCME, complexSkillExpressionList, tenantDbid, dbConn);
			    
			    request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				if (skillExpressionCreated) {
					request.getRequestDispatcher("WebContent/skillExpressionNew.jsp?skill_expression_created=true").include(request, response);
				} else {
					request.getRequestDispatcher("WebContent/skillExpressionNew.jsp?skill_expression_created=false").include(request, response);
				}  	
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
				
		    }  else if (action.equals("get_agents_with_skill_exp")){
		    			    	
		    	String skillExpressionIdString = (request.getParameter("expid"));
		    	int skillExpressionId = Integer.parseInt(skillExpressionIdString);
		    	int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				IConfService confService = (IConfService) session.getAttribute("confService");
				int testAgentGroupDbid = (Integer) session.getAttribute("testAgentGroupDbid");
		    	
				String numAgents = SkillObject.getNumAgentsWithSkillExpression(skillExpressionId, tenantDBID, testAgentGroupDbid, confService, dbConn);
				
				
				session.setAttribute("string",numAgents);
		    	request.getRequestDispatcher("WebContent/returnString.jsp").include(request, response);
		    	
		    } else if (action.equals("get_agents_with_skill_exp_string")){
			    String skill = request.getParameter("skill");
			    String operator = request.getParameter("operator");	
			    String level = request.getParameter("level");
			    
			    if (operator.equals("eq")){
			    	operator = "=";
			    } else if (operator.equals("gt")){
			    	operator = ">";
			    } else if (operator.equals("gte")){
			    	operator = ">=";
			    } else if (operator.equals("lt")){
			    	operator = "<";
			    } else if (operator.equals("lte")){
			    	operator = "<=";
			    }
			    
			    String skillExpression = "Skill(\"" + skill + "\")" + operator + level;
			    
				int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				IConfService confService = (IConfService) session.getAttribute("confService");
				
				int testAgentGroupDbid = (Integer) session.getAttribute("testAgentGroupDbid");
				String numAgents = SkillObject.getNumAgentsWithSkillExpressionString(skillExpression, tenantDBID, testAgentGroupDbid, confService);
				
				
				session.setAttribute("string",numAgents);
				request.getRequestDispatcher("WebContent/returnString.jsp").include(request, response);
			
			} else if (action.equals("get_agents_with_complex_skill_exp")) {
				int tenantDbid = (Integer) session.getAttribute("tenantDBID");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				IConfService confService = (IConfService) session.getAttribute("confService");
				
				int skillExpId1 = Integer.parseInt(request.getParameter("skill_exp_1"));
			    int skillExpId2 = Integer.parseInt(request.getParameter("skill_exp_2"));	
			    String logicalOp = request.getParameter("logical_op");
			    
			    if (logicalOp.equals("AND")) {
			    	logicalOp = "&";
			    } else if (logicalOp.equals("OR")) {
			    	logicalOp = "|";
			    }
			    
			    String skillExp1 = SkillObject.getSkillExpressionCME(skillExpId1, tenantDbid, dbConn);
			    String skillExp2 = SkillObject.getSkillExpressionCME(skillExpId2, tenantDbid, dbConn);
			    
			    
			    String complexSkillExpression = "(" + skillExp1 + " " + logicalOp + " " + skillExp2 + ")";
			    
			    int testAgentGroupDbid = (Integer) session.getAttribute("testAgentGroupDbid");
				String numAgents = SkillObject.getNumAgentsWithSkillExpressionString(complexSkillExpression, tenantDbid, testAgentGroupDbid, confService);
			    
				session.setAttribute("string",numAgents);
				request.getRequestDispatcher("WebContent/returnString.jsp").include(request, response);
				
			} else if (action.equals("logout")){
				session.invalidate();
				request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/logout.jsp").include(request, response);
				request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
			
		    } else if (action.equals("list_agents_in_group")) {
				IConfService confService = (IConfService) session.getAttribute("confService");
				int agentGroupDbid = Integer.parseInt(request.getParameter("group_id"));
				
				ArrayList<String> agents = AgentGroupObject.getMembersOfAgentGroup(agentGroupDbid, confService);
				
				session.setAttribute("agents",agents);
				
				request.getRequestDispatcher("WebContent/listAgentsInGroup.jsp").include(request, response);
				
		    } else if (action.equals("del_skill_exp")){
		    	
		    	int skillExpressionId = Integer.parseInt(request.getParameter("expid"));
		    	int tenantDBID = (Integer) session.getAttribute("tenantDBID");
				Connection dbConn = (Connection) session.getAttribute("dbConnection");
				IConfService confService = (IConfService) session.getAttribute("confService");
				
		    	
				boolean skillDeleted = SkillObject.delSkillExpression(skillExpressionId, dbConn);
				
				if (skillDeleted) {
					session.setAttribute("string","Skill Deleted");
				} else {
					session.setAttribute("string","Skill Not Deleted");
				}
				
		    	
				request.getRequestDispatcher("WebContent/returnString.jsp").include(request, response);
		    	
		    } else if (action.equals("test_stuff")){
		    	IConfService confSerivce = (IConfService) session.getAttribute("confService");
		    	int tenantDBID = (Integer) session.getAttribute("tenantDBID");
		    	Connection dbConn = (Connection) session.getAttribute("dbConnection");
		    	//int folderType = CfgObjectType.CFGSkill.ordinal();
		    	
		    	Map<String, Integer> rootSkillFolders = new TreeMap<String, Integer>();
		    	
		    	int folderType = CfgObjectType.CFGSkill.ordinal();
		    	
		    	rootSkillFolders = FolderObject.getRootFolders(confSerivce, folderType, tenantDBID);
		    	
			} else if (dispatchUrl != null) {

				RequestDispatcher rd = 
						request.getRequestDispatcher(dispatchUrl);
				rd.forward(request, response);
			}
		}
		
		else {
			session.invalidate();
			request.getRequestDispatcher("WebContent/header.jsp").include(request, response);
			request.getRequestDispatcher("WebContent/loginForm.jsp").include(request, response);
			request.getRequestDispatcher("WebContent/footer.jsp").include(request, response);
		}
	}
}
