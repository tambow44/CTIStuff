package controller;

import java.util.Map;

public class JSON {
	public static String getJSONString(Map<String,Integer> itemMap) {
		String jsonString = "";
		
		String key = "";
		int value = 0;
		
		for (Map.Entry<String, Integer> item : itemMap.entrySet()) {
			key = item.getKey();
			value = item.getValue();
			jsonString = jsonString +"<option value=\"" + key + "\">" + key + "</option>";
		}
		
		return jsonString;
		
	}
}
