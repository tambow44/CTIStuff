//===============================================================================
// Any authorized distribution of any copy of this code (including any related
// documentation) must reproduce the following restrictions, disclaimer and copyright
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name
// (even as a part of another name), endorse and/or promote products derived from
// this code without prior written permission from Genesys Telecommunications
// Laboratories, Inc.

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys
// Developer License Agreement.  This code shall not be used, copied, and/or
// distributed under any other license agreement.

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC.
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT,
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2009 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
package controller;

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTransaction;

import com.genesyslab.platform.applicationblocks.com.queries.CfgTransactionQuery;

import com.genesyslab.platform.applicationblocks.commons.Action;

import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.collections.KeyValueCollection;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Sample methods for reading information from the configuration server.
 *
 * @author <a href="mailto:makagon@genesyslab.com">Petr Makagon</a>
 * @author <a href="mailto:vladb@genesyslab.com">Vladislav Baranovsky</a>
 * @author <a href="mailto:afilatov@genesyslab.com">Alexander Filatov</a>
 * @author <a href="mailto:abrazhny@genesyslab.com">Anton Brazhnyk</a>
 * @author <a href="mailto:svolokh@genesyslab.com">Sergii Volokh</a>
 */

@WebServlet(name = "TransactionObject", urlPatterns = { 
		"/get_transaction", "/print_transaction", "/print_section",  "/print_option", "/update_kvp" })
        
public class TransactionObjectServlet extends HttpServlet {
	
	private static final long serialVersionUID = 61868146L;
	
	@Override
    public void doGet(HttpServletRequest request, 
            HttpServletResponse response)
            throws IOException, ServletException {
        process(request, response);
    }

	@Override
    public void doPost(HttpServletRequest request, 
            HttpServletResponse response)
            throws IOException, ServletException {
        process(request, response);
	}
	
    /**
     * Sample method to print information from read application configuration object.
     *
     * @param cfgApp application object to print
     * @param printPrefix string prefix to be printed before each line
     */
	
	private void process(HttpServletRequest request,
            HttpServletResponse response) 
            throws IOException, ServletException {
		String uri = request.getRequestURI();
        /*
         * uri is in this form: /contextName/resourceName, 
         * for example: /app10a/product_input. 
         * However, in the case of a default context, the 
         * context name is empty, and uri has this form
         * /resourceName, e.g.: /product_input
         */
        int lastIndex = uri.lastIndexOf("/");
        String action = uri.substring(lastIndex + 1); 
        String dispatchUrl = null;
		
		if (action.equals("get_transaction")) {
			dispatchUrl = "WebContent/transForm.jsp";
		} 
		else if(action.equals("print_transaction")) {
			HttpSession session = request.getSession();
			String transName = request.getParameter("transName");
			IConfService confSerivce = (IConfService) session.getAttribute("confService");
			
			CfgTransaction readApp = null;
			try {
				readApp = confSerivce.retrieveObject(CfgTransaction.class, new CfgTransactionQuery(transName));
			} catch (ConfigException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        // Read configuration application object:
	    	KeyValueCollection appOptions = readApp.getUserProperties();
	    	PrintWriter out = response.getWriter();
	    	out.println(
	    			"<html>" +
	    			"<head>" +
	    			"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">" +
	    			"<title>Insert title here</title>" +
	    			"</head>" +
	    			"<body>" +
	    			"<table border=\"1\">" +
	    			"<tr>" +
	    			"<td colspan=\"2\">" +
	    			"transName" +
	    			"</td>" +
	    			"</tr>"
	    	
	    	);
	    	for (Object sectionObj : appOptions) {
	            KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
	            out.println("<tr><td>" + sectionKvp.getStringKey() + "</td><td></td></tr>");
	            for (Object recordObj : sectionKvp.getTKVValue()) {
	                KeyValuePair recordKvp = (KeyValuePair) recordObj;
	                out.println("<tr><td>"
	                        + recordKvp.getStringKey() + "</td><td>"
	                        + "<a href=\"/GLOT/update_kvp?trans="+transName+"&section="+sectionKvp.getStringKey()+"&key="+recordKvp.getStringKey()+"&value="+recordKvp.getStringValue()+"_new\">"+recordKvp.getStringValue() + "</a></td></tr>");
	            }
	        }
	    	out.println("</table>" +
	    			"</body>" +
	    			"</html>");
		}
		else if (action.equals("update_kvp")) {
			HttpSession session = request.getSession();
			PrintWriter out = response.getWriter();
			String transName = request.getParameter("trans");
			out.println(transName);
			String sectionName = request.getParameter("section");
			out.println(sectionName);
			String optionKey = request.getParameter("key");
			out.println(optionKey);
			String optionValue = request.getParameter("value");
			out.println(optionValue);
			
			IConfService confSerivce = (IConfService) session.getAttribute("confService");
			
			CfgTransaction readTransaction = null;
			
			try {
				// get Transaction object from Cfg server
				readTransaction = confSerivce.retrieveObject(CfgTransaction.class, new CfgTransactionQuery(transName));
			} catch (ConfigException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				String errorMessage = e.toString();
				out.println(errorMessage);
			}
			
			// Get collection of sections from transaction
			KeyValueCollection transaction_list = readTransaction.getUserProperties();
			
			// Get specific section kvp from sections collection
			KeyValuePair section_pair = transaction_list.getPair(sectionName);
			
			// Get options collection from specific section kvp
			KeyValueCollection section_kvpcol = section_pair.getTKVValue();
			
			// Get specific option kvp from options collection
			KeyValuePair old_kvp = section_kvpcol.getPair(optionKey);
			out.println(old_kvp.getStringKey()+": "+old_kvp.getStringValue());
			
			// Remove this option from options collection
			section_kvpcol.remove(optionKey);
			
			// Create new option kvp
			KeyValuePair new_kvp = new KeyValuePair(optionKey,optionValue);
			
			// Add created option to options collection
			section_kvpcol.addPair(new_kvp);
			
			// Set section kvp collection to updated collection
			section_pair.setTKVValue(section_kvpcol);
			
			// Remove this section from sections collection
			transaction_list.remove(sectionName);
						
			// Add updated section to sections collection 
			transaction_list.addPair(section_pair);
			
			// Update the transaction object with the updated sections collection 
			readTransaction.setUserProperties(transaction_list);
			
			// Save the changes.
			try {
				readTransaction.save();
			} catch (ConfigException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				String errorMessage = e.toString();
				out.println(errorMessage);
			}
			
			out.println("Done, I guess?");
		}
			
	}
	
    public static void printShortCfgTransaction(
            final CfgTransaction cfgTrans,
            final String printPrefix) {
        System.out.println(printPrefix + "CfgTransaction:");

        System.out.println(printPrefix + "    name               = " + cfgTrans.getName());
        System.out.println(printPrefix + "    dbid               = " + cfgTrans.getDBID());
        System.out.println(printPrefix + "    type               = " + cfgTrans.getType());
        System.out.println(printPrefix + "    description        = " + cfgTrans.getDescription());
        System.out.println(printPrefix + "    alias              = " + cfgTrans.getObjectPath());
        System.out.println(printPrefix + "    state              = " + cfgTrans.getState());
        }

    /**
     * Sample method to print extended information from read application configuration object.
     * This method also gets from the configuration server refered configuration application objects
     * and prints short information about that objects. This infromation is read on request
     * and we do not need to specify configuration service by itself or do something for this -
     * it is used from the main application object behind the scene.
     *
     * @param cfgApp application object to print
     */
    public static void printCfgApplication(
            final CfgTransaction cfgTrans) {
    	printShortCfgTransaction(cfgTrans, "");

        // Print all options:
        System.out.println("    options            = {");
        KeyValueCollection appOptions = cfgTrans.getUserProperties();
        for (Object sectionObj : appOptions) {
            KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
            System.out.println("        Section \"" + sectionKvp.getStringKey() + "\" = {");
            for (Object recordObj : sectionKvp.getTKVValue()) {
                KeyValuePair recordKvp = (KeyValuePair) recordObj;
                System.out.println("            \""
                        + recordKvp.getStringKey() + "\" = \""
                        + recordKvp.getStringValue() + "\"");
            }
            System.out.println("        }");
        }
        System.out.println("    }");
    }

    /**
     * Read application configuration object and print it.
     *
     * @param service configuration service instance
     * @param appName name of application to read and print
     * @throws ConfigException in case of exception while reading object
     */
    public static void readAndPrintCfgApplication(
            final IConfService service,
            final String transName)
                throws ConfigException {
        // Read configuration application object:
    	CfgTransaction readApp = service.retrieveObject(CfgTransaction.class,
                new CfgTransactionQuery(transName));

        printCfgApplication(readApp);
    }
    public static void readAndPrintOptions(
            final IConfService service,
            final String transName)
                throws ConfigException {
        // Read configuration application object:
    	CfgTransaction readApp = service.retrieveObject(CfgTransaction.class,
                new CfgTransactionQuery(transName));

    	printOptions(readApp);
    }
    public static void printOptions (final CfgTransaction cfgTrans) {
    	
    	//list options
    	KeyValueCollection appOptions = cfgTrans.getUserProperties();
    	for (Object sectionObj : appOptions) {
            KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
            System.out.println("        Section \"" + sectionKvp.getStringKey() + "\" = {");
            for (Object recordObj : sectionKvp.getTKVValue()) {
                KeyValuePair recordKvp = (KeyValuePair) recordObj;
                System.out.println("            \""
                        + recordKvp.getStringKey() + "\" = \""
                        + recordKvp.getStringValue() + "\"");
            }
            System.out.println("        }");
        }
    }
    
}
