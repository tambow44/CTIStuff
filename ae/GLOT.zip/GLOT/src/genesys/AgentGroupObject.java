package genesys;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgAgentGroup;
import com.genesyslab.platform.applicationblocks.com.objects.CfgPerson;
import com.genesyslab.platform.applicationblocks.com.queries.CfgAgentGroupQuery;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;

public class AgentGroupObject {
	static CfgAgentGroup getAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		CfgAgentGroupQuery agentGroupQuery = new CfgAgentGroupQuery(confService);
		agentGroupQuery.setDbid(agentGroupDbid);
		CfgAgentGroup agentGroup = agentGroupQuery.executeSingleResult();
		return agentGroup;
	}
	
	// Update the test agent group's skill expression for testing
	public static boolean updateTestAgentGroup(String skillExpression, int testAgentGroupDbid, IConfService confService) throws ConfigException{
		boolean groupUpdated = false;
		
		CfgAgentGroup testAgentGroup = getAgentGroup(testAgentGroupDbid, confService);
		
		KeyValueCollection testAGUserProperites = testAgentGroup.getGroupInfo().getUserProperties();
		
		KeyValuePair section_pair = testAGUserProperites.getPair("virtual");
		
		// Get options collection from specific section kvp
		KeyValueCollection section_kvpcol = section_pair.getTKVValue();
		
		// Remove this option from options collection
		section_kvpcol.remove("script");
		
		// Create new option kvp
		KeyValuePair new_kvp = new KeyValuePair("script",skillExpression);
		
		// Add created option to options collection
		section_kvpcol.addPair(new_kvp);
		
		// Set section kvp collection to updated collection
		section_pair.setTKVValue(section_kvpcol);
		
		// Remove this section from sections collection
		testAGUserProperites.remove("virtual");
					
		// Add updated section to sections collection 
		testAGUserProperites.addPair(section_pair);
		
		// Update the transaction object with the updated sections collection 
		testAgentGroup.getGroupInfo().setUserProperties(testAGUserProperites);
		
		try {
			testAgentGroup.save();
			groupUpdated = true;
		} catch (ConfigException e) {
			System.out.println(e.getMessage());
			groupUpdated = false;
		}
		
		return groupUpdated;
	}
	
	// Get the number of agents in an agent group.
	public static int getNumMembersInAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		int numAgents = 0;
		
		CfgAgentGroup agentGroup = getAgentGroup(agentGroupDbid, confService);
		
		if (agentGroup.getAgentDBIDs() != null) {
			numAgents = agentGroup.getAgentDBIDs().size();
		} else {
			numAgents = 0;
		}
		
		return numAgents;
	}
	
	// get list of agents in an agent group (first name last name in alphabetical order).
	public static ArrayList<String> getMembersOfAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		ArrayList<String> agents = new ArrayList<String>();
		
		CfgAgentGroup agentGroup = getAgentGroup(agentGroupDbid, confService);
		
		Collection<CfgPerson> personCollection = agentGroup.getAgents();
		
		
		for (CfgPerson thisPerson : personCollection) {
			agents.add(thisPerson.getFirstName() + " " + thisPerson.getLastName());
		}
		
		Collections.sort(agents);
		
		return agents;
	}
}
