package genesys;

import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgAccessGroup;
import com.genesyslab.platform.applicationblocks.com.objects.CfgPerson;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTenant;

import com.genesyslab.platform.applicationblocks.com.queries.CfgAccessGroupQuery;
import com.genesyslab.platform.applicationblocks.com.queries.CfgPersonQuery; 

public class AgentInfo {
	public static int getPersonTenant(String personLogin, final IConfService confService) throws InterruptedException, ConfigException{
		
		CfgPerson readPerson = null;
		CfgPersonQuery personQuery = new CfgPersonQuery(confService);
        personQuery.setUserName(personLogin);
        
		readPerson = personQuery.executeSingleResult();
				
		CfgTenant personTenant = readPerson.getTenant();
				
		return personTenant.getDBID();
		
	}
	
	public static int getPersonDbid(String personLogin, IConfService confService) throws ConfigException{
		int personDbid = 0;
		
		CfgPerson readPerson = null;
		CfgPersonQuery personQuery = new CfgPersonQuery(confService);
        personQuery.setUserName(personLogin);
        
		readPerson = personQuery.executeSingleResult();
		
		personDbid = readPerson.getDBID();
		
		return personDbid;
		
	}
	
	public static boolean checkSuperAdmin(int personDbid, IConfService confService) throws ConfigException {
		boolean isSuperAdmin = false;
		
		CfgAccessGroupQuery accessGroupQuery = new CfgAccessGroupQuery(confService);
		
		accessGroupQuery.setName("Super Administrators");
		accessGroupQuery.setPersonDbid(personDbid);
		
		CfgAccessGroup accessGroup = accessGroupQuery.executeSingleResult();
		
		if (accessGroup != null) {
			isSuperAdmin = true;
		}
		
		return isSuperAdmin;
	}
	
}
