package genesys;

import java.util.Collection;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgFolder;
import com.genesyslab.platform.applicationblocks.com.objects.CfgObjectID;

import com.genesyslab.platform.applicationblocks.com.queries.CfgFolderQuery;

import com.genesyslab.platform.configuration.protocol.types.CfgObjectType;


public class FolderObject {
	
	// Return list of folders (Name and DBID) of an object type from a tenant.
	public Map<String, Integer> getFolders(IConfService confService, int folderType, int tenantDBID) throws ConfigException, InterruptedException{
		
		SortedMap<String, Integer> folderMap = new TreeMap<String, Integer>();
		
		CfgFolderQuery folderQuery = new  CfgFolderQuery(confService);
		
		folderQuery.setType(folderType);
		folderQuery.setOwnerType(CfgObjectType.CFGTenant.ordinal());
		folderQuery.setOwnerDbid(tenantDBID);
		
		Collection<CfgFolder> folderCollection = folderQuery.execute();
		
		int folderDbid;
		String folderName;
		
		for(CfgFolder folder : folderCollection) {
			folderDbid = folder.getDBID();
			folderName = folder.getName();
			
			folderMap.put(folderName, folderDbid);
		}
		
		return folderMap;
		
	}
	
	// Return a folder's name when given the folder's DBID.
	public String getFolderName(int folderDbid, IConfService confService) throws ConfigException{
		CfgFolderQuery folderQuery = new  CfgFolderQuery(confService);
		
		folderQuery.setDbid(folderDbid);
		
		CfgFolder folder = folderQuery.executeSingleResult();
		
		return folder.getName(); 
		
	}
	
	// Return a root folder's DBID when given the folder name and the tenant DBID
	public int getRootFolderDbid(String folderName, int tenantDbid, IConfService confService) throws ConfigException{
		CfgFolderQuery folderQuery = new  CfgFolderQuery(confService);
		
		folderQuery.setName(folderName);
		folderQuery.setOwnerType(CfgObjectType.CFGTenant.ordinal());
		folderQuery.setOwnerDbid(tenantDbid);
		folderQuery.setDefaultFolder(1);
		
		CfgFolder folder = folderQuery.executeSingleResult();
		
		return folder.getObjectDbid();
	}
	
	// Return a folder's DBID when given the folder name and the parent folder's DBID
	public int getSubFolderDbid(String folderName, int parentFolderDBID, IConfService confService) throws ConfigException{
		
		int folderDBID = 0;
		
		CfgFolderQuery parentFolderQuery = new  CfgFolderQuery(confService);
		parentFolderQuery.setDbid(parentFolderDBID);
		CfgFolder parentFolder = parentFolderQuery.executeSingleResult();
		Collection<CfgObjectID> childFolders = parentFolder.getObjectIDs();
		
		// Create a query to get each child folder
		CfgFolderQuery childFolderQuery = new  CfgFolderQuery(confService);
		CfgFolder childFolder = new CfgFolder(confService);
		
		int childFolderDbid = 0;
		String childFolderName = "";
		
		// loop through child objects and if the object is a folder get its name
		for(CfgObjectID folder : childFolders) {
			if (folder.getType() == CfgObjectType.CFGFolder) {
				childFolderDbid = folder.getDBID();
				childFolderQuery.setDbid(childFolderDbid);
				childFolder = childFolderQuery.executeSingleResult();
				childFolderName = childFolder.getName();	
				// then if the name matches the requested folder name set the return DBID
				if (childFolderName.equals(folderName)) {
					folderDBID = childFolderDbid;
				}
			}
		}
		
		return folderDBID;
	}
	
	
	// Returns top level folders (Name and DBID) of an object type from a tenant.
	public static Map<String, Integer> getRootFolders(IConfService confService, int folderType, int tenantDBID) throws ConfigException, InterruptedException{
		
		SortedMap<String, Integer> folderMap = new TreeMap<String, Integer>();
		
		// Create a query to get the root folder type folder
		CfgFolderQuery rootFolderQuery = new CfgFolderQuery(confService);
		
		rootFolderQuery.setOwnerType(CfgObjectType.CFGTenant.ordinal());
		rootFolderQuery.setType(folderType);
		rootFolderQuery.setOwnerDbid(tenantDBID);
		rootFolderQuery.setDefaultFolder(1);
		
		CfgFolder rootFolder = rootFolderQuery.executeSingleResult();
		
		// Now we have the root folder of this type get the objects immediately below.
		Collection<CfgObjectID> childFolders = rootFolder.getObjectIDs();
		
		// Create a query to get each child folder
		CfgFolderQuery childFolderQuery = new  CfgFolderQuery(confService);
		CfgFolder childFolder = new CfgFolder(confService);
		
		int folderDbid = 0;
		String folderName = "";
		
		// loop through child objects and if the object is a folder get its DBID and name
		for(CfgObjectID folder : childFolders) {
			if (folder.getType() == CfgObjectType.CFGFolder) {
				folderDbid = folder.getDBID();
				childFolderQuery.setDbid(folderDbid);
				childFolder = childFolderQuery.executeSingleResult();
				folderName = childFolder.getName();	
				folderMap.put(folderName, folderDbid);
			}
		}
		
		return folderMap;
	}
	
	// Returns folders (Name and DBID) within a folder from a tenant.
		public Map<String, Integer> getFolderFolders(IConfService confService, int parentFolderDBID, int tenantDBID) throws ConfigException, InterruptedException{
			
			SortedMap<String, Integer> folderMap = new TreeMap<String, Integer>();
			
			CfgFolderQuery folderQuery = new  CfgFolderQuery(confService);
			
			folderQuery.setDbid(parentFolderDBID);
			
			CfgFolder parentFolder = folderQuery.executeSingleResult();
			
			Collection<CfgObjectID> childFolders = parentFolder.getObjectIDs();
			
			// Create a query to get each child folder
			CfgFolderQuery childFolderQuery = new  CfgFolderQuery(confService);
			CfgFolder childFolder = new CfgFolder(confService);
			
			int folderDbid = 0;
			String folderName = "";
			
			for(CfgObjectID folder : childFolders) {
				if (folder.getType() == CfgObjectType.CFGFolder) {
					folderDbid = folder.getDBID();
					childFolderQuery.setDbid(folderDbid);
					childFolder = childFolderQuery.executeSingleResult();
					folderName = childFolder.getName();	
					folderMap.put(folderName, folderDbid);
				}
			}
			
			return folderMap;
			
		}
	
}
