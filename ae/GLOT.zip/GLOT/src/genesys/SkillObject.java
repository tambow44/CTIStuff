package genesys;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgSkill;

import com.genesyslab.platform.applicationblocks.com.queries.CfgSkillQuery;

public class SkillObject {
	public String getSkillName(int skillDbid, IConfService confService) throws ConfigException{
		String skillName;
		
		CfgSkillQuery skillQuery = new CfgSkillQuery(confService);
		
		skillQuery.setDbid(skillDbid);
		
		CfgSkill skill = skillQuery.executeSingleResult();
		
		skillName = skill.getName();
		
		return skillName;
	}
	
	public int getSkillDbid(String skillName, int tenantDbid, IConfService confService) throws ConfigException{
		int skillDbid = 0;
		
		CfgSkillQuery skillQuery = new CfgSkillQuery(confService);
		
		skillQuery.setTenantDbid(tenantDbid);
		skillQuery.setName(skillName);
		
		CfgSkill skill = skillQuery.executeSingleResult();
		
		skillDbid = skill.getObjectDbid();
		
		return skillDbid;
	}
	
	public static Map<String, Integer> getTenantSkills(int tenantDbid, IConfService confService) throws ConfigException, InterruptedException{
		
		SortedMap<String, Integer> skillMap = new TreeMap<String, Integer>();
		
		CfgSkillQuery skillQuery = new CfgSkillQuery(confService);
		
		skillQuery.setTenantDbid(tenantDbid);
		
		Collection<CfgSkill> skillCollection = skillQuery.execute();
		
		int skillDbid;
		String skillName;
		
		for(CfgSkill skill : skillCollection) {
			skillDbid = skill.getDBID();
			skillName = skill.getName();
			
			skillMap.put(skillName, skillDbid);
		}
		
		return skillMap;
	}
	
	public static Map<String, Integer> getFolderSkills(int folderDbid, int tenantDbid, IConfService confService) throws ConfigException, InterruptedException{
		SortedMap<String, Integer> skillMap = new TreeMap<String, Integer>();
		
		// Get complete list of skills for this tenant
		Map<String, Integer> skillCollection = getTenantSkills(tenantDbid, confService);
		
		String thisSkillName;
		int thisSkillDbid;
		
		CfgSkill thisSkill;
		
		CfgSkillQuery thisSkillQuery = new CfgSkillQuery(confService);
		
		// loop through skills checking if they are in the selected folder.
		for (Entry<String, Integer> thisSkillPair : skillCollection.entrySet()) {
			thisSkillName = thisSkillPair.getKey();
			thisSkillDbid = thisSkillPair.getValue();
			
			thisSkillQuery.setDbid(thisSkillDbid);
			
			thisSkill = thisSkillQuery.executeSingleResult();
			
			// check if the folder id for this skill is the folder id provided and add to Map if it is.
			if (thisSkill.getFolderId() == folderDbid) {
				skillMap.put(thisSkillName, thisSkillDbid);
			}
			
		}
		
		return skillMap;
	}
	
	public static String getSkillExpression(int skillExpressionId, int tenantDbid, Connection dbConn) throws SQLException {
		
		String skillExpression = "";
		
		String skillExpressionQuery = "SELECT EXP_STRING " +
				"FROM SKILL_EXPRESSION " +
				"WHERE ID = " + skillExpressionId + " " +
				"AND TENANT_DBID = " + tenantDbid;	
		Statement skillExpressionQueryStmt = dbConn.createStatement();
		ResultSet skillExpressionQueryResult;
		skillExpressionQueryResult = skillExpressionQueryStmt.executeQuery(skillExpressionQuery);
		while( skillExpressionQueryResult.next() ) {
			skillExpression = skillExpressionQueryResult.getString(1);
		}
		return skillExpression;
	}
	
	public static String getSkillExpressionCME(int skillExpressionId, int tenantDbid, Connection dbConn) throws SQLException {
		
		String skillExpression = "";
		
		String skillExpressionQuery = "SELECT EXPRESSION " +
				"FROM SKILL_EXPRESSION " +
				"WHERE ID = " + skillExpressionId + " " +
				"AND TENANT_DBID = " + tenantDbid;	
		Statement skillExpressionQueryStmt = dbConn.createStatement();
		ResultSet skillExpressionQueryResult;
		skillExpressionQueryResult = skillExpressionQueryStmt.executeQuery(skillExpressionQuery);
		while( skillExpressionQueryResult.next() ) {
			skillExpression = skillExpressionQueryResult.getString(1);
		}
		return skillExpression;
	}
	
	public static Map<String, Integer> getSkillExpressions(int tenantDbid, Connection dbConn) throws NumberFormatException, SQLException{
		
		SortedMap<String, Integer> skillExpressions = new TreeMap<String,Integer>();
		
		String skillExpressionQuery = "SELECT EXP_STRING, ID " +
				"FROM SKILL_EXPRESSION " +
				"WHERE TENANT_DBID = " + tenantDbid;	
		Statement skillExpressionQueryStmt = dbConn.createStatement();
		ResultSet skillExpressionQueryResult;
		skillExpressionQueryResult = skillExpressionQueryStmt.executeQuery(skillExpressionQuery);
		
		String skillExpression = "";
		int skillExpressionID = 0;
		
		while( skillExpressionQueryResult.next() ) {
			skillExpression = skillExpressionQueryResult.getString(1);
			skillExpressionID = Integer.parseInt(skillExpressionQueryResult.getString(2));
			
			skillExpressions.put(skillExpression, skillExpressionID);
			
		}
		return skillExpressions;
		
	}
	
	public static String getNumAgentsWithSkillExpression(int skillExpressionId, int tenantDbid, int testAgentGroupDbid, IConfService confService, Connection dbConn) throws ConfigException, SQLException {
		String numAgentsString = "";
		String skillExpression = getSkillExpressionCME(skillExpressionId, tenantDbid, dbConn);
		
		AgentGroupObject.updateTestAgentGroup(skillExpression, testAgentGroupDbid, confService);
						
		int numAgents = AgentGroupObject.getNumMembersInAgentGroup(testAgentGroupDbid, confService);
		
		if (numAgents == 1) {
			numAgentsString = numAgents  + " agent matches this skill expression.";
		} else {
			numAgentsString = numAgents  + " agents match this skill expression.";
		}
		
		return numAgentsString;
	}

	public static String getNumAgentsWithSkillExpressionString(
			String skillExpression, int tenantDBID, int testAgentGroupDbid, IConfService confService) throws ConfigException {
		AgentGroupObject.updateTestAgentGroup(skillExpression, testAgentGroupDbid, confService);
		
		int numAgents = AgentGroupObject.getNumMembersInAgentGroup(testAgentGroupDbid, confService);
		String numAgentsString = "";
		
		Random rand = new Random();
		
		if (numAgents == 1) {
			numAgentsString =  "1 <a href=\"/GLOT/list_agents_in_group?group_id=" + testAgentGroupDbid + "&rand=" + rand.nextInt(1000000) + "\" onclick=\"return popitup('/GLOT/list_agents_in_group?group_id=" + testAgentGroupDbid + "&rand=" + rand.nextInt(1000000) + "')\">agent</a> matches this skill expression.";
		} else {
			numAgentsString = numAgents + " <a href=\"/GLOT/list_agents_in_group?group_id=" + testAgentGroupDbid + "&rand=" + rand.nextInt(1000000) + "\" onclick=\"return popitup('/GLOT/list_agents_in_group?group_id=" + testAgentGroupDbid + "&rand=" + rand.nextInt(1000000) + "')\">agents</a> match this skill expression.";
		}
		
		return numAgentsString;
		
	}
	
	public static boolean createSkillExpression(String skillExpressionCME, String skillExpressionList, int tenantDbid, Connection dbConn) throws SQLException {
		String skillExpressionCreateQuery = "INSERT INTO SKILL_EXPRESSION " +
				"(EXPRESSION, EXP_STRING, TENANT_DBID) " +
				"VALUES ('" + skillExpressionCME + "', '" + skillExpressionList + "', " + tenantDbid + ")";	
		Statement skillExpressionQueryStmt = dbConn.createStatement();
		
		try {
			skillExpressionQueryStmt.executeUpdate(skillExpressionCreateQuery);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

	public static boolean delSkillExpression(int skillExpressionId,
			Connection dbConn) throws SQLException {
		String skillExpressionDeleteQuery = "DELETE FROM SKILL_EXPRESSION " +
				"WHERE ID = " + skillExpressionId;
		
		Statement skillExpressionQueryStmt = dbConn.createStatement();
		
		try {
			skillExpressionQueryStmt.executeUpdate(skillExpressionDeleteQuery);
			skillExpressionQueryStmt.close();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}
