//===============================================================================
// Any authorized distribution of any copy of this code (including any related
// documentation) must reproduce the following restrictions, disclaimer and copyright
// notice:

// The Genesys name, trademarks and/or logo(s) of Genesys shall not be used to name
// (even as a part of another name), endorse and/or promote products derived from
// this code without prior written permission from Genesys Telecommunications
// Laboratories, Inc.

// The use, copy, and/or distribution of this code is subject to the terms of the Genesys
// Developer License Agreement.  This code shall not be used, copied, and/or
// distributed under any other license agreement.

// THIS CODE IS PROVIDED BY GENESYS TELECOMMUNICATIONS LABORATORIES, INC.
// ("GENESYS") "AS IS" WITHOUT ANY WARRANTY OF ANY KIND. GENESYS HEREBY
// DISCLAIMS ALL EXPRESS, IMPLIED, OR STATUTORY CONDITIONS, REPRESENTATIONS AND
// WARRANTIES WITH RESPECT TO THIS CODE (OR ANY PART THEREOF), INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NON-INFRINGEMENT. GENESYS AND ITS SUPPLIERS SHALL
// NOT BE LIABLE FOR ANY DAMAGE SUFFERED AS A RESULT OF USING THIS CODE. IN NO
// EVENT SHALL GENESYS AND ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT,
// CONSEQUENTIAL, ECONOMIC, INCIDENTAL, OR SPECIAL DAMAGES (INCLUDING, BUT
// NOT LIMITED TO, ANY LOST REVENUES OR PROFITS).

// Copyright (c) 2006 - 2009 Genesys Telecommunications Laboratories, Inc. All rights reserved.
//===============================================================================
package genesys;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import au.com.bytecode.opencsv.CSVWriter;

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTransaction;

import com.genesyslab.platform.applicationblocks.com.queries.CfgTransactionQuery;

import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.configuration.protocol.types.CfgTransactionType;

import controller.MapUtil;

public class TransactionObject {

	public static String getListObjectName(int listObjectDBID, int tenantDBID, IConfService confService) throws ConfigException{

		CfgTransaction readTrans = null;
		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confService);

		cfgTransactionQuery.setDbid(listObjectDBID);
		cfgTransactionQuery.setTenantDbid(tenantDBID);

		readTrans = cfgTransactionQuery.executeSingleResult();

		String listObjectName = readTrans.getName();

		return listObjectName;

	}

	public static String printTransaction(int listObjectDBID, int tenantDBID, IConfService confService) {

		String transOutput = "";
		CfgTransaction readTrans = null;
		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confService);

		cfgTransactionQuery.setDbid(listObjectDBID);
		cfgTransactionQuery.setTenantDbid(tenantDBID);

		try {
			readTrans = cfgTransactionQuery.executeSingleResult();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			transOutput = transOutput + e.getMessage();
		}
		// Read configuration transaction annex tab:

		KeyValueCollection transOptions = readTrans.getUserProperties();
		transOutput = transOutput +
				"<div id=\"header\">" + readTrans.getName() + "</div>" +
				"<table id=\"rounded-corner\">" +
				"<thead>" +
				"<tr>" +
				"<th scope=\"col\" class=\"rounded-left\">Option</th>" +
				"<th scope=\"col\" >Value</th>" +
				"<th scope=\"col\" class=\"rounded-right\">Action</th>" +
				"</tr>" +
				"</thead>";
		for (Object sectionObj : transOptions) {
			KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
			transOutput = transOutput + "<tr><td class=\"section\" colspan=\"3\">" + sectionKvp.getStringKey() + "</td></tr>";
			for (Object recordObj : sectionKvp.getTKVValue()) {
				KeyValuePair recordKvp = (KeyValuePair) recordObj;
				transOutput = transOutput + "<tr><td>"
						+ recordKvp.getStringKey() + "</td><td>"
						+ recordKvp.getStringValue() + "</td><td>" +
						" <a href=\"/GLOT/edit_option?trans="+listObjectDBID+"&section="+sectionKvp.getStringKey()+"&key="+recordKvp.getStringKey()+"&value="+recordKvp.getStringValue()+"\">edit</a></td></tr>";
			}
		}
		transOutput = transOutput + "</table>";
		return transOutput;
	}

	public static Map<String, Map<String, String>> listTransactionOptions(int listObjectDBID, 
			int tenantDBID, IConfService confService, Connection dbConn) throws ConfigException, SQLException {

		// Create sorted Map to return
		SortedMap<String, Map<String, String>> transactionList =  new TreeMap<String, Map<String, String>>();

		// Create transaction and transaction query objects
		CfgTransaction readTrans = null;
		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confService);
		
		// define query criteria and execute query to get transaction object		
		cfgTransactionQuery.setDbid(listObjectDBID);
		cfgTransactionQuery.setTenantDbid(tenantDBID);
		readTrans = cfgTransactionQuery.executeSingleResult();

		// Read configuration transaction annex tab:
		KeyValueCollection listObjectDetails = readTrans.getUserProperties();

		String sectionName = "";
		String sectionNameOrdered = "";
		int sectionOrder = 1000;
		String optionKey = "";
		String optionValue = "";
		String optionTypeName = "";
		String optionTypeID = "";
		String optionCSV = "";
		
		// setup sql query to get section order from the GLOT database.
		String psQuerySectionOrder = "SELECT S.SECTION_ORDER " +
				"FROM SECTION S, LIST_OBJECT L " +
				"WHERE L.ID = S.LIST_OBJECT_ID " +
				"AND L.TENANT_ID = " + tenantDBID + " "+
				"AND L.ID = " + listObjectDBID + " " +
				"AND S.NAME = ? ";
			
		PreparedStatement sectionOrderPStmt = dbConn.prepareStatement(psQuerySectionOrder);
		
		// setup sql query to get option type for options from the GLOT database.
		String psQueryOptionType = "SELECT TN.ID, TN.TYPE, TN.NAME " +
				"FROM TYPE_NAME TN, OPTION_NAME O, TENANTS T, SECTION S, LIST_OBJECT L " +
				"WHERE T.ID = L.TENANT_ID " +
				"AND L.ID = S.LIST_OBJECT_ID " +
				"AND S.ID = O.SECTION_ID " +
				"AND TN.ID = O.TYPE_ID " +
				"AND T.ID = " + tenantDBID + " "+
				"AND L.ID = " + listObjectDBID + " " +
				"AND S.NAME = ? " +
				"AND O.NAME = ? ";
			
		PreparedStatement optionTypePStmt = dbConn.prepareStatement(psQueryOptionType);
		
		// setup sql query to get alternate name for select options from the GLOT database.
		String psQueryAltName = "SELECT ALT_NAME " +
				"FROM TYPE_OPTION TON, OPTION_NAME O, TENANTS T, SECTION S, LIST_OBJECT L " +
				"WHERE T.ID = L.TENANT_ID " +
				"AND L.ID = S.LIST_OBJECT_ID " +
				"AND T.ID = " + tenantDBID + " " +
				"AND L.ID = " + listObjectDBID + " " +
				"AND S.ID = O.SECTION_ID " +
				"AND O.TYPE_ID = TON.TYPE_ID " +
				"AND S.NAME = ? " +
				"AND O.NAME = ? " + 
				"AND TON.NAME = ?";

		PreparedStatement optionAltNamePStmt = dbConn.prepareStatement(psQueryAltName);

		for (Object sectionObj : listObjectDetails) {
			KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
			sectionName = sectionKvp.getStringKey();
			
			sectionOrderPStmt.setString(1, sectionName);
			ResultSet sectionOrderQueryResult = sectionOrderPStmt.executeQuery();
			while( sectionOrderQueryResult.next() ) {
				sectionOrder = sectionOrderQueryResult.getInt(1);
			}
			
			sectionNameOrdered = sectionOrder + "_" + sectionName;
			
			SortedMap<String, String> optionKVP = new TreeMap<String, String>();

			for (Object recordObj : sectionKvp.getTKVValue()) {
				KeyValuePair recordKvp = (KeyValuePair) recordObj;

				optionKey = recordKvp.getStringKey();
				optionValue = recordKvp.getStringValue();

				optionTypePStmt.setString(1, sectionName);
				optionTypePStmt.setString(2, optionKey);
				ResultSet optionTypeQueryResult = optionTypePStmt.executeQuery();

				// Loop through the result set
				while( optionTypeQueryResult.next() ) {
					optionTypeID = optionTypeQueryResult.getString(1);
					optionTypeName = optionTypeQueryResult.getString(2);

					// if the option type is a SELECT then set the option value to the alt name 
					// this allows masking of underlying values when necessary
					if (optionTypeName.equals("SELECT")){
						optionAltNamePStmt.setString(1, sectionName);
						optionAltNamePStmt.setString(2, optionKey);
						optionAltNamePStmt.setString(3, optionValue);

						ResultSet queryAltNameResult = optionAltNamePStmt.executeQuery();
						while( queryAltNameResult.next()){
							optionValue = queryAltNameResult.getString(1);
						}
					}
				}	

				

				optionCSV = optionTypeID + "," + optionTypeName + "," + optionValue;
				
				optionKVP.put(optionKey, optionCSV);
			}

			transactionList.put(sectionNameOrdered, optionKVP);
		}
		sectionOrderPStmt.close();

		return transactionList;
	}

	public static boolean updateTransaction(int transID, String sectionName, String optionKey, String optionValue, int tenantDBID, IConfService confSerivce) {

		boolean listObjectupdated = false;


		CfgTransaction readTransaction = null;

		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confSerivce);

		cfgTransactionQuery.setTenantDbid(tenantDBID);
		cfgTransactionQuery.setDbid(transID);


		try {
			// get Transaction object from Cfg server
			readTransaction = cfgTransactionQuery.executeSingleResult();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String errorMessage = e.toString();
			System.out.println(errorMessage);
			listObjectupdated = false;
		}

		// Get collection of sections from transaction
		KeyValueCollection transaction_list = readTransaction.getUserProperties();

		// Get specific section kvp from sections collection
		KeyValuePair section_pair = transaction_list.getPair(sectionName);

		// Get options collection from specific section kvp
		KeyValueCollection section_kvpcol = section_pair.getTKVValue();

		// Get specific option kvp from options collection
		KeyValuePair old_kvp = section_kvpcol.getPair(optionKey);

		// Remove this option from options collection
		section_kvpcol.remove(optionKey);

		// Create new option kvp
		KeyValuePair new_kvp = new KeyValuePair(optionKey, optionValue);

		// Add created option to options collection
		section_kvpcol.addPair(new_kvp);

		// Set section kvp collection to updated collection
		section_pair.setTKVValue(section_kvpcol);

		// Remove this section from sections collection
		transaction_list.remove(sectionName);

		// Add updated section to sections collection 
		transaction_list.addPair(section_pair);

		// Update the transaction object with the updated sections collection 
		readTransaction.setUserProperties(transaction_list);

		// Save the changes.
		try {
			readTransaction.save();
			listObjectupdated = true;
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String errorMessage = e.toString();
			System.out.println(errorMessage);
			listObjectupdated = false;
		}

		return listObjectupdated;
	}

	public static void printShortCfgTransaction(
			final CfgTransaction cfgTrans,
			final String printPrefix) {
		System.out.println(printPrefix + "CfgTransaction:");

		System.out.println(printPrefix + "    name               = " + cfgTrans.getName());
		System.out.println(printPrefix + "    dbid               = " + cfgTrans.getDBID());
		System.out.println(printPrefix + "    type               = " + cfgTrans.getType());
		System.out.println(printPrefix + "    description        = " + cfgTrans.getDescription());
		System.out.println(printPrefix + "    alias              = " + cfgTrans.getObjectPath());
		System.out.println(printPrefix + "    state              = " + cfgTrans.getState());
	}


	public static void readAndPrintOptions(
			final IConfService service,
			final String transName)
					throws ConfigException {
		// Read configuration application object:
		CfgTransaction readApp = service.retrieveObject(CfgTransaction.class,
				new CfgTransactionQuery(transName));

		printOptions(readApp);
	}
	public static void printOptions (final CfgTransaction cfgTrans) {

		//list options
		KeyValueCollection appOptions = cfgTrans.getUserProperties();
		for (Object sectionObj : appOptions) {
			KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
			System.out.println("        Section \"" + sectionKvp.getStringKey() + "\" = {");
			for (Object recordObj : sectionKvp.getTKVValue()) {
				KeyValuePair recordKvp = (KeyValuePair) recordObj;
				System.out.println("            \""
						+ recordKvp.getStringKey() + "\" = \""
						+ recordKvp.getStringValue() + "\"");
			}
			System.out.println("        }");
		}
	}


	public static ArrayList<String> getSections(int transObjectDBID, int tenantDBID,
			IConfService confService) {

		ArrayList<String> sections = new ArrayList<String>();
		CfgTransaction readTrans = null;
		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confService);

		cfgTransactionQuery.setDbid(transObjectDBID);
		cfgTransactionQuery.setTenantDbid(tenantDBID);

		try {
			readTrans = cfgTransactionQuery.executeSingleResult();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
		}
		// Read configuration transaction annex tab:

		KeyValueCollection transOptions = readTrans.getUserProperties();


		// Add section names to array
		for (Object sectionObj : transOptions) {


			KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
			sections.add(sectionKvp.getStringKey()) ;
		}
		// Return array of section names.
		return sections;
	}


	public static Map<Integer, String> getTransObjectList(int tenantDBID,
			IConfService confService) throws ConfigException, InterruptedException {
		CfgTransactionQuery transQuery = new CfgTransactionQuery(confService);

		transQuery.setTenantDbid(tenantDBID);

		transQuery.setObjectType(CfgTransactionType.CFGTRTList);

		// Read all transaction objects for this tenant.
		Collection<CfgTransaction> transactionObjects = transQuery.execute();

		Map<Integer, String> transactionObjectList = new HashMap<Integer, String>();


		// Add transaction object name and id to kvp list
		for (CfgTransaction transactionObject : transactionObjects) {
			transactionObjectList.put(transactionObject.getDBID(), transactionObject.getName());
		}

		Map<Integer, String> sortedTransactionObjectList = MapUtil.sortByValue(transactionObjectList);

		//return kvp list of transaction objects and ids.
		return sortedTransactionObjectList;
	}


	public static void addTransObject(int tenantDBID, int listObjectDBID,
			int ctiOnly, IConfService confService, Connection dbConn) throws ConfigException, SQLException {
		CfgTransactionQuery transactionQuery = new CfgTransactionQuery(confService);

		transactionQuery.setDbid(listObjectDBID);

		CfgTransaction transaction = transactionQuery.executeSingleResult();

		String query = "INSERT INTO LIST_OBJECT VALUES (" + listObjectDBID + ", '" + transaction.getName() + "', " + tenantDBID + ", " + ctiOnly + ")";


		Statement stmt = dbConn.createStatement();

		stmt.execute(query);
		stmt.close() ;

	}


	public static ArrayList<String> getOptions(int transObjectDBID,
			int sectionID, int tenantDBID, IConfService confService, Connection dbConn) throws SQLException, ClassNotFoundException {

		String sectionName = getSectionName(sectionID, dbConn);

		ArrayList<String> optionList = new ArrayList<String>();

		CfgTransaction readTrans = null;
		CfgTransactionQuery cfgTransactionQuery = new CfgTransactionQuery(confService);

		cfgTransactionQuery.setDbid(transObjectDBID);
		cfgTransactionQuery.setTenantDbid(tenantDBID);

		try {
			readTrans = cfgTransactionQuery.executeSingleResult();
		} catch (ConfigException e) {
			// TODO Auto-generated catch block
		}
		// Read configuration transaction annex tab:

		KeyValueCollection transOptions = readTrans.getUserProperties();

		// Get Section KVPair

		KeyValuePair sectionKvp = transOptions.getPair(sectionName);

		// Get options from Section KVPair

		for (Object recordObj : sectionKvp.getTKVValue()) {
			KeyValuePair recordKvp = (KeyValuePair) recordObj;
			optionList.add(recordKvp.getStringKey());
		}

		// Return array of option names.
		return optionList;
	}


	public static String getSectionName(int sectionID, Connection dbConn) throws ClassNotFoundException, SQLException {

		String sectionName = null;

		String query = "SELECT * FROM SECTION WHERE ID = " + sectionID;

		Statement sectionStmt = dbConn.createStatement();

		ResultSet queryResult = sectionStmt.executeQuery(query);

		// Loop through the result set
		while( queryResult.next() ) {
			sectionName = queryResult.getString(2);
		}	

		queryResult.close();
		sectionStmt.close();

		return sectionName;
	}


	public static String getOptionName(int optionID, Connection dbConn) throws SQLException, ClassNotFoundException {

		String optionName = null;

		String query = "SELECT * FROM OPTION_NAME WHERE ID = " + optionID;

		Statement optionStmt = dbConn.createStatement();

		ResultSet queryResult = optionStmt.executeQuery(query);


		// Loop through the result set
		while( queryResult.next() ) {
			optionName = queryResult.getString(2);
		}	

		queryResult.close();
		optionStmt.close();

		return optionName;
	}

	public static int getOptionID (String optionName, String sectionName, int listObjectDBID, Connection dbConn) throws SQLException, ClassNotFoundException {

		int optionID = 0;

		String query = "SELECT o.ID " +
				"FROM OPTION_NAME o, SECTION s " +
				"WHERE o.SECTION_ID = S.ID " +
				"AND O.NAME = '" + optionName + "' " +
				"AND S.NAME = '" + sectionName + "' " +
				"AND S.LIST_OBJECT_ID = " + listObjectDBID;


		Statement optionIDStmt = dbConn.createStatement();

		ResultSet queryResult = optionIDStmt.executeQuery(query);


		// Loop through the result set
		while( queryResult.next() ) {
			optionID = queryResult.getInt(1);
		}	

		queryResult.close();
		optionIDStmt.close();

		return optionID;
	}

	public static boolean updateOption(int optionID, int optionTypeID, Connection dbConn) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean optionUpdated = false;

		String query = "UPDATE OPTION_NAME SET TYPE_ID = " + optionTypeID + " WHERE ID = " + optionID;

		Statement optionUpdateStmt = dbConn.createStatement();

		int queryResult;
		try {
			queryResult = optionUpdateStmt.executeUpdate(query);
			optionUpdated = true;
		} catch (SQLException e) {
			optionUpdated = false;
			System.out.println("Insert Type Name failed");
			System.out.println(query);
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}

		optionUpdateStmt.close();

		return optionUpdated;
	}

	public static boolean addListObjectType(String optionTypeName, String optionTypeDescription, String listDelimiter, Connection dbConn) throws SQLException {

		boolean optionTypeAdded = false;

		String insertTypeNameQuery = "INSERT INTO TYPE_NAME (NAME, TYPE, DESCRIPTION) VALUES ('" + optionTypeName + "', 'LIST', '" + optionTypeDescription + "')";
		Statement optionTypeAddStmt = dbConn.createStatement();

		int queryResult;
		try {
			queryResult = optionTypeAddStmt.executeUpdate(insertTypeNameQuery);
			optionTypeAdded = true;
		} catch (SQLException e) {
			optionTypeAdded = false;
			System.out.println("Insert Type Name failed");
			System.out.println(insertTypeNameQuery);
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}

		optionTypeAddStmt.close();

		if (optionTypeAdded) {

			String typeID = getTypeDBID(optionTypeName, dbConn);

			String insertTypeListDelimQuery = "INSERT INTO TYPE_OPTION (NAME, TYPE_ID, OPTION_TYPE) VALUES ('" + listDelimiter + "', " + typeID + ", 'LIST_DELIMITER')";
			Statement optionTypeAddListDelimStmt = dbConn.createStatement();

			int optionTypeAddListDelimResult;
			try {
				optionTypeAddListDelimResult = optionTypeAddListDelimStmt.executeUpdate(insertTypeListDelimQuery);
				optionTypeAdded = true;
			} catch (SQLException e) {
				optionTypeAdded = false;
			}
		}
		return optionTypeAdded;
		// TODO Auto-generated method stub

	}

	public static boolean addKVListObjectType(String optionTypeName,
			String optionTypeDescription, String kvlistDelimiter, String kvDelimiter, Connection dbConn) throws SQLException {

		boolean optionTypeAdded = false;

		String insertTypeNameQuery = "INSERT INTO TYPE_NAME (NAME, TYPE, DESCRIPTION) VALUES ('" + optionTypeName + "', 'KVLIST', '" + optionTypeDescription + "')";
		Statement optionTypeAddStmt = dbConn.createStatement();

		int queryResult;
		try {
			queryResult = optionTypeAddStmt.executeUpdate(insertTypeNameQuery);
			optionTypeAdded = true;
		} catch (SQLException e) {
			optionTypeAdded = false;
			System.out.println("Insert Type Name failed");
			System.out.println(insertTypeNameQuery);
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}

		optionTypeAddStmt.close();

		String typeID = getTypeDBID(optionTypeName, dbConn);

		String insertTypeKVListDelimQuery = "INSERT INTO TYPE_OPTION (NAME, TYPE_ID, OPTION_TYPE) VALUES ('" + kvlistDelimiter + "', " + typeID + ", 'LIST_DELIMITER')";

		Statement optionTypeAddListDelimStmt = dbConn.createStatement();

		int optionTypeAddKVListDelimResult;
		try {
			optionTypeAddKVListDelimResult = optionTypeAddListDelimStmt.executeUpdate(insertTypeKVListDelimQuery);
		} catch (SQLException e) {
			optionTypeAdded = false;
			System.out.println("Insert Type KV List delim failed");
		}

		String insertTypeKVPairDelimQuery = "INSERT INTO TYPE_OPTION (NAME, TYPE_ID, OPTION_TYPE) VALUES ('" + kvDelimiter + "', " + typeID + ", 'KV_DELIMITER')";
		
		Statement optionTypeAddKVPairDelimStmt = dbConn.createStatement();

		int optionTypeAddKVPairDelimResult;
		try {
			optionTypeAddKVPairDelimResult = optionTypeAddKVPairDelimStmt.executeUpdate(insertTypeKVPairDelimQuery);
		} catch (SQLException e) {
			optionTypeAdded = false;
			System.out.println("Insert Type KVPair delim failed");
		}

		return optionTypeAdded;

	}

	public static boolean addSelectObjectType(String optionTypeName,
			String optionTypeDescription, Map<String,String> selectValues, Connection dbConn) throws SQLException {

		boolean optionTypeAdded = false;	
		String query = "INSERT INTO TYPE_NAME (NAME, TYPE, DESCRIPTION) VALUES ('" + optionTypeName + "', 'SELECT', '" + optionTypeDescription + "')";
		Statement optionTypeAddStmt = dbConn.createStatement();

		int queryResult;
		try {
			queryResult = optionTypeAddStmt.executeUpdate(query);
			optionTypeAdded = true;
		} catch (SQLException e) {
			optionTypeAdded = false;
		}
		
		if (optionTypeAdded) {

			String typeID = getTypeDBID(optionTypeName, dbConn);
			String value = "";
			String altValue = "";

			//loop through list of values and alt values
			for (Map.Entry<String, String> entry : selectValues.entrySet()) {

				value = entry.getKey();

				//check that an alt value has been entered and if not set the alt value to the regular value.
				if (entry.getValue().equals("")) {
					altValue = entry.getKey();
				} else {
					altValue = entry.getValue();
				}

				String insertTypeSelectValueQuery = "INSERT INTO TYPE_OPTION (NAME, ALT_NAME, TYPE_ID, OPTION_TYPE) VALUES ('" + entry.getKey() + "', '" + altValue + "', " + typeID + ", 'VALUE')";
				Statement optionTypeAddSelectValueStmt = dbConn.createStatement();

				int optionTypeAddSelectValueResult;
				try {
					optionTypeAddSelectValueResult = optionTypeAddSelectValueStmt.executeUpdate(insertTypeSelectValueQuery);
				} catch (SQLException e) {
					optionTypeAdded = false;
				}
			}

		}

		optionTypeAddStmt.close();

		return optionTypeAdded;

	}

	public static String getTypeDBID(String typeName, Connection dbConn) throws SQLException {
		String selectTypeIDQuery = "SELECT ID FROM TYPE_NAME WHERE NAME = '" + typeName + "'";
		Statement typeIDQueryStmt = dbConn.createStatement();
		String typeID = null;
		ResultSet typeIDQueryResult;
		typeIDQueryResult = typeIDQueryStmt.executeQuery(selectTypeIDQuery);

		while( typeIDQueryResult.next() ) {
			typeID = typeIDQueryResult.getString(1);
		}	

		typeIDQueryResult.close();
		typeIDQueryStmt.close();

		return typeID;
	}

	public static void adminChange(String username, int optionID,
			int oldTypeID, int newTypeID, Connection dbConn) throws SQLException{

		// create a java calendar instance
		Calendar calendar = Calendar.getInstance();

		// get a java.util.Date from the calendar instance.
		// this date will represent the current instant, or "now".
		java.util.Date now = calendar.getTime();

		// a java current time (now) instance
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

		String insertAdminChangeQuery = "INSERT INTO ADMIN_CHANGES(USERNAME, OPTION_ID, CHANGE_DATE, OLD_TYPE_ID, NEW_TYPE_ID) VALUES ('" + username +"', " + optionID + ", TIMESTAMP('" + currentTimestamp + "'), " + oldTypeID + ", " + newTypeID +")";


		Statement insertAdminChangeStmt = dbConn.createStatement();

		try {
			insertAdminChangeStmt.executeUpdate(insertAdminChangeQuery);
		} catch (SQLException e) {
			System.out.println("Insert Admin Change failed");
			System.out.println(insertAdminChangeQuery);
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}
		insertAdminChangeStmt.close();

	}

	public static void listObjectChange(String username, 
			int listObjectDBID, String sectionName, String optionKey, String oldValue, String newValue, Connection dbConn) throws SQLException, ClassNotFoundException{

		// create a java calendar instance
		Calendar calendar = Calendar.getInstance();

		// get a java.util.Date from the calendar instance.
		// this date will represent the current instant, or "now".
		java.util.Date now = calendar.getTime();

		// a java current time (now) instance
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

		int optionID = getOptionID(optionKey, sectionName, listObjectDBID, dbConn);

		String insertListObjectChangeQuery = "INSERT INTO CHANGES(USERNAME, OPTION_ID, CHANGE_DATE, OLD_VALUE, NEW_VALUE) VALUES ('" + username +"', " + optionID + ", TIMESTAMP('" + currentTimestamp + "'), '" + oldValue + "', '" + newValue +"')";


		Statement insertListObjectChangeStmt = dbConn.createStatement();

		try {
			insertListObjectChangeStmt.executeUpdate(insertListObjectChangeQuery);
		} catch (SQLException e) {
			System.out.println("Insert List Object Change failed");
			System.out.println(insertListObjectChangeQuery);
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}
		insertListObjectChangeStmt.close();

	}

	public static int copySection(int thisSectionID, int copySectionID,
			Connection dbConn) throws SQLException {
		int sectionCopiedOptionNum = 0;

		String thisSectionQuery = "SELECT o.NAME, o.ID " +
				"FROM OPTION_NAME o, SECTION s " +
				"WHERE o.SECTION_ID = S.ID " +
				"AND s.ID = " + thisSectionID;

		Statement thisSectionQueryStmt = dbConn.createStatement();
		ResultSet thisSectionQueryResult;
		thisSectionQueryResult = thisSectionQueryStmt.executeQuery(thisSectionQuery);

		while( thisSectionQueryResult.next() ) {
			String optionName = thisSectionQueryResult.getString(1);
			int optionID = Integer.parseInt(thisSectionQueryResult.getString(2));
			String copySectionQuery = "SELECT o.TYPE_ID " +
					"FROM OPTION_NAME o, SECTION s " +
					"WHERE o.SECTION_ID = S.ID " +
					"AND s.ID = " + copySectionID + " " +
					"AND o.NAME = '" + optionName + "'";
			Statement copySectionQueryStmt = dbConn.createStatement();
			ResultSet copySectionQueryResult;
			copySectionQueryResult = copySectionQueryStmt.executeQuery(copySectionQuery);
			while( copySectionQueryResult.next() ) {
				sectionCopiedOptionNum ++;
				int optionTypeID = Integer.parseInt(copySectionQueryResult.getString(1));
				String setOptionTypeQuery = "UPDATE OPTION_NAME SET TYPE_ID = " + optionTypeID + " WHERE ID = " + optionID;
				Statement setOptionTypeQueryStmt = dbConn.createStatement();
				setOptionTypeQueryStmt.executeUpdate(setOptionTypeQuery);
				setOptionTypeQueryStmt.close();
			}
			copySectionQueryResult.close();
			copySectionQueryStmt.close();
		}		

		thisSectionQueryResult.close();
		thisSectionQueryStmt.close();
		
		return sectionCopiedOptionNum;
	}

	public static int cleanUpSection(int tenantDBID, int transObjectDBID, int sectionID,
			IConfService confService, Connection dbConn) throws SQLException, ClassNotFoundException {

		int optionsDeleted = 0;

		ArrayList<String> optionList = getOptions(transObjectDBID, sectionID, tenantDBID, confService, dbConn);

		String optionsQuery = "SELECT ID, NAME FROM OPTION_NAME " +
				"WHERE SECTION_ID = " + sectionID;

		Statement optionsQueryStmt = dbConn.createStatement();
		ResultSet optionsQueryResult;
		optionsQueryResult = optionsQueryStmt.executeQuery(optionsQuery);

		int thisOptionID;
		String thisOptionName;
		String deleteOptionQuery;

		while( optionsQueryResult.next() ) {
			thisOptionID = Integer.parseInt(optionsQueryResult.getString(1));
			thisOptionName = optionsQueryResult.getString(2);

			if (!optionList.contains(thisOptionName)) {
				optionsDeleted++;

				deleteOptionQuery = "DELETE FROM OPTION_NAME " +
						"WHERE ID = " + thisOptionID;
				Statement deleteOptionQueryStmt = dbConn.createStatement();
				deleteOptionQueryStmt.executeUpdate(deleteOptionQuery);
				deleteOptionQueryStmt.close();
			}
		}
		optionsQueryResult.close();
		optionsQueryStmt.close();

		return optionsDeleted;
	}

	public static ArrayList<String> getChanges(
			int offset, String table, Connection dbConn, int tenantDBID) throws SQLException {

		ArrayList<String> changes = new ArrayList<String>();
		String thisChange = "";
		String changesQuery = "";
		if (table.equals("CHANGES")) {
			changesQuery =
					"SELECT C.USERNAME, C.CHANGE_DATE, T.NAME AS TENANT, L.NAME AS LIST_OBJECT, " +
							"S.NAME AS SECTION_NAME, O.NAME AS OPTION_NAME, C.OLD_VALUE, C.NEW_VALUE " +
							"FROM " + table + " C, OPTION_NAME O, SECTION S, LIST_OBJECT L, TENANTS T " +
							"WHERE C.OPTION_ID = O.ID " +
							"AND O.SECTION_ID = S.ID " +
							"AND S.LIST_OBJECT_ID = L.ID " +
							"AND L.TENANT_ID = T.ID  " +
							"AND T.ID = " + tenantDBID + " " +
							"ORDER BY CHANGE_DATE DESC " +
							"OFFSET " + offset + " ROWS " +
							"FETCH FIRST 40 ROWS ONLY";
		} else {
			changesQuery =
					"SELECT C.USERNAME, C.CHANGE_DATE, T.NAME AS TENANT, L.NAME AS LIST_OBJECT, " +
							"S.NAME AS SECTION_NAME, O.NAME AS OPTION_NAME, TN_OLD.NAME AS OLD_NAME, TN_NEW.NAME AS NEW_NAME " +
							"FROM " + table + " C, OPTION_NAME O, TYPE_NAME TN_OLD, TYPE_NAME TN_NEW, " +
							"SECTION S, LIST_OBJECT L, TENANTS T " +
							"WHERE C.OPTION_ID = O.ID " +
							"AND C.OLD_TYPE_ID = TN_OLD.ID " +
							"AND C.NEW_TYPE_ID = TN_NEW.ID " +
							"AND O.SECTION_ID = S.ID " +
							"AND S.LIST_OBJECT_ID = L.ID " +
							"AND L.TENANT_ID = T.ID  " +
							"ORDER BY CHANGE_DATE DESC " +
							"OFFSET " + offset + " ROWS " +
							"FETCH FIRST 40 ROWS ONLY";
		}
		
		Statement changesQueryStmt = dbConn.createStatement();
		ResultSet changesQueryResult;
		changesQueryResult = changesQueryStmt.executeQuery(changesQuery);

		while( changesQueryResult.next() ) {
			thisChange = "";
			thisChange = thisChange + changesQueryResult.getString(1);
			thisChange = thisChange + "," + changesQueryResult.getString(2);
			thisChange = thisChange + "," + changesQueryResult.getString(3);
			thisChange = thisChange + "," + changesQueryResult.getString(4);
			thisChange = thisChange + "," + changesQueryResult.getString(5);
			thisChange = thisChange + "," + changesQueryResult.getString(6);
			thisChange = thisChange + "," + changesQueryResult.getString(7).replace(",","&#44;");
			thisChange = thisChange + "," + changesQueryResult.getString(8).replace(",","&#44;");

			changes.add(thisChange);

		}

		return changes;
	}

	public static int updateSection(int sectionID,
			Map<Integer, Integer> optionTypes, Connection dbConn) throws SQLException {
		
		String query;
		Statement optionUpdateStmt = dbConn.createStatement();
		
		int optionsUpdated = 0;
			
		for (Map.Entry<Integer, Integer> entry : optionTypes.entrySet()) {
			query = "UPDATE OPTION_NAME SET TYPE_ID = " + entry.getValue() + " WHERE ID = " + entry.getKey();
			
			try {
				optionUpdateStmt.executeUpdate(query);
				optionsUpdated++;
			} catch (SQLException e) {
				System.out.println("Insert Type Name failed");
				System.out.println(query);
				System.out.println(e.getErrorCode());
				System.out.println(e.getMessage());
				System.out.println(e.getCause());
			}
		}
		
		optionUpdateStmt.close();
		
		return optionsUpdated;
	}

	public static int updateSectionOrders(int transObjectDBID,
			Map<Integer, Integer> sectionOrders, Connection dbConn) throws SQLException {
		
		String query;
		Statement sectionOrderUpdateStmt = dbConn.createStatement();
		
		int sectionsUpdated = 0;
			
		for (Map.Entry<Integer, Integer> entry : sectionOrders.entrySet()) {
			query = "UPDATE SECTION SET SECTION_ORDER = " + entry.getValue() + " WHERE ID = " + entry.getKey();
			
			try {
				sectionOrderUpdateStmt.executeUpdate(query);
				sectionsUpdated++;
			} catch (SQLException e) {
				System.out.println("Insert Type Name failed");
				System.out.println(query);
				System.out.println(e.getErrorCode());
				System.out.println(e.getMessage());
				System.out.println(e.getCause());
			}
		}
		
		sectionOrderUpdateStmt.close();
		
		return sectionsUpdated;
	}

	public static String writeChangesCSV(String startdate, String enddate,
			Connection dbConn, String path, int tenantDBID) throws IOException, SQLException {
		
		
		//Create CSVWriter object
		CSVWriter writer = new CSVWriter(new FileWriter(path + "WebContent/tenant_changes.tsv"), '\t');
		
		String changesQuery = "SELECT C.USERNAME, C.CHANGE_DATE, T.NAME AS TENANT, L.NAME AS LIST_OBJECT, " +
				"S.NAME AS SECTION_NAME, O.NAME AS OPTION_NAME, C.OLD_VALUE, C.NEW_VALUE " +
				"FROM CHANGES C, OPTION_NAME O, SECTION S, LIST_OBJECT L, TENANTS T " +
				"WHERE C.OPTION_ID = O.ID " +
				"AND O.SECTION_ID = S.ID " +
				"AND S.LIST_OBJECT_ID = L.ID " +
				"AND L.TENANT_ID = T.ID  " +
				"AND T.ID = " + tenantDBID + " " +
				"AND C.CHANGE_DATE BETWEEN TIMESTAMP('" + startdate + " 00:00:00') AND TIMESTAMP('" + enddate + " 23:59:59') " +
				"ORDER BY CHANGE_DATE DESC";
		
		Statement changesQueryStmt = dbConn.createStatement();
		ResultSet changesQueryResult;
		changesQueryResult = changesQueryStmt.executeQuery(changesQuery);
		
		writer.writeAll(changesQueryResult, true);
		
		changesQueryResult.close();
		changesQueryStmt.close();
		writer.close();
		
		return "/GLOT/WebContent/tenant_changes.tsv";
		
	}

}
