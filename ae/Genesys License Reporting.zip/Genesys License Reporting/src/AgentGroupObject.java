

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgAgentGroup;
import com.genesyslab.platform.applicationblocks.com.objects.CfgPerson;
import com.genesyslab.platform.applicationblocks.com.queries.CfgAgentGroupQuery;

public class AgentGroupObject {
	static CfgAgentGroup getAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		CfgAgentGroupQuery agentGroupQuery = new CfgAgentGroupQuery(confService);
		agentGroupQuery.setDbid(agentGroupDbid);
		CfgAgentGroup agentGroup = agentGroupQuery.executeSingleResult();
		return agentGroup;
	}

	
	// Get the number of agents in an agent group.
	public static int getNumMembersInAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		int numAgents = 0;
		
		CfgAgentGroup agentGroup = getAgentGroup(agentGroupDbid, confService);
		
		if (agentGroup.getAgentDBIDs() != null) {
			numAgents = agentGroup.getAgentDBIDs().size();
		} else {
			numAgents = 0;
		}
		
		return numAgents;
	}
	
	// get list of agents in an agent group (first name last name in alphabetical order).
	public static ArrayList<String> getMembersOfAgentGroup(int agentGroupDbid, IConfService confService) throws ConfigException{
		ArrayList<String> agents = new ArrayList<String>();
		
		CfgAgentGroup agentGroup = getAgentGroup(agentGroupDbid, confService);
		
		Collection<CfgPerson> personCollection = agentGroup.getAgents();
		
		
		for (CfgPerson thisPerson : personCollection) {
			agents.add(thisPerson.getFirstName() + " " + thisPerson.getLastName());
		}
		
		Collections.sort(agents);
		
		return agents;
	}
}
