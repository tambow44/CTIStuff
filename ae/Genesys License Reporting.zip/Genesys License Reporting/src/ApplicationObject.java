

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgApplication;
import com.genesyslab.platform.applicationblocks.com.queries.CfgApplicationQuery;
import com.genesyslab.platform.commons.collections.KeyValueCollection;


public class ApplicationObject {

	public static KeyValueCollection getAppOptions(String appName, IConfService confService) throws ConfigException {

		CfgApplication readApp = null;
		CfgApplicationQuery CfgApplicationQuery = new CfgApplicationQuery(confService);
		
		System.out.println("AppName: " + appName);

		CfgApplicationQuery.setName(appName);

		readApp = CfgApplicationQuery.executeSingleResult();
		
		// Read configuration transaction annex tab:
		
		System.out.println("AppDBID: " + readApp.getDBID());

		KeyValueCollection appOptions = readApp.getOptions();
		
		return appOptions;
	}

	
}
