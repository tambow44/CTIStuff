import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;


public class CfgSvcInitialization {

    /**
     * Sample Configuration service initialization function example.
     *
     * @param cfgsrvEndpointName name for the server connection endpoint
     * @param cfgsrvHost configuration server host name
     * @param cfgsrvPort configuration server port
     * @param username configuration server login username
     * @param password configuration server login password
     * @return initialized configuration service
     * @throws ConfigException in case of exception while service or configuration protocol initialization
     * @throws InterruptedException if process was interrupted
     * @throws ProtocolException exception on protocol connection openning
     */
    public static IConfService initializeConfigService(
                final String cfgsrvEndpointName,
                final String cfgsrvHost,
                final int    cfgsrvPort,
                final String username,
                final String password)
            throws ConfigException, InterruptedException, ProtocolException {

        CfgAppType  clientType         = CfgAppType.CFGSCE;
        String      clientName         = "default";

        System.out.println("ConfService connection being attempted...");
        System.out.println(cfgsrvEndpointName);
        System.out.println(cfgsrvHost);
        System.out.println(cfgsrvPort);
        
        ConfServerProtocol protocol = new ConfServerProtocol(new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort));
        protocol.setClientName(clientName);
        protocol.setClientApplicationType(clientType.ordinal());
        protocol.setUserName(username);
        protocol.setUserPassword(password); 
        
        return ConfServiceFactory.createConfService(protocol);
    }
}
