

import java.sql.*;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTenant;

import com.genesyslab.platform.applicationblocks.com.queries.CfgTenantQuery;

public class TenantInfo {
	
	public static int getTenantDBID(String tenantName, IConfService confService) throws ConfigException{
		
		CfgTenant readTenant = null;
		CfgTenantQuery tenantQuery = new CfgTenantQuery(confService);
		tenantQuery.setName(tenantName);
		
		readTenant = tenantQuery.executeSingleResult();
		return readTenant.getDBID();
		
	}
	
	public static String getTenantName(int tenantDBID, IConfService confService) throws ConfigException{
		CfgTenant readTenant = null;
		CfgTenantQuery tenantQuery = new CfgTenantQuery(confService);
		tenantQuery.setDbid(tenantDBID);
		
		readTenant = tenantQuery.executeSingleResult();
		return readTenant.getName();
	}
	
	public static Map<Integer, String> getTenants(IConfService confService) throws ConfigException, InterruptedException{
		
		CfgTenantQuery tenantQuery = new CfgTenantQuery(confService);
		
		Collection<CfgTenant> tenants = tenantQuery.execute();
		
		Map<Integer, String> tenantList = new HashMap<Integer, String>();
		
		for (CfgTenant tenant : tenants) {
			tenantList.put(tenant.getDBID(), tenant.getName());
		}
		
		return tenantList;
	}
	
	
	public static int getTenantTestAgentGroupDbid(int tenantDBID, Connection dbConn) throws SQLException{
		int testAgGrpDbid = 0;
		
		String query = "SELECT TEST_AG_GRP_DBID " +
				"FROM TENANTS " +
				"WHERE ID = " + tenantDBID;
		Statement stmt = dbConn.createStatement();
		
		ResultSet queryResult;
		queryResult = stmt.executeQuery(query);
		while( queryResult.next() ) {
			testAgGrpDbid = queryResult.getInt(1);
		}
		return testAgGrpDbid;
		
	}

}
