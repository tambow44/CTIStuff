import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.TimeZone;

import org.joda.time.*;

import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgAgentGroup;
import com.genesyslab.platform.applicationblocks.com.queries.CfgAgentGroupQuery;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.commons.collections.KeyValueCollection;

public class getdata {
	// JDBC driver name and database URL

	static String DB_URL_BASE = "jdbc:oracle:thin:@";
	

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		DateTime processDate = null;
		String dbURL;
		
		// Get command line options and sanity check
						
		if (args.length < 4 || args.length > 5) {
			System.out.println("Run this with the command line 'java -jar lrm.jar host port username password date'");
			System.out.println("Where:");
			System.out.println("host is the Config Server host");
			System.out.println("port is the config server port");
			System.out.println("username is the config server username");
			System.out.println("password is the config server password");
			System.out.println("date is optional and is the date to process in the format yyyy-mm-dd");
		}
		
		String confHost = "";
		int confPort = 0;
		String confUserName = "";
		String confPassword = "";
		String rand = null;
		String cfgsrvEndpointName = "";
		
		if (args.length == 5) {
			int inputYear = Integer.parseInt(args[4].substring(0, 4));
			int inputMonth = Integer.parseInt(args[4].substring(5, 7));
			int inputDay = Integer.parseInt(args[4].substring(8, 10));
			
			System.out.println(inputYear + "-" + inputMonth + "-" + inputDay);

			try {
				processDate = new DateTime(inputYear,inputMonth,inputDay,0,0,0,DateTimeZone.forID("NZ"));
			} catch (Exception e) {
				System.out.println("Either run this with no date argument or with the date you want to process in the format yyyy-mm-dd");
				System.exit(1);
			}
		} else {
			DateTime today = new DateTime(DateTimeZone.forID("NZ")).withTimeAtStartOfDay();
			processDate = today.plusDays(-1).withTimeAtStartOfDay();
		}
		System.out.println("Process Date: " + processDate);
		rand = Long.toHexString(Double.doubleToLongBits(Math.random()));
		cfgsrvEndpointName = "ConfAcc#" + rand;
		confHost = args[0];
		confPort = Integer.parseInt(args[1]);
		confUserName = args[2];
		confPassword = args[3];
		
		// Set up config server connection

		IConfService confService = null;
		CfgAppType  clientType         = CfgAppType.CFGSCE;
        String      clientName         = "default";
        ConfServerProtocol protocol = new ConfServerProtocol(new Endpoint(cfgsrvEndpointName, confHost, confPort));
        protocol.setClientName(clientName);
        protocol.setClientApplicationType(clientType.ordinal());
        protocol.setUserName(confUserName);
        protocol.setUserPassword(confPassword); 
        
        try{
        	confService = ConfServiceFactory.createConfService(protocol);
		} catch(Exception e){
			System.out.println("Config server details were incorrect");
			System.out.println("Run this with the command line 'java -jar lrm.jar host port username password yyyy-mm-dd'");
			System.out.println("Where:");
			System.out.println("host is the Config Server host");
			System.out.println("port is the config server port");
			System.out.println("username is the config server username");
			System.out.println("password is the config server password");
			System.out.println("date is optional and is the date to process in the format yyyy-mm-dd");
			e.printStackTrace();
			System.exit(1);
		}
        try {
			protocol.open();
		} catch (ProtocolException | IllegalStateException | InterruptedException e2) {
			
			e2.printStackTrace();
		}
        
		// Get lrm application options
		
		KeyValueCollection appOptions = null;
		String appName = "VFLRM";
		
		try {
			appOptions = ApplicationObject.getAppOptions(appName, confService);
		} catch (ConfigException e1) {
			e1.printStackTrace();
			System.exit(1);
		}
		
		// Loop through options setting relevant variables.
		
		KeyValueCollection iconInstances = new KeyValueCollection();
		KeyValueCollection tenantLicenses = new KeyValueCollection();
		KeyValueCollection tenants = new KeyValueCollection();
		
		String lrmDBHost = "";
		String lrmDBPort = "";
		String lrmDBName = "";
		String lrmDBUserName = "";
		String lrmDBPassword = "";
		
		for (Object sectionObj : appOptions) {
			KeyValuePair sectionKvp = (KeyValuePair) sectionObj;
			
			if (sectionKvp.getStringKey().startsWith("icon_")) {
				iconInstances.addObject(sectionKvp.getStringKey(), sectionKvp.getTKVValue());
			} else if (sectionKvp.getStringKey().startsWith("license_")) {
				tenantLicenses.addObject(sectionKvp.getStringKey(), sectionKvp.getTKVValue());
			} else if (sectionKvp.getStringKey().equals("lrm")) {
				for (Object recordObj : sectionKvp.getTKVValue()) {
					KeyValuePair recordKvp = (KeyValuePair) recordObj;
					switch (recordKvp.getStringKey()) {
						case "host" : lrmDBHost = recordKvp.getStringValue(); break;
						case "port" : lrmDBPort = recordKvp.getStringValue(); break;
						case "dbname" : lrmDBName = recordKvp.getStringValue(); break;
						case "username" : lrmDBUserName = recordKvp.getStringValue(); break;
						case "password" : lrmDBPassword = recordKvp.getStringValue(); break;
						default : System.out.println(recordKvp.getStringKey() + ":" + recordKvp.getStringValue()); break;
					}
				}
			} else if (sectionKvp.getStringKey().equals("tenants")) {
				for (Object recordObj : sectionKvp.getTKVValue()) {
					KeyValuePair recordKvp = (KeyValuePair) recordObj;
					tenants.addPair(recordKvp);
				}
			}
		}
		
		/* Get list of license agent groups for each tenant
		 * Note that if an agent is in multiple agent groups
		 * then the last agent group from the agent group query 
		 * will be the one they count towards. What one that is
		 * is not something that we can tell customers before hand
		 * so they need to be aware of this and make sure agents
		 * are only in a single license agent group.
		 */
		CfgAgentGroupQuery agentGroupQuery = new CfgAgentGroupQuery(confService);
		agentGroupQuery.setName("lag_*");
		Collection<CfgAgentGroup> tenantAgentGroups = null;
		HashMap<Integer, String> agentIDGroupName = new HashMap<Integer, String>();
		HashMap<String, Integer> groupNameGroupID = new HashMap<String, Integer>();
		String agentGroupName;
		Integer groupID;
		Collection<Integer> agentDBIDs = null;
		ArrayList<String> groupNames = new ArrayList<String>();
		HashMap<Integer, ArrayList<String>> tenantIDGroups = new HashMap<Integer, ArrayList<String>>();
		int tenantDBID;
		
		for (Object tenantObj : tenants) {
			KeyValuePair tenantKvp = (KeyValuePair) tenantObj;
			tenantDBID = Integer.parseInt(tenantKvp.getStringValue());
			agentGroupQuery.setTenantDbid(tenantDBID);		
			try {
				tenantAgentGroups = agentGroupQuery.execute();
			} catch (ConfigException | InterruptedException e1) {
				e1.printStackTrace();
			}
			if (tenantAgentGroups != null) {
				for (CfgAgentGroup thisAgentGroup : tenantAgentGroups) {
					agentGroupName = thisAgentGroup.getGroupInfo().getName();
					groupID = thisAgentGroup.getGroupInfo().getDBID();
					groupNames.add(agentGroupName);
					groupNameGroupID.put(agentGroupName, groupID);
					agentDBIDs = thisAgentGroup.getAgentDBIDs();
					for (Integer thisAgentDBID : agentDBIDs) {
						agentIDGroupName.put(thisAgentDBID, agentGroupName);
					}
				}
				tenantIDGroups.put(tenantDBID, (ArrayList<String>) groupNames.clone());
				groupNames.clear();
			}
			
		}
		
		
		
		

		long startTime = processDate.getMillis()/1000;
		long endTime = startTime + 86400;
		System.out.println("startTime: " + startTime);
		System.out.println("endTime: " + endTime);

		Connection iconConn = null;
		Connection lrmConn = null;
		String lrmDBURL = DB_URL_BASE + lrmDBHost + ":" + lrmDBPort + ":" + lrmDBName;
		
		try{
			//Register JDBC driver
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

			//Open a connection
			lrmConn = DriverManager.getConnection(lrmDBURL, lrmDBUserName, lrmDBPassword); 

			//First get data from ICon DB data and put it into LRM db

			Statement iconSelectStmt = null;
			Statement LRMInsertStmt = null;
			ResultSet iconSelectResult = null;
			String sLRMInsertSQL;
			String iconURL;
			String iconDBUsername = null;
			String iconDBPassword = null;
			String iconDBPort = null;
			String iconDBHost = null;
			String iconDBName = null;
			String iconGroupName = "";
			int iconTenantDBID = 0;
			int iconAgentID;
			int iconGroupID = 0;
			int iconCreatedTS;
			int iconTeminatedTS;
			int iconServiceTypeID;
			int iconSwitchID;
			String iconServiceSubType;

			/* 
			 * Loop through KVP Collection of icon instances
			 * queries the icon databases and put the results into the LRM database
			 */
			
			for (Object iconObj : iconInstances) {
				KeyValuePair sectionKvp = (KeyValuePair) iconObj;
				for (Object recordObj : sectionKvp.getTKVValue()) {
					KeyValuePair recordKvp = (KeyValuePair) recordObj;
					
					switch (recordKvp.getStringKey()) {
						case "host" : iconDBHost = recordKvp.getStringValue(); break;
						case "port" : iconDBPort = recordKvp.getStringValue(); break;
						case "dbname" : iconDBName = recordKvp.getStringValue(); break;
						case "username" : iconDBUsername = recordKvp.getStringValue(); break;
						case "password" : iconDBPassword = recordKvp.getStringValue(); break;
						case "tenant" : iconTenantDBID = Integer.parseInt(recordKvp.getStringValue()); break;
						default : System.out.println(recordKvp.getStringKey() + ":" + recordKvp.getStringValue()); break;
						
					}
				}
								
				iconURL = iconDBHost + ":" + iconDBPort + ":" + iconDBName;
				dbURL = DB_URL_BASE + iconURL;
				
				iconConn = DriverManager.getConnection(dbURL, iconDBUsername, iconDBPassword); 

				String sIconSelect = "SELECT DISTINCT LS.AGENTID, LS.CREATED_TS, LS.TERMINATED_TS, SE.GSYS_EXT_INT1, SE.GSYS_EXT_VCH1, LS.SWITCHID " +
						"FROM G_LOGIN_SESSION LS INNER JOIN GX_SESSION_ENDPOINT SE ON SE.LOGINSESSIONID = LS.LOGINSESSIONID " +
						"WHERE (LS.CREATED_TS BETWEEN " + startTime + " AND " + endTime +
						" OR LS.TERMINATED_TS BETWEEN " + startTime + " AND " + endTime + 
						" OR (LS.TERMINATED_TS IS NULL AND LS.CREATED_TS < " + endTime + ")) " +
						"AND LS.AGENTID IS NOT NULL";
				
				//System.out.println("sIconSelect: " + sIconSelect);
				
				iconSelectStmt = iconConn.createStatement();
				iconSelectResult = iconSelectStmt.executeQuery(sIconSelect);
				
				while (iconSelectResult.next()) {
					iconAgentID = iconSelectResult.getInt(1);
					iconGroupName = agentIDGroupName.get(iconAgentID);
					iconCreatedTS = iconSelectResult.getInt(2);
					iconTeminatedTS = iconSelectResult.getInt(3);
					iconServiceTypeID = iconSelectResult.getInt(4);
					iconServiceSubType = iconSelectResult.getString(5);
					iconSwitchID = iconSelectResult.getInt(6);
					
					// different inserts for agent being in a license agent group or not.
					if(iconGroupName != null){
						iconGroupID = groupNameGroupID.get(iconGroupName);
						sLRMInsertSQL = "INSERT INTO LRM.LOGIN_SESSION " +
								"VALUES (" + iconAgentID + "," + iconCreatedTS + "," + iconTeminatedTS + "," + iconTenantDBID + "," + iconServiceTypeID + "," + iconSwitchID + "," + iconServiceSubType + ", '" + iconGroupName +"', " + iconGroupID + ")";
					} else {
						iconGroupID = 0;
						sLRMInsertSQL = "INSERT INTO LRM.LOGIN_SESSION " +
								"VALUES (" + iconAgentID + "," + iconCreatedTS + "," + iconTeminatedTS + "," + iconTenantDBID + "," + iconServiceTypeID + "," + iconSwitchID + "," + iconServiceSubType + ", " + iconGroupName +", " + iconGroupID + ")";
					}
					LRMInsertStmt = lrmConn.createStatement();
					LRMInsertStmt.executeQuery(sLRMInsertSQL);
					LRMInsertStmt.close();

				}
				iconSelectResult.close();
				iconSelectStmt.close();

			}
			
			/*
			 *  now we have the day's login sessions in the LRM database 
			 *  we will aggregate this to 15min, hour and day tables
			 */

			Date date;
			String dateTime;
			String maxSessionTimeSubHour = null;
			String maxSessionTimeHour = null;
			String maxSessionTimeDay = null;
			String quarterHour = null;
			String dayTime = null;
			SimpleDateFormat dateSDF;
			SimpleDateFormat minuteSDF;
			dateSDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			minuteSDF = new SimpleDateFormat("mm");
			dateSDF.setTimeZone(TimeZone.getTimeZone("NZ"));

			String hourTime = "";
			int minute;
			int sessions = 0;
			int checkTime;
			int maxSessionsSubHour = 0;
			int maxSessionsHour = 0;
			int maxSessionsDay = 0;
			String sql;
			String insertSQL;
			Statement selectSessionCountStmt = null;
			Statement insertSessionCountStmt = null;
			ResultSet countSessions;
			ResultSet insertResult;
			String tenantName;
			int [] aServiceTypes = {1,2,3,1000};
			int [] aProvisionedLicenses = new int[4];
			int iServiceType = 0;
			int openmediaLicenses = 0;
			int voiceLicenses = 0;
			int emailLicenses = 0;
			int chatLicenses = 0;
			int iProvisionedLicenses = 0;
			KeyValueCollection thisTenantsLicenses;
			

			/*
			 * Loop through tenants taking name and id from tenants KVP Collection
			 */
			for (Object tenantObj : tenants) {
				KeyValuePair tenantKvp = (KeyValuePair) tenantObj;
				
				tenantDBID = Integer.parseInt(tenantKvp.getStringValue());
				tenantName = tenantKvp.getStringKey();			
				System.out.println("tenantDBID: " + tenantDBID);
				thisTenantsLicenses = tenantLicenses.getList("license_" + tenantName);
				voiceLicenses = Integer.parseInt(thisTenantsLicenses.getString("voice"));
				emailLicenses = Integer.parseInt(thisTenantsLicenses.getString("email"));
				chatLicenses = Integer.parseInt(thisTenantsLicenses.getString("chat"));
				openmediaLicenses = Integer.parseInt(thisTenantsLicenses.getString("openmedia"));
				
				aProvisionedLicenses[0] = voiceLicenses;
				aProvisionedLicenses[1] = emailLicenses;
				aProvisionedLicenses[2] = chatLicenses;
				aProvisionedLicenses[3] = openmediaLicenses;
				
				/*loop through service types
				 *  1 = voice
				 *  2 = email
				 *  3 = chat
				 *  4 = open media
				 */
				
				for(int iServiceTypePosition =0; iServiceTypePosition < aServiceTypes.length; iServiceTypePosition++) {
					iProvisionedLicenses = aProvisionedLicenses[iServiceTypePosition];
					// check licenses for service type are present and only run if they are
					if (iProvisionedLicenses > 0) {
						// first calculate license use for all agents.						
						checkTime = (int) startTime;
						iServiceType = aServiceTypes[iServiceTypePosition];
						
						maxSessionsSubHour = 0;
						maxSessionsHour = 0;
						maxSessionsDay = 0;
						maxSessionTimeDay = dateSDF.format(new Date(checkTime*1000L));
						dayTime = maxSessionTimeDay;
						
						
						
						while (checkTime < endTime) {
							date = new Date(checkTime*1000L); // *1000 is to convert seconds to milliseconds
							minute = Integer.parseInt(minuteSDF.format(date));
							dateTime = dateSDF.format(date);
							
							/* Get a set of the entries
						      Set set = agentIDGroupName.entrySet();
						      // Get an iterator
						      Iterator i = set.iterator();
						      // Display elements
						      while(i.hasNext()) {
						         Map.Entry me = (Map.Entry)i.next();
						         System.out.print(me.getKey() + ": ");
						         System.out.println(me.getValue());
						      } */
							
							sql = "SELECT COUNT(*) "
									+ "FROM LRM.LOGIN_SESSION "
									+ "WHERE CREATED_TS < "
									+ (checkTime + 60)
									+ " AND (TERMINATED_TS > "
									+ checkTime + " OR TERMINATED_TS IS NULL OR TERMINATED_TS = 0) " +
									" AND TENANTID = " + tenantDBID +
									" AND SERVICETYPE = " + iServiceType;
							
							selectSessionCountStmt = lrmConn.createStatement();
							countSessions = selectSessionCountStmt.executeQuery(sql);
							countSessions.next();
							sessions = countSessions.getInt(1);
							
							if (minute == 0 || minute == 15 || minute == 30 || minute == 45) {
								quarterHour = dateTime;
								maxSessionTimeSubHour = dateTime;
							}

							if (minute == 0) {
								hourTime = dateTime;
								maxSessionTimeHour = dateTime;
							}

							if (sessions > maxSessionsSubHour) {
								maxSessionsSubHour = sessions;
								maxSessionTimeSubHour = dateTime;
							}

							if (sessions > maxSessionsHour) {
								maxSessionsHour = sessions;
								maxSessionTimeHour = dateTime;
							}
							
							if (sessions > maxSessionsDay) {
								maxSessionsDay = sessions;
								maxSessionTimeDay = dateTime;
							}

							if (minute == 14 || minute == 29 || minute == 44 || minute == 59) {
								insertSQL = "INSERT INTO LRM.LICENSE_USE_SUB_HOUR " 
										+ "VALUES (to_date('" + quarterHour + "','YYYY-MM-DD HH24:MI:SS'), " + iServiceType +", " + maxSessionsSubHour + ", to_date('" + maxSessionTimeSubHour + "','YYYY-MM-DD HH24:MI:SS'), '" + tenantName + "', " + iProvisionedLicenses + ")";
								insertSessionCountStmt = lrmConn.createStatement();
								insertResult = insertSessionCountStmt.executeQuery(insertSQL);
								insertResult.close();
								insertSessionCountStmt.close();
								maxSessionsSubHour = 0;
							}

							if (minute == 59) {
								insertSQL = "INSERT INTO LRM.LICENSE_USE_HOUR " 
										+ "VALUES (to_date('" + hourTime + "','YYYY-MM-DD HH24:MI:SS'), " + iServiceType +", " + maxSessionsHour + ", to_date('" + maxSessionTimeHour + "','YYYY-MM-DD HH24:MI:SS'), '" + tenantName + "', " + iProvisionedLicenses + ")";
								insertSessionCountStmt = lrmConn.createStatement();
								insertResult = insertSessionCountStmt.executeQuery(insertSQL);
								insertResult.close();
								insertSessionCountStmt.close();
								maxSessionsHour = 0;
							}

							countSessions.close();
							selectSessionCountStmt.close();		    	  

							checkTime = checkTime + 60;	    	  

						}
						insertSQL = "INSERT INTO LRM.LICENSE_USE_DAY " 
								+ "VALUES (to_date('" + dayTime + "','YYYY-MM-DD HH24:MI:SS'), " + iServiceType +", " + maxSessionsDay + ", to_date('" + maxSessionTimeDay + "','YYYY-MM-DD HH24:MI:SS'), '" + tenantName + "', " + iProvisionedLicenses + ")";
						insertSessionCountStmt = lrmConn.createStatement();
						insertResult = insertSessionCountStmt.executeQuery(insertSQL);
						insertResult.close();
						insertSessionCountStmt.close();
						
						// now do the same for license groups for this tenant
						
						int thisGroupID;
						//get the Vector of group names for this tenant then loop through them if there are any
						groupNames = tenantIDGroups.get(tenantDBID);
						if (groupNames != null) {
							for (String thisGroupName : groupNames){
								checkTime = (int) startTime;
								thisGroupID = groupNameGroupID.get(thisGroupName);
								maxSessionsSubHour = 0;
								maxSessionsHour = 0;
								maxSessionsDay = 0;
								maxSessionTimeDay = dateSDF.format(new Date(checkTime*1000L));
								dayTime = maxSessionTimeDay;
															
								while (checkTime < endTime) {
									date = new Date(checkTime*1000L); // *1000 is to convert seconds to milliseconds
									minute = Integer.parseInt(minuteSDF.format(date));
									dateTime = dateSDF.format(date);
									
									sql = "SELECT COUNT(*) "
											+ "FROM LRM.LOGIN_SESSION "
											+ "WHERE CREATED_TS < "
											+ (checkTime + 60)
											+ " AND (TERMINATED_TS > "
											+ checkTime + " OR TERMINATED_TS IS NULL OR TERMINATED_TS = 0) " +
											" AND TENANTID = " + tenantDBID +
											" AND SERVICETYPE = " + iServiceType +
											" AND AGENTGROUPID = " + thisGroupID ;
									selectSessionCountStmt = lrmConn.createStatement();
									countSessions = selectSessionCountStmt.executeQuery(sql);
									countSessions.next();
									sessions = countSessions.getInt(1);
									
									if (minute == 0 || minute == 15 || minute == 30 || minute == 45) {
										quarterHour = dateTime;
										maxSessionTimeSubHour = dateTime;
									}

									if (minute == 0) {
										hourTime = dateTime;
										maxSessionTimeHour = dateTime;
									}

									if (sessions > maxSessionsSubHour) {
										maxSessionsSubHour = sessions;
										maxSessionTimeSubHour = dateTime;
									}

									if (sessions > maxSessionsHour) {
										maxSessionsHour = sessions;
										maxSessionTimeHour = dateTime;
									}
									
									if (sessions > maxSessionsDay) {
										maxSessionsDay = sessions;
										maxSessionTimeDay = dateTime;
									}

									if (minute == 14 || minute == 29 || minute == 44 || minute == 59) {
										insertSQL = "INSERT INTO LRM.AG_LICENSE_USE_SUB_HOUR " 
												+ "VALUES (to_date('" + quarterHour + "','YYYY-MM-DD HH24:MI:SS'), " + 
												iServiceType +", " + 
												maxSessionsSubHour + ", to_date('" + maxSessionTimeSubHour + "','YYYY-MM-DD HH24:MI:SS'), '" + 
												tenantName + "', '" + 
												thisGroupName + "', " + 
												thisGroupID + ")";
										insertSessionCountStmt = lrmConn.createStatement();
										insertResult = insertSessionCountStmt.executeQuery(insertSQL);
										insertResult.close();
										insertSessionCountStmt.close();
										maxSessionsSubHour = 0;
									}

									if (minute == 59) {
										insertSQL = "INSERT INTO LRM.AG_LICENSE_USE_HOUR " 
												+ "VALUES (to_date('" + hourTime + "','YYYY-MM-DD HH24:MI:SS'), " + 
												iServiceType +", " + 
												maxSessionsHour + ", to_date('" + maxSessionTimeHour + "','YYYY-MM-DD HH24:MI:SS'), '" + 
												tenantName + "', '" + 
												thisGroupName + "', " + 
												thisGroupID + ")";
										insertSessionCountStmt = lrmConn.createStatement();
										//System.out.println(insertSQL);
										insertResult = insertSessionCountStmt.executeQuery(insertSQL);
										insertResult.close();
										insertSessionCountStmt.close();
										maxSessionsHour = 0;
									}

									countSessions.close();
									selectSessionCountStmt.close();		    	  

									checkTime = checkTime + 60;	    	  

								}
								insertSQL = "INSERT INTO LRM.AG_LICENSE_USE_DAY " 
										+ "VALUES (to_date('" + dayTime + "','YYYY-MM-DD HH24:MI:SS'), " + 
										iServiceType +", " + 
										maxSessionsDay + ", to_date('" + maxSessionTimeDay + "','YYYY-MM-DD HH24:MI:SS'), '" + 
										tenantName + "', '" + 
										thisGroupName + "', " + 
										thisGroupID + ")";
								insertSessionCountStmt = lrmConn.createStatement();
								insertResult = insertSessionCountStmt.executeQuery(insertSQL);
								insertResult.close();
								insertSessionCountStmt.close();
							}
						}
					}	
				}		
			}
			
			String sTruncateLoginSession;
			Statement LRMTruncateStmt = null;
			
			sTruncateLoginSession = "TRUNCATE TABLE LRM.LOGIN_SESSION REUSE STORAGE";

			LRMTruncateStmt = lrmConn.createStatement();
			LRMTruncateStmt.executeQuery(sTruncateLoginSession);
			LRMTruncateStmt.close();

		}catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}finally{
			try{
				if(lrmConn!=null)
					lrmConn.close();
				if(iconConn!=null)
					lrmConn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}//end finally try
		}//end try
		try {
			protocol.close();
			ConfServiceFactory.releaseConfService(confService);
			confService = null;
		} catch (ProtocolException | IllegalStateException | InterruptedException e) {
			e.printStackTrace();
		}
	}//end main

}
