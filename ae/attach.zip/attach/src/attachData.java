import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EventObject;
import java.util.Iterator;

import com.genesyslab.platform.applicationblocks.commons.Action;
import com.genesyslab.platform.applicationblocks.commons.broker.EventReceivingBrokerService;
import com.genesyslab.platform.applicationblocks.commons.broker.MessageFilter;
import com.genesyslab.platform.applicationblocks.commons.protocols.ProtocolManagementServiceImpl;
import com.genesyslab.platform.applicationblocks.commons.protocols.TServerConfiguration;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.ChannelClosedEvent;
import com.genesyslab.platform.commons.protocol.ChannelErrorEvent;
import com.genesyslab.platform.commons.protocol.ChannelListener;
import com.genesyslab.platform.commons.protocol.ChannelState;
import com.genesyslab.platform.commons.protocol.Message;
import com.genesyslab.platform.commons.protocol.Protocol;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.threading.SingleThreadInvoker;
import com.genesyslab.platform.voice.protocol.ConnectionId;
import com.genesyslab.platform.voice.protocol.tserver.AddressType;
import com.genesyslab.platform.voice.protocol.tserver.AgentWorkMode;
import com.genesyslab.platform.voice.protocol.tserver.CommonProperties;
import com.genesyslab.platform.voice.protocol.tserver.ControlMode;
import com.genesyslab.platform.voice.protocol.tserver.RegisterMode;
import com.genesyslab.platform.voice.protocol.tserver.TimeStamp;
import com.genesyslab.platform.voice.protocol.tserver.events.EventACK;
import com.genesyslab.platform.voice.protocol.tserver.events.EventAttachedDataChanged;
import com.genesyslab.platform.voice.protocol.tserver.events.EventDialing;
import com.genesyslab.platform.voice.protocol.tserver.events.EventPrimaryChanged;
import com.genesyslab.platform.voice.protocol.tserver.events.EventRegistered;
import com.genesyslab.platform.voice.protocol.tserver.events.EventRinging;
import com.genesyslab.platform.voice.protocol.tserver.events.EventRouteUsed;
import com.genesyslab.platform.voice.protocol.tserver.events.EventServerInfo;
import com.genesyslab.platform.voice.protocol.tserver.events.EventUserEvent;
import com.genesyslab.platform.voice.protocol.tserver.requests.agent.RequestAgentReady;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.RequestRegisterAddress;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.RequestUnregisterAddress;
import com.genesyslab.platform.voice.protocol.tserver.requests.queries.RequestQueryServer;
import com.genesyslab.platform.voice.protocol.tserver.requests.special.RequestDistributeUserEvent;
import com.genesyslab.platform.voice.protocol.tserver.requests.userdata.RequestUpdateUserData;


public class attachData implements ChannelListener {

    private static String TS_ID="scab";
    private static String CR, SLASH, LOGPATH;
    private static KeyValueCollection GKVP = null;
    private static boolean bDone = false, bACW = false;
    private long lNow=0;
    private ProtocolManagementServiceImpl protocolManagementService;
    private EventReceivingBrokerService eventReceivingBrokerService;


	class TServerEventsHandler implements Action<Message>{
    	public void handle(final Message message) {
    		
    		//bEvent = true;
    		
    		switch(message.messageId()){
    		/*
	        case EventRinging.ID: {
	            	// Retrieve connection id for this call from the event. This connection id is
	            	// used for all requests pertaining to this call.
	                //EventRinging eventRinging = (EventRinging)message ;
	                //writeKVPs(eventRinging.getThisDN(), eventRinging.getConnID(), eventRinging.getUserData());
	        }
	        break;
	
	        case EventDialing.ID: {
	            	// Retrieve connection id for this call from the event. This connection id is
	            	// used for all requests pertaining to this call.
	            	//EventDialing eventDialing = (EventDialing)message;
	                //writeKVPs(eventDialing.getThisDN(), eventDialing.getConnID(), eventDialing.getUserData());
	        }
	        break;
	            
	        case EventAttachedDataChanged.ID: {
        		//EventAttachedDataChanged eventData = (EventAttachedDataChanged)message;
                //writeKVPs(eventData.getThisDN(), eventData.getConnID(), eventData.getUserData());
        	}
        	break;
	        case EventRouteUsed.ID: {
	        	log("eventRouteUsed");
        		//EventRouteUsed eventUsed = (EventRouteUsed)message;
        		
                //writeKVPs(eventUsed.getThisDN(), eventUsed.getConnID(), eventUsed.getUserData());
        	}
        	break;
        	
        	*/
	        case EventAttachedDataChanged.ID: {
	        	
        		EventAttachedDataChanged eventData = (EventAttachedDataChanged)message;
                //printKVPs(eventData.getThisDN(), eventData.getConnID(), eventData.getUserData(), eventData.getEventSequenceNumber());
                if (GKVP!=null) {
                	KeyValueCollection kvp = GKVP;
                	GKVP=null;
                	log("******** attachDataToCall( "+eventData.getThisDN()+","+ eventData.getConnID()+","+ kvp+" )");
                	try {
						attachDataToCall( eventData.getThisDN(), eventData.getConnID(), kvp );
					} catch (Exception e) {
						e.printStackTrace();
					}
                	
                }
	        	break;
        	}

	        case EventPrimaryChanged.ID: {
	        	log("eventPrimaryChanged:" + message);
    			//EventPrimaryChanged eventPrimaryChanged = (EventPrimaryChanged)message;
	        	break;
    		}
	        
	        case EventACK.ID: {
	        	log("eventACK:" + message);
	        	//bDone=true;
	        	break;
	        }
	        
	        case EventRegistered.ID: {
	        	EventRegistered eventInfo = (EventRegistered)message;
	        	if (eventInfo.getAgentWorkMode()==AgentWorkMode.AfterCallWork) bACW = true;;
	        }
    		
	        case EventUserEvent.ID: {
	        	log("eventUserEvent:" + message);
        		bDone=true;
        		//EventUserEvent eventUserEvent = (EventUserEvent)message;
                //printKVPs(eventUserEvent.getThisDN(), eventUserEvent.getConnID(), eventUserEvent.getUserData(),eventUserEvent.getEventSequenceNumber());
	        	break;
	        }
	        
	        case EventServerInfo.ID: {
	        	EventServerInfo eventInfo = (EventServerInfo)message;
	        	log("Server Info Heart-beat: "+
	        			eventInfo.getApplicationName()+" "+
	        			eventInfo.getServerVersion()+" "+ 
	        			eventInfo.getServerStartTime()+" "+
	        			eventInfo.getTime() );
		        break;
	        }
	        default: {
        		log("" + message);
        	}
	        	
    		}	
    	}
    }
	
	private static void printKVPs( String sDN, ConnectionId connID, KeyValueCollection userData, Long lSeq ) {
        if (userData == null) return;
        String s;
        
    	Iterator iter = userData.iterator();
        log( "MyConnID="+connID );
        log( "MyDN="+sDN );
        while(iter.hasNext()) {
            KeyValuePair item = (KeyValuePair)iter.next();
            s = item.getStringValue();
            if (s==null) s = String.valueOf(item.getIntValue());
            s = item.getStringKey() + "=" + s;
            log (s);
        }
    }
	
	private static int toInt( String s ) {
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

	private static String nowMS() {
		// Display the ms time in a readable state
        DateFormat SDFormat = new SimpleDateFormat("yyyyMMdd.HHmmss.SSS");
        long t = System.currentTimeMillis();
        return SDFormat.format(new Date(t));
	}
	
	private static String nowSec() {
		// Display the ms time in a readable state
		String s = nowMS();
		s = s.substring( 0, s.lastIndexOf(".") );
        return s;
	}
	
	private static void appendToFile( String s, String sFile )  throws Exception {  
		PrintWriter out = null;  
		boolean append=true;
		//if (overWrite!=null) if (overWrite.length>0) append = ! overWrite[0];
		//String sFullFile = MYpath+sFile;
		out = new PrintWriter( new BufferedWriter( new FileWriter(sFile,append)));  
		out.print( s );  
		out.flush();  
		out.close();   
	}
	/*
	private static String toDateTime( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("d-MMM-yy HH:mm:ss.SSS").format(new java.util.Date( dtms )) );
	}
	*/
	private static String toTime( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("HH:mm:ss.SSS").format(new java.util.Date( dtms )) );
	}
	
	private static String toNumDay( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("yyyyMMdd").format(new java.util.Date( dtms )) );
	}

	
    private static void log( String s ) {
    	//System.out.println(nowMS()+": "+s);
    	try {
    		long t = System.currentTimeMillis();
    		// this will be changed to be dir that exe is in ------------------------- TODO !!!!
        	String sFile = LOGPATH + SLASH + toNumDay( t ) + ".log";
    		appendToFile( toTime(t)+" "+s+CR, sFile );
    	} catch (Exception e) {}
    }

    private static int cigna2Genesys( int iOutcome ) {
		switch(iOutcome) {
		case 0: { return 7; } // None (7=ring without answer)
		case 1: { return 33; } // DmResponded (33=answer)
		case 2: { return 53; } // Incorrect Number (53=wrong number)
		case 3: { return 33; } // More information
		case 4: { return 7; } // Not Contacted
		case 5: { return 33; } // Not Interested
		case 6: { return 33; } // Sale
		case 7: { return 33; } // Ineligible
		case 8: { return 9; } // Answer machine (9=answer machine)
		case 9: { return 33; } // Incomplete Sale
		case 12: { return 33; } // TM Sale
		case 16: { return 33; } // IC Sale
		case 20: { return 33; } // Ineligible
		case 101: { return 33; } // Reschedule (done different)
		}
		return 32; // silence
    }

	
	private void openTServer( String TS1, String TS2 ) {
		log("open Tserver:"+TS1+" & "+TS2);
        // Create Protocol Manager Service object
        protocolManagementService = new ProtocolManagementServiceImpl();

        // Create and initialize connection configuration object for TServer.
        TServerConfiguration tserverConfiguration = new TServerConfiguration(TS_ID);

        try {
			tserverConfiguration.setUri(new URI("TCP://"+TS1));
			if ( TS2.length()>2 ) {
				tserverConfiguration.setWarmStandbyUri(new URI("TCP://"+TS2));
				tserverConfiguration.setWarmStandbyTimeout(10000);
				tserverConfiguration.setWarmStandbyAttempts((short) 2);
			}
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
        tserverConfiguration.setClientName("AE");  // this appears in the logs
        tserverConfiguration.setClientPassword("");

        // Register this connection configuration with Protocol Manager
        protocolManagementService.register(tserverConfiguration);

        protocolManagementService.addChannelListener((ChannelListener)this);
        
        // Create and Initialize Message Broker Application Block
        eventReceivingBrokerService = new EventReceivingBrokerService(
        	new SingleThreadInvoker("EventReceivingBrokerService-1"));
		eventReceivingBrokerService.register(
		    new TServerEventsHandler(),
		    new MessageFilter(protocolManagementService.getProtocol(TS_ID).getProtocolId())
		);
		
		protocolManagementService.getProtocol(TS_ID).setReceiver(eventReceivingBrokerService);
	}
	
	private void finalizePSDKApplicationBlocks(){
		// Cleanup code
        // Close Connection if opened (check status of protocol object)
		log("Finalize PSDK");
		Protocol protocol = protocolManagementService.getProtocol(TS_ID);
        
		if (protocol.getState() == ChannelState.Opened) // Close only if the protocol state is opened
        {
            try {
				protocolManagementService.getProtocol(TS_ID).close(); // synchronous
			} catch (ProtocolException e) {
				e.printStackTrace();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }

        // Stop EventBroker - This should release internal message receiving thread
		// Failing to do this would cause the application to keep running
        eventReceivingBrokerService.releaseReceivers();
        
        // Unregister the protocol configuration object
        protocolManagementService.unregister(TS_ID);
	}
		
	private void connect(){
		log("connect");
		// Open the connection - only when the connection is not already opened
        // Opening the connection can fail and raises an exception
        try {
        	Protocol protocol = protocolManagementService.getProtocol(TS_ID);
        	
        	if(protocol.getState() == ChannelState.Closed)
        		protocol.open(); // synchronously
    			//protocol.beginOpen(); // asynchronously
        	
    	} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void disconnect(){
		log("disconnect");
        try
        {
        	// Get the protocol associated with this configuration
        	Protocol protocol = protocolManagementService.getProtocol(TS_ID); 

        	// Close if protocol not already closed
        	if (protocol.getState() == ChannelState.Opened){
	            protocol.close();  // synchronously
	            //protocol.beginClose();  // asynchronously
	
	            // This method does not have a LinkDisconnected event called for it
	            //OnLinkDisconnected(null);
        	}
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
	
	private  void register( String sDN ){
		log("register:"+sDN);
        try
        {
            // Create the register address request object for TServer (Voice Platform SDK). 
            RequestRegisterAddress request =
                RequestRegisterAddress.create(
                sDN,										// DN to register
                RegisterMode.ModeShare,					// Share DN info with other apps?
                ControlMode.RegisterDefault,			// Register DN with switch?
                AddressType.DN);						// Type of DN

            // Request asynchronously
            protocolManagementService.getProtocol(TS_ID).send(request);
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
	}

	private void unregister(String sDN){
		log("unregister:"+sDN);
        try {
            // Create the register address request object for TServer. 
            RequestUnregisterAddress request =
                RequestUnregisterAddress.create(
                sDN, 									// DN to unregister
                ControlMode.RegisterDefault);			// Unregister DN with switch?

            // Request asynchronously
            protocolManagementService.getProtocol(TS_ID).send(request);
        } catch (Exception e){
        	e.printStackTrace();
    	}
	}
	
	private void queryServer() {
		log("query server");
        try {
            RequestQueryServer request = RequestQueryServer.create();
            protocolManagementService.getProtocol(TS_ID).send(request);  // asynch
		} catch (IllegalStateException e) {
			e.printStackTrace();
			//bKill = true;
        } catch (Exception e){
        	e.printStackTrace();
    	}
	}
	
	private void makeReady() {
		log("make ready");
		try {
			RequestAgentReady request = RequestAgentReady.create();
			//request.setThisDN(arg0);
			protocolManagementService.getProtocol(TS_ID).send(request);
        } catch (Exception e){
        	e.printStackTrace();
		}
	}
	
	private void attachDataToCall( String sADN, ConnectionId connID, KeyValueCollection KVP ) throws Exception {
		log("attach:"+connID+" "+sADN);
		 
        try {
        	TimeStamp ts = TimeStamp.create();
        	CommonProperties props = CommonProperties.create(ts);
        	props.setConnID(connID);
        	props.setUserData(KVP);
        	props.setThisDN(sADN);
        	RequestDistributeUserEvent request = RequestDistributeUserEvent.create(sADN, props);
        	
        	protocolManagementService.getProtocol(TS_ID).send(request);
        } catch (Exception e) {
        	e.printStackTrace();
        }
	}
	
	public attachData( String sTS1, String sTS2, String sADN, String sConnID, int iTimeOut, KeyValueCollection KVP )throws Exception {
		super();

		lNow = System.currentTimeMillis();
		bDone = false;
		bACW = false;
		openTServer(sTS1,sTS2);
		Thread.sleep( 250 ); // ms
		connect();
		Thread.sleep( 250 );
		register(sADN);
		sConnID = sConnID.toLowerCase();
		if (sConnID.equals("scan")) {
			GKVP=KVP;
		} else {
			ConnectionId connID = new ConnectionId(sConnID);
			attachDataToCall( sADN, connID, KVP );
		}
		// Wait until we are done, or timeout expired
		while (!bDone && ( iTimeOut*1000+lNow > System.currentTimeMillis() ) ) {
			Thread.sleep(100); // ms
		}
		Thread.sleep(150);
		if (bACW) {
			//makeReady(); 
			Thread.sleep(50);
		}
		unregister(sADN);
		Thread.sleep( 250 );
		disconnect();
		Thread.sleep( 250 );
		finalizePSDKApplicationBlocks();
	}
	
	public static void finish( int iResult, String sResult ) {
		log("exit: "+iResult+"|"+sResult);
		System.out.println(iResult+"|"+sResult);
		System.exit(iResult);
	}

	public static void main(String[] args) {
		int ev=0, iTimeOut=10;
		int iCallRes=0, iOutcome;
		String s, sData;
		CR = System.getProperty("line.separator");
		SLASH = System.getProperty("file.separator");
		LOGPATH = ClassLoader.getSystemClassLoader().getResource(".").getPath();
		if (LOGPATH.startsWith("/")) LOGPATH = LOGPATH.substring(1); // chop out first one
		LOGPATH = LOGPATH.replace("/", SLASH) + "logs";
		if (new File(LOGPATH).mkdir()) { // this is clever enough not to create if already exists
			// dirs created
		}
		
		bDone = true;
		
		log("Attach V 2.13");
		log("Passed:"+(args.length>0?args[0]:"")+" "+(args.length>1?args[1]:"")+" "+(args.length>2?args[2]:"")+" "+(args.length>3?args[3]:"")+" "
				+(args.length>4?args[4]:"")+" "+(args.length>5?args[5]:"")+" "+(args.length>6?args[6]:""));
		if (args.length<6) {
			log("Params:");
			log("   primary-Tserver:port backup-Tserver:port AgentDN CONNID 10 \"data\" [ \"MM/DD/YYYY HH:mm\" ]");
			log("E.g.");
			log("attach ctiwnfw01:5202 ctiakfw01:5202 5007 064c027b68772376 10 ");
			log("\"CLI|AgentID|OCSID|HandleID|CampaignName|CallingList|ListID|CampaignCode|OutcomeCode|OutcomeText\"");
			log("Notes:");
			log("1. This is HA aware. So will handle primary and secondary Tservers.");
			log("2. Wrap data in quotes.");
			log("3. Agent will be made ready after.");
			log("4. Note that if the optional date-time is specified, it will reschedule the call.");
			log("   Note date is MM/DD, and is UTC time and is 24-hour.");
			finish(1,"Not enough parameters (see log)");
		}
		
		if ( !args[0].contains(":") ) {
			finish(2,"Bad Tserver format (ctiwnfw01:3024)");
		}
		KeyValueCollection KVP = new KeyValueCollection();
		sData = args[5];
		if ((sData.split("\\|")).length<10) {
			log("payload passed:"+sData);
			//System.out.println("\"CLI|AgentID|OCSID|HandleID|CampaignName|CallingList|ListID|CampaignCode|OutcomeCode|OutcomeText\"");
			finish(3,"Main payload requires 10 items \"CLI|AId|OId|HId|CN|CL|LId|CC|OC|OT\"");
		}
		KVP.addString( "GSW_PHONE", sData.split("\\|")[0] );
		KVP.addString( "Phone", sData.split("\\|")[0] );	
		KVP.addString( "GSW_AGENT_ID", sData.split("\\|")[1] );			
		KVP.addString( "AgentId", sData.split("\\|")[1] );	
		KVP.addInt( "GSW_APPLICATION_ID", toInt( sData.split("\\|")[2]) );			
		KVP.addString( "GSW_RECORD_HANDLE", sData.split("\\|")[3] );			
		KVP.addString( "GSW_CAMPAIGN_NAME", sData.split("\\|")[4] );			
		KVP.addString( "GSW_CALLING_LIST", sData.split("\\|")[5] );
		KVP.addString( "ListID", sData.split("\\|")[6] );
		//KVP.addString( "CustFirstName", sData.split("\\|")[7] );
		//KVP.addString( "CustLastName", sData.split("\\|")[8] );
		KVP.addString( "CampaignCode", sData.split("\\|")[7] );
		iOutcome = toInt(sData.split("\\|")[8]);
		KVP.addString( "Outcome", String.valueOf(iOutcome) );
		KVP.addString( "OutcomeDescription", sData.split("\\|")[9] );
		
		if (args.length==6) {
			iCallRes = cigna2Genesys( iOutcome );
			KVP.addInt("GSW_CALL_RESULT", iCallRes );
			KVP.addString( "GSW_AGENT_REQ_TYPE", "RecordProcessed" );
			KVP.addString( "GSW_TREATMENT", "RecordTreatCampaign" );
		} else {
			s = args[6];
			if (s.equals("DONOTCALL")) {
				//KVP.addString( "GSW_AGENT_REQ_TYPE", "DoNotCall" );
			} else if (s.contains("/")) {
				if ( s.contains(":") && (s.length()>13) ) {
					KVP.addString( "GSW_AGENT_REQ_TYPE", "RecordReschedule" );
					KVP.addString( "GSW_CALLBACK_TYPE", "Campaign" );
					KVP.addString( "GSW_DATE_TIME", s );
					log("reschedule at "+s);
				} else {
					finish(5,"Bad reschedule date format \"MM/DD/YYYY HH:mm\" (24H)");
				}
			}
		}
		try {
			iTimeOut = toInt(args[4]);
			attachData m;
			m = new attachData( args[0], args[1], args[2], args[3], iTimeOut, KVP );
			if (!bDone) finish(6,"Time out");
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			log(sw.toString());
			finish(10,"Unknown error:"+e.toString());
			//e.printStackTrace();
		}
		log("end "+nowSec());
		finish(0,"OK");
	}

	@Override
	public void onChannelClosed(ChannelClosedEvent arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onChannelError(ChannelErrorEvent arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onChannelOpened(EventObject arg0) {
		// TODO Auto-generated method stub
	}

}
