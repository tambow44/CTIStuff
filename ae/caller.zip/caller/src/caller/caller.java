package caller;

public class caller {
	public class mine {
		public mine() {
			System.out.print("mine");
		}
	}
}
