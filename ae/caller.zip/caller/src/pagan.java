public class pagan {
	static int ngobs=0;
	
	public static class Card {
		public int kd, hp;
		public String sN;
		Card(String s, int k, int h) {
			kd=k;
			hp=h;
			sN = s;
		}
		
	}
	
	public class Goblin {
		int OFFICERS=1, COMMANDANT=2, TRAINER=3, WHORES=4, INFIRMARY=5, FIRST=6, CELLS=7, PARADE=8;
	
		
		public int hp, rank, wounds, location, team;
		Goblin(int h, int r, int t ) {
			hp=h;
			rank=r;
			wounds=0;
			location=0;
			team=t;
		}
	}
	public static int game(int nPlrs) {
		int iPack=0;
		int nPack=21;
		Card card[] = {};
		card[1] = new Card("",4,2);
		while (true) {
			
			if (iPack>nPack) break;
		}
		return 1;
	}
	
	private static void campPhase() {
		for (int i=1; i<=ngobs; i++) {
			
		}
	}

	private static boolean patrolPhase() {
		
		return false;
	}

	public static void playGame() {
		while (true) {
			campPhase();
			if (!patrolPhase()) break;
		}
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println("abc");
		playGame();
	}
}
