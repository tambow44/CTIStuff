
public class prime {
	
	static long numPrimes(long f, long t) {
		long k=0;
		if ((f % 2)==0) f++;
		for (long i=f; i<=t; i++) {
			if (prime(i)) k++;
		}
		return k;
	}

	static boolean prime(long n){
		long top,i=1;
		top = (long) Math.sqrt(n);
		if ((n % 2) == 0) return false;
		if ((n % 3) == 0) return false;
		while (i<=top) {
			i = i + 4;
			if ((n % i) == 0) return false;
			i = i + 2;
			if ((n % i) == 0) return false;
		}
		return true;
	}

	public static void main(String[] args) {
		System.out.println("num:"+numPrimes(1,10000000));
	}

}
