package setlo;

public class setloBean implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String numtext="", DNfile="";
	
	//public caller() {  }
	
	public String getNumtext() {
		return this.numtext;
	}
	
	public void setNumtext(String s) {
		this.numtext = s;
	}
	
	public void setDnfile(String s) {
		this.DNfile = s;
		this.numtext = "contents of the file "+s;
	}
	
	public String getDnfile() {
		return this.DNfile;
	}
	
}