import java.io.File;

import calltest.*;
public class call {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String sDN="039826818", sLogsDir="logs", sDNDir="DN";
		int e, iQueueTimeout=600, iAnswerTimeout=15;

		//CR = System.getProperty("line.separator");
		if (args.length==0) {
			System.out.println( String.format("DN [ queue-timeout(secs, def:%d) [ answer-timeout(secs, def:%d)"+
								"[ logs-dir(def:%s) [ DNlogs-dir(def:%s) ]]]]",iQueueTimeout,iAnswerTimeout,sLogsDir,sDNDir));
			System.exit(1);
		}
		sDN=args[0];
		if (args.length>1) iQueueTimeout = calltest.toInt(args[1]);
		if (args.length>2) iAnswerTimeout = calltest.toInt(args[2]);
		if (args.length>3) sLogsDir = args[3];
		if (args.length>4) sDNDir = args[4];

		if (!new File(sLogsDir).isDirectory()) {
			System.out.println("Logs directory \""+sLogsDir+"\" doesn't exist.");
			System.exit(1);
		}
		if (!new File(sDNDir).isDirectory()) {
			System.out.println("Logs directory \""+sDNDir+"\" doesn't exist.");
			System.exit(1);
		}
		
		calltest x=new calltest();
		calltest.MyTServer ts = x.new MyTServer();
		
		e = ts.makeTestCall("8003",sDN,"aklwpctisip01",6000,iQueueTimeout,iAnswerTimeout,sLogsDir,sDNDir);
		//s = s.replaceAll("\\|",CR );
		System.out.println( e );
		System.exit(e);
	}

}
