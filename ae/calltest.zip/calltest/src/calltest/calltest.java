package calltest;

//import java.util.Date;
import java.util.ArrayList;
import java.io.*;

//import com.genesyslab.platform.commons.protocol.ProtocolException;

//import calltest.calltest.MyEvent;
import Genesys.ComLib.TKV.TKVList;
import Genesys.ComLib.TKV.TKVPair;
import Genesys.TLib.*;

public class calltest {
		
	public static long dtmsStart = 0;

	public long delta() {
			// Useless fact: Java long is 63 bits (& 1 sign bit), so a millisecond counter will last 292 million years
			long l = System.currentTimeMillis() - dtmsStart;
			return l;
	}

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors
		if (s==null) return 0;
		return ( s.matches("-?\\d+") ? Integer.parseInt(s) : 0 );
	}

	public static int toDayHour( long  dtms ) {
		return toInt( (String)( new java.text.SimpleDateFormat("HH").format(new java.util.Date( dtms )) ) );
	}

	public static String toNumDay( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("yyyyMMdd").format(new java.util.Date( dtms )) );
	}

	public static String toDateTime( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("d-MMM-yy HH:mm:ss.SSS").format(new java.util.Date( dtms )) );
	}

	public static String toTime( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("HH:mm:ss.SSS").format(new java.util.Date( dtms )) );
	}

	public ArrayList<String> alReadFile( String sFile ) throws IOException, FileNotFoundException {
			// Read file sFile into ArrayList (1 string per line)
			// Trim lines, and ignore blank lines and lines that start with #
			ArrayList<String> al = new ArrayList<String>();
			String sLine=null;
			BufferedReader inp=null;
			try {
				//java.net.URL url = new java.net.URL("jndi:/localhost"+MYrequest.getContextPath()+"/"+sFile);
				//inp = new BufferedReader(new InputStreamReader(url.openStream()));
				inp = new BufferedReader(new FileReader(new File(sFile)));
				while ((sLine = inp.readLine()) != null) {
					sLine = sLine.trim();
					if (sLine.length()>0) if (!sLine.startsWith("#")) al.add( sLine );
				}
				inp.close();
			//} catch (FileNotFoundException e) {		// uncomment this if you want to ignore fileNotFounds
			//	if (inp!=null) inp.close();
			}	finally {
				if (inp!=null) inp.close();
			}
			return al;	
	} 

	class MyEvent {
		public TEvent event;
		public long ms;
		public String sExtra;
	}

	public class DispHandler implements TServerDispatchHandler {
	  // Since we are using a route-point, it can handle multiple phone-calls.
	  // That means multiple events (from these multiple calls) all arriving at arbitrary times all intermeshed. 
	  // And this means we need to distinguish OUR events from those OTHER events. 
	  // So I use CallID and OtherDN to give me some uniqueness, and don't bother to save the bad ones.
	  private ArrayList<MyEvent> aEvent = new ArrayList<MyEvent>();
	  private MyEvent myEvent;
	  private TEvent evTrigger=null;
	  private String sDigits = "";
	  private String sExtraText = "";
	  private String sLastAgentID = "";
	  private TConnectionID myConnID = null;
	  private int myCallID = 0, iOtherDN=0;
	  private int[] aTriggers;
	  
		public void dispatch_function(TEvent event) {
			int cid = event.CallID;
			if (cid>0) {
				if (myCallID>0) {
					if (cid!=myCallID) return; // not my call - go away
				} else {
					int iODN = toInt(event.OtherDN);
					if ((iODN>0)&&(iOtherDN>0)&&(iODN!=iOtherDN)) return;
					myCallID = cid;
					myConnID = event.ConnID;
				}
			}
			myEvent = new MyEvent();
		  	myEvent.event = event;
		  	myEvent.sExtra = sExtraText;
		  	myEvent.ms = System.currentTimeMillis();
			aEvent.add(myEvent);
			sExtraText = "";
			System.out.println(String.format("%d ms: %s", myEvent.ms, myEvent.event.getEventName() ) );
			if (event.AgentID != null) sLastAgentID = event.AgentID;
			if (event.Event == TServer.EventAgentLogout || event.Event == TServer.EventUnregistered) sLastAgentID="";
			if (event.CollectedDigits!=null) sDigits += event.CollectedDigits;
			if (event.Event == TServer.EventError) evTrigger = event;
			if (aTriggers!=null) {
				for (int i=0; i<aTriggers.length; i++) {
					if (event.Event == aTriggers[i]) evTrigger = event;
				}
			}
		};
		
		public void setText(String s) {
			//if (sExtraText.length()>0) sExtraText += "|";
			sExtraText += s+"|";
		}
		
		public int getSize() {
			return aEvent.size();
		}
		
		public long getMs(int i) {
		  if ((i<0)||(i>=aEvent.size())) i=aEvent.size()-1;
			return ((MyEvent)aEvent.get(i)).ms;
		}
		
		public String lastAgentID() {
		  return sLastAgentID;
		}
		
		public String getText(int i) {
		  if ((i<0)||(i>=aEvent.size())) i=aEvent.size()-1;
			return ((MyEvent)aEvent.get(i)).sExtra;
		}
		
		public String getText0() {
			// When we don't have any events, there may be extra text loaded.
			return sExtraText;
		}
		
		public TConnectionID getConnID() {
			// This is the ConnID of the whole call
			return myConnID;
		}
		
		public void setOtherDN(int i) {
			iOtherDN = i;
		}

		public void setTriggers(int[] aEvents) {
			aTriggers = aEvents;
		}
		
		public TEvent getTriggeredEvent() {
			return evTrigger;
		}
		
		public void clearTrigger() {
			evTrigger = null;
		}
		
		public String getDigits() {
			return sDigits;
		}
		
		public TEvent getE(int i) {
		  if ((i<0)||(i>=aEvent.size())) i=aEvent.size()-1;
			return ((MyEvent)aEvent.get(i)).event;
		}
	}

	public class MyTServer extends TServer {

		public int MYDN=0;
		public DispHandler dh = new DispHandler();

		private int waitForEvent( int iTimeOut, int ... aEvent ) throws InterruptedException {
		  // The dispatch handler is updated asynchronously. Single-run web pages are notoriously synchronous,
		  // so if we want to trigger on a particular event (or group of), we need to pass these events through to
		  // the dispatch handler (setTriggers) and let it check through this list upon every event that arrives.
		  // If one of the chosen events is struck (getTriggeredEvent), we can return immediately, 
		  // otherwise, wait until time-out.
		  //
			// Wait for any of the events passed-in (aEvent), or for at least iTimeOut ms
			// Return the event we find it, or 0 for timeout
			TEvent ev;
			long t;
			
			t = System.currentTimeMillis();
			dh.setTriggers(aEvent);
			while ( (System.currentTimeMillis() - t) <= iTimeOut) {
				ev = dh.getTriggeredEvent();
				if (ev!=null) {
					dh.clearTrigger();
					return  ev.Event;
				}
				Thread.sleep( 20 );  //  ms 
			}
			// It is a timeout if we get here
			dh.setText( String.format("================== %d ms timeout (%d) ===============", iTimeOut, (System.currentTimeMillis() - t) ) );
			return 0;
		}

		public int OpenTS (String sServer, int iPort ) throws InterruptedException, TServerEx {
			return OpenHATS(sServer, iPort, "", 0);
		}
		
		public int OpenHATS (String sTS1, int iPort1, String sTS2, int iPort2 ) throws InterruptedException, TServerEx {
			// Open HA TS (HA=High Availability)
			// Try to connect to sTS1 sPort1
			// If we get a connection timeout, use the backup host & port (sTS2 & iPort2). 
			// If we get a successful connect, then check the EventLinkConnected event's userdata[0]. This contains the host of the
			// backup TS. If it matches *our* host (sTS1), then we are not the primary TS. Connect to sTS2 in this case.
			int ee=0;
			boolean bTry2=false;
			dh.setText("Connect primary ("+sTS1+":"+iPort1+")" );
			try {
				OpenServerEx( sTS1, iPort1, dh, "ae" , "ae", 1); // 1=asynchronous (0 no longer works)
			} catch (TServerEx e) {
				dh.setText("Primary fails" );
				if (iPort2==0) {
					if (e.getMessage().contains("socket")) { 
						dh.setText(e.getMessage());
						return 2;
					}
				}
				if ((iPort2==0)||!e.getMessage().contains("socket")) {
					throw e;
				}
				bTry2=true;
			}
			if ((iPort2>0)&&!bTry2) {
				ee = waitForEvent( 10000, EventLinkConnected );
				TKVList kv = dh.getE(-1).UserData; // Get the EventLinkConnected event
				if (kv!=null) {
					kv.TKVListInitScanLoop();
					TKVPair kvp = kv.TKVListNextPair();
					if (kvp!=null) {
						String s = kvp.TKVListStringValue(); 
						if (s.equalsIgnoreCase(sTS1)) {  // An indication that primary TS is in backup-mode
							dh.setText("Primary is in backup mode" );
							ee = CloseTS();
							bTry2 = true;
						}
					}
				}
			}
			if (bTry2) {
				dh.setText("Connect secondary ("+sTS2+":"+iPort2+")" );
				OpenServerEx( sTS2, iPort2, dh, "ae" , "ae", 1);			
				ee = waitForEvent( 10000, EventLinkConnected );
			}
			ee=0;
			return ee;
		}

		public int CloseTS () throws InterruptedException, TServerEx {
			dh.setText("Disconnect");
			int[] a = {EventServerDisconnected};	dh.setTriggers( a ); 
			// TCloseServer works so damn fast that it triggers the dispatch-handler before I can get to WaitforEvent. So I have to
			// load the triggers before I call TCloserServer
			TCloseServer();
			int e = waitForEvent( 401, EventServerDisconnected );
			return e;
		}
		
		public int MakePredSIPCall(String sRP, String sDN, int iRingTimeOut, int iQueueTimeOut ) throws InterruptedException, TServerEx {
		  // Make a predictive call using RP sRP to sDN. 
		  // RingTimeout is seconds to wait for the DN to answer
		  // QueueTimeOut is how long to wait after answering - total call length
			@SuppressWarnings("unused")
			int e,ee;

			dh.setOtherDN(toInt(sDN));

			dh.setText( "Register "+sRP );
			
			e = RegisterAddress(sRP,0,0,0,null);
			e = waitForEvent(20000, EventRegistered);

			dh.setText( String.format("Make predictive call to %s",sDN) );

			e = MakePredictiveCall(sRP, sDN, iRingTimeOut, null, null, null );
			// These are the "normal" events and show that there is an agent on the line and that
			// they answered and hung-up (EventAbandoned), or answered and pressed a key (EventDiverted).
			// If the ringTimeout expires, EventReleased happens.
			// Anything else and we will time-out. waitForEvent returns 0 on a timeout.
			// (EventDestinationBusy is when the target is engaged, but you should not get that from 
			// call centre lines, so it is treated as a fault)
			ee = waitForEvent( iQueueTimeOut*1000, EventDiverted, EventAbandoned, EventReleased );

			Thread.sleep(500); // just wait a bit
			
			if (ee==EventReleased) dh.setText( String.format("=========== EventReleased, in this case, means the DN was not answered within the ring time-out (%d s)",iRingTimeOut) );
			
			if (ee==0) {	 // timeout
				if (dh.getConnID()!=null) {
					//i = ReleaseCall(sRP, dh.getConnID(), null, null);
					//e = waitFor(1000, EventReleased);
					// With the SIP server, we can't use ReleaseCall to stop. SIP servers require a messy
					// sequence of steps to release, which I have not attempted to do from the java libraries. 
					// So I let the strategy do that, and instigate it by
				    // deleting the jspcmd KVP; which the strategy will check for. 
					e = DeleteUserData(sRP, dh.getConnID(), "jspcmd" );
					e = waitForEvent(8000, EventDiverted, EventAbandoned );
					
					//TKVList kvp = new TKVList("jspcmd");   this is an alternate way, if you want to be a smart-arse
					//kvp.TKVListAddString("jspcmd","stop");
					//i = UpdateUserData(sRP, dh.getConnID(), kvp );

				}
			}
			
			dh.setOtherDN(0);
		
			dh.setText( "Unregister");
			e = UnregisterAddress(sRP,0,null);
			e = waitForEvent(1000, EventUnregistered);
			return ee;
		}

		public int makeTestCall( String sRP, String sDN, String sTServer, int iPort, int iQueue, int iAnswer, 
									String sLogDir, String sDNDir ) throws Exception {
			/*
			 * Make a test call (predictive) to sDN via sRP on sTServer:iPort. 
			 * Write output to file in sDNDir named DN.dn
			 * And append output to log file in sLogDir.
			 * Log file is named by the day in the format yyyymmdd.log 
			 */
			StringBuilder sAll;
			long t;
			int e;

			String s, sFile,CR,SLASH; 

			//if (!sDN.matches("\\d+")) return "bad DN:"+sDN;

			CR = System.getProperty("line.separator");
			SLASH = System.getProperty("file.separator");

			//MYrequest = new HttpServletRequestWrapper(request);
			//MYpath = application.getRealPath("/");

			sAll = new StringBuilder();

			dtmsStart = System.currentTimeMillis();

			sAll.append( "================ "+toDateTime(dtmsStart)+" ========|" );

			OpenTS( sTServer, iPort);
			
			e = MakePredSIPCall( sRP, sDN, iAnswer, iQueue ); // timeout to answer, time to wait in queue
			
			CloseTS();
			
			for (int i=0; i < dh.getSize(); i++) {
				t = dh.getMs(i);
				s = dh.getText(i);
				if (s.length()>1) sAll.append(s);
				sAll.append( String.format("%s (%dms) %s(%d) ", toTime(t), t-dtmsStart, dh.getE(i).getEventName(), dh.getE(i).Event ) );
				if (dh.getE(i).ConnID!=null) sAll.append( dh.getE(i).ConnID+" " );
				if (dh.getE(i).CallID>0) sAll.append( String.format("callid=%d ", dh.getE(i).CallID) );
				if (dh.getE(i).ThisDN!=null) sAll.append( dh.getE(i).ThisDN+" ");
				if (dh.getE(i).OtherDN!=null) sAll.append( dh.getE(i).OtherDN+" ");
				if (dh.getE(i).CollectedDigits!=null) if (dh.getE(i).CollectedDigits.length()>0) sAll.append( String.format("key=%s",dh.getE(i).CollectedDigits));
				sAll.append("|");
			}
			
			s = sAll.toString().replaceAll("\\|",CR );
			if (sLogDir.length()>=1) {
				sFile = sDNDir + SLASH + sDN + ".dn";
				overWriteFile( s, sFile );  // Changes the mod date of the file
				//t = dtmsFileLastModified(sFile);
			}
			
			if (sLogDir.length()>=1) {
				sFile = sLogDir + SLASH + toNumDay(dtmsStart) + ".log";
				appendToFile( s, sFile );
			}
			//sAll.append( String.format("ConnID=%s digits=%s |", dh.getConnID(), dh.getDigits() ) );

			//s = sAll.toString();
			return e;
		}
		
		public int logoutAgentFromSwitch( String sDN, String sTServer, int iPort, boolean bDoIt ) throws Exception {
			// Register sDN, if there is an agent logged in to it, log her off
			int e=0, ee=0;
			System.out.println("BefTS" );
			OpenTS( sTServer, iPort);
			System.out.println("AftTS" );
	/*
			//TKVList kvp = new TKVList();
			int a[0] = EventRegistered;	dh.setTriggers( a ); 
			e = RegisterAddress(sDN,0,0,0,null);
			ee = waitForEvent(20000, EventRegistered);

			if ( dh.lastAgentID().isEmpty() ) {
				dh.setText( String.format("No agent on %s",sDN) );
			} else {
				dh.setText( String.format("Agent %s is on %s",dh.lastAgentID(),sDN) );
				if (bDoIt) {
					dh.setText( String.format("Log agent %s out",dh.lastAgentID() ) );
					e = AgentLogout(null, sDN, null, null);	
					ee = waitForEvent( 5000, EventAgentLogout );
				}
				Thread.sleep(100); // just wait a bit
			}

			Thread.sleep(50);
			
			dh.setText( "Unregister");
			a[0] = EventUnregistered;	dh.setTriggers( a ); 
			e = UnregisterAddress(sDN,0,null);
			e = waitForEvent(1002, EventUnregistered);
*/
			Thread.sleep(50);
			System.out.println("BefCTS" );
			
			CloseTS();
			System.out.println("AftCTS" );
			return ee+e;
		}
		
		public int CheckRP(String sRP, String sDN, String sTServer, int iPort, String sLogDir ) throws Exception {
			  // Check a single sRP by registering and then making a predictive call to sDN.
			return CheckHARP(sRP, sDN, sTServer, iPort, "", 0, 2000, sLogDir);
		}

		public int CheckHARP(String sRP, String sDN, String sTS1, int iPort1, String sTS2, int iPort2, int iDelay, String sLogDir ) throws Exception {
			// Check a single sRP by registering and then making a predictive call to sDN.
			  // The assumption being, if we get NetworkReached, then we know the RP is good.
			// If the delay is negative, make it positive but then don't do a release after.
			@SuppressWarnings("unused")
				int e,ee=0;
				String sFile,s;
				long t;

				dtmsStart = System.currentTimeMillis();
				
				if (OpenHATS( sTS1, iPort1, sTS2, iPort2)==0) {
				
				dh.setText( "Register "+sRP );
				
				e = RegisterAddress(sRP,0,0,0,null);
				e = waitForEvent(1000, EventRegistered);

				dh.setText( String.format("Make predictive call to %s",sDN) );
				
				e = MakePredictiveCall(sRP, sDN, 10, null, null, null );
				ee = waitForEvent(12500, EventNetworkReached, EventReleased);

				Thread.sleep( (iDelay<0?-iDelay:iDelay) ); // wait a bit
			
				if ((dh.getConnID()!=null) && (iDelay>0)) {
					dh.setText( "Release");
					e = ReleaseCall(sRP, dh.getConnID(), null, null);
					e = waitForEvent(1000, EventReleased);
				}
				dh.setText( "Unregister");
				e = UnregisterAddress(sRP,0,null);
				e = waitForEvent(1000, EventUnregistered);
				
				CloseTS();
				}
				if (sLogDir!=null) if (sLogDir.length()>=1) {
					StringBuilder sAll = new StringBuilder();
					sAll.append( "================ "+toDateTime(dtmsStart)+" ========|" );
					if (dh.getSize()==0) sAll.append(dh.getText0());
					for (int i=0; i < dh.getSize(); i++) {
						t = dh.getMs(i);
						s = dh.getText(i);
						if (s.length()>1) sAll.append(s);
						sAll.append( String.format("%s (%dms) %s ", toTime(t), t-dtmsStart, dh.getE(i).getEventName() ) );
						if (dh.getE(i).ConnID!=null) sAll.append( dh.getE(i).ConnID+" " );
						//if (dh.getE(i).CallID>0) sAll.append( String.format("callid=%d ", dh.getE(i).CallID) );
						//if (dh.getE(i).ThisDN!=null) sAll.append( dh.getE(i).ThisDN+" ");
						//if (dh.getE(i).OtherDN!=null) sAll.append( dh.getE(i).OtherDN+" ");
						sAll.append("|");
					}
					
					s = sAll.toString().replaceAll("\\|",System.getProperty("line.separator") );
					if (sLogDir.equals("con")) {
						System.out.println(s);
					} else {
						sFile = sLogDir + System.getProperty("file.separator") + toNumDay(dtmsStart) + ".log";
						appendToFile( s, sFile );
					}
				}
				return ee;
		}	
	}	

	public static void appendToFile( String s, String sFile, boolean ...overWrite )  throws Exception {  
			PrintWriter out = null;  
			boolean append=true;
			if (overWrite!=null) if (overWrite.length>0) append = ! overWrite[0];
			//String sFullFile = MYpath+sFile;
			out = new PrintWriter( new BufferedWriter( new FileWriter(sFile,append)));  
			out.print( s );  
			out.flush();  
			out.close();   
	} 

	public static void overWriteFile( String s, String sFile )  throws Exception {
			appendToFile( s, sFile, true);
	}

	public static long dtmsFileLastModified(String sFile) throws Exception {
			File f = new File(sFile);
	    return f.lastModified();
	}
	
}