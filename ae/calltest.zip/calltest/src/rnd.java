import java.util.Arrays;

public class rnd {
	public static final int BkHi=1, BkLo=2, Jump=3, StHi=4, StLo=5, Kick=6 ;
	public static String[] aManoeuvre = {"","BH","BL","J","SH","SL","K"};
	
	class Plr {
		int manoeuvre=0, lastMan=0, hp, stam, ST, QK, sum;
		int[] strategies;
		double win;
		
		public Plr() { reset(10,20,0,0); }
		
		public int getMan() { return manoeuvre; }
		public void setMan(int v) { 
			lastMan=manoeuvre;
			manoeuvre=v;
		}
		public int getST() { return ST; }
		public int getQK() { return QK; }
		public int getHP() { return hp; }
		public int getStam() { return stam; }
		public void reset(int h, int s1, int s, int q) { hp=h; stam=s1; ST=s; QK=q; setMan(0); lastMan=0; }
		
		public double getWin() { return win; }
		public void setWin(double d) { win=d; }
		
		public int[] getStrategy() { return strategies; }
		public void setStrategy(int ...strats ) throws Exception {
			strategies=strats;
			sum=0;
			for (int i=0; i<strategies.length; i++) sum += strategies[i];
			if (sum<1) throw new Exception("zero sum ");
		}

		public void damage(int h, int lm) {
			if (lm==Jump) h = h*2;
			hp -= h;
		}
		public void tire(int t) {
			stam -= t;
			while (stam<0) {
				damage(1,0);
				stam += 4;
			}
		}
		
		public String displayStrat(int[] strat) {
			String s="";
			for (int i=0; i<=5; i++) s += String.format("%5d",strat[i]);
			return s;
		}
		
		public String showStrat() {
			String s="";
			for (int i=0; i<=5; i++) s += String.format("%s:%d ",aManoeuvre[i+1],strategies[i]);
			return s;
		}
		
		public String show() {
			return String.format("ST=%d QK=%d hp=%d stam=%d man=%s", getST(), getQK(), getHP(),getStam(), aManoeuvre[getMan()] );
		}
		
		public void choose() throws Exception {
			int s,ss;
			for (int c=1; c<=2; c++) {
				s=D(sum);
				ss=0;
				for (int i=0; i<strategies.length; i++) {
					ss+=strategies[i];
					if (ss>=s) {
						if ((c==1)&&(lastMan==Jump)&&(i<=3)) continue; // try not to favour defence after jump
						setMan(i+1); 
						return; 
					}
				}
			}
			throw new Exception("fell from choose loop");
		}

		public void strike(Plr him ) throws Exception {
			/* One sided - I strike him. Current thinking: 
			 * kick beats hi beats lo beats kick
			 * hi beats bk-lo
			 * lo beats bk-hi
			 * kick beats jump
			*/
			int m = him.getMan();
			boolean best=(getQK()>=him.getQK());
			if ((m<1)||(getMan()<1)) throw new Exception("zero manoeuvre");
			tire(1);
			switch(getMan()) {
			case StHi: 
				if ((m==BkLo)||((m==StHi)&&best)||(m==StLo)) him.damage(2+getST(),lastMan);
				tire(1);
				break;
			case StLo:
				if ((m==BkHi)||(m==Kick)||((m==StLo)&&best)) him.damage(2+getST(),lastMan);
				tire(1);
				break;
			case Kick:
				if ((m==Jump)||((m==Kick)&&best)||(m==StHi)) him.damage(3+getST(),lastMan);
				tire(2);
				break;
			}
		}
		
	}
	
	public static double fight(Plr p1, Plr p2, int times) throws Exception {
		int k,w1=0,w2=0;
		double d;
		if (times<12) System.out.println(p1.showStrat()+" vs "+p2.showStrat());
		w1=0;
		w2=0;
		for (int i=1; i<=times; i++) {
			if (times<12) System.out.println(String.format("======= %d ==========",i));
			p1.reset(10,20,0,0);
			p2.reset(10,20,0,0);
			k=0;
			while ((p1.getHP()>0)&&(p2.getHP()>0)) {
				p1.choose();
				p2.choose();
				p1.strike(p2);
				p2.strike(p1);
				if (times<12) System.out.println("p1:"+p1.show()+" p2:"+p2.show());
				k++; if (k>1000) throw new Exception("Infinite loop in fight?");
			}
			if (p1.getHP()>0) w1++;
			if (p2.getHP()>0) w2++;
		}
		d=(double)(w2*100)/(double)times;
		p2.setWin(d);
		d=(double)(w1*100)/(double)times;
		p1.setWin(d);
		return d;
	}

	public static int D(int v) throws Exception {
		return (int)(Math.random()*v)+1;
	}
	
	public static int rlo(int i) {
		//i=i/2;
		i -= 2;
		return (i<1?1:i);
	}
	
	public static int rhi(int i) {
		//i=i*140/100;
		i += 3;
		return (i<7?7:i);
	}
	
	public static int rinc(int i) {
		//i=(rhi(i)-rlo(i))/7+1;
		i=1;
		return (i<1?1:i);
	}
	
	public static String niceTime(long t) {
		return String.format("%02d:%02d:%02d.%03d",t/1000/60/60,(t/1000/60)%60,(t/1000)%60,t%1000);
	}

	public static String toDateTime( long dtms ) {
		return (String)( new java.text.SimpleDateFormat("d-MMM-yy HH:mm:ss.SSS").format(new java.util.Date( dtms )) );
	}
	
	public static void main(String[] args) throws Exception {
		long dtms;
		double top[],f1,m;
		int times=20000, tops=10, s;
		int[][] bSt;
		int[] tot = {0,0,0,0,0,0}, sl,rl,rh,ri;
		top=new double[tops];
		bSt=new int[tops][6];
		rl=new int[6];
		rh=new int[6];
		ri=new int[6];
		Plr p1,p2;
		dtms = System.currentTimeMillis();
		rnd x=new rnd();
		p1=x.new Plr();
		p2=x.new Plr();
		p1.setStrategy(10,20,30,30,30,70);
		p2.setStrategy(10,20,30,30,30,70);
		//f1=fight(p1,p2,10000);
		//System.out.println(String.format("run=%5.2f",f1));	System.exit(1);
		System.out.println(String.format("times=%d %s",times,toDateTime(dtms)));
		p2.setStrategy(2,14,36,17,55,72);
		bSt[0]=p2.getStrategy();
		for (int iter=1; iter<=10; iter++) {
			System.out.println(String.format("=============== loop %d %s ===========",iter,niceTime(System.currentTimeMillis()-dtms)));
			Arrays.fill(top,0);
			s=0;
			sl=p2.getStrategy();
			for (int j=0; j<6; j++) {
				rl[j]=rlo(sl[j]);
				rh[j]=rhi(sl[j]);
				ri[j]=rinc(sl[j]);
			}
			for (int n0=rl[0]; n0<=rh[0]; n0+=ri[0] ) 
				for (int n1=rl[1]; n1<=rh[1]; n1+=ri[1] ) 
					for (int n2=rl[2]; n2<=rh[2]; n2+=ri[2] ) 
						for (int n3=rl[3]; n3<=rh[3]; n3+=ri[3] ) 
							for (int n4=rl[4]; n4<=rh[4]; n4+=ri[4] ) 
								for (int n5=rl[5]; n5<=rh[5]; n5+=ri[5] ) {
									p1.setStrategy(n0,n1,n2,n3,n4,n5);
									f1=fight(p1,p2,times);
									if (f1>top[s]) {
										top[s]=f1;
										bSt[s]=p1.getStrategy();
										m=999;
										for (int j=0; j<tops; j++) if (top[j]<m) { m=top[j]; s=j; }
										//System.out.print(String.format("%s %5.2f s=%d ",p1.showStrat(),f1,s));
										//System.out.println(String.format("%4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f ",
											//	top[0],top[1],top[2],top[3],top[4],top[5],top[6],top[7],top[8],top[9]));
									}
								}
			//System.out.println("best strats");
			//for (int j=0; j<top; j++) System.out.println(String.format("%5.1f: %d %d %d %d %d %d", b[j], bSt[j][0], bSt[j][1], bSt[j][2], bSt[j][3], bSt[j][4], bSt[j][5]));
			for (int j=0; j<tops; j++) System.out.println(String.format("%5.1f: %s", top[j], p1.displayStrat(bSt[j])));
			s=D(tops)-1;
			Arrays.fill(tot,0);
			for (int j=0; j<tops; j++) for (int k=0; k<=5; k++) tot[k] += bSt[j][k];
			for (int k=0; k<=5; k++) tot[k] = tot[k]/tops + 3;
			p2.setStrategy(tot);
			System.out.println("Set P2: "+p2.showStrat());
		}
		System.out.println(niceTime(System.currentTimeMillis()-dtms));
	}

}
