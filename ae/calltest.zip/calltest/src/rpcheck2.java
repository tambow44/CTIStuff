import java.io.File;

import calltest.calltest;


public class rpcheck2 {
	public static void main(String[] args) throws Exception {
		String s, sTS1, sTS2="", sDN, sRP, sLogsDir="con";
		int e, iDelay, iPort1,iPort2=0;

		//CR = System.getProperty("line.separator");
		if (args.length<5) {
			System.out.println("RP Checker. Make a predictive call on a RP to test it.");
			System.out.println("parameters: PrimeTShost:port BackupTShost:port RP DN KVP delay [logdir]");
			System.out.println("If there is no Backup TS, put \"no\" as a place-filler.");
			System.out.println("KVP is what to attach to the call when the call is answered (so the strategy on RP");
			System.out.println("can identify this), then release delay ms after answered (wait 20 secs to answer).");
			System.out.println("KVP example: \"SPEECH_CALL_TYPE=TEST\"");
			System.out.println("\"no\" means no KVP, don't wait for answer, and release after delay");
			System.out.println("If you put an \"n\" on end of delay (like \"1000n\"), it won't even do a release.");
			System.out.println("If logdir specified, the output will be appended to file YYYYMMDD.log within. If not specified, to stdout.");
			System.exit(1);
		}
		if (!args[0].contains(":")) {
			System.out.println("Format TS as host:port. Like \"irdcagrt02:4070\".");
			System.exit(1);			
		}
		sTS1=args[0].split(":")[0];
		iPort1 = calltest.toInt(args[0].split(":")[1]);
		iPort2 = 0;
		// If the second param doesn't have a :, we assume it's a space-filler and there is no backup TS.
		if (args[1].contains(":")) {
			sTS2=args[1].split(":")[0];
			iPort2 = calltest.toInt(args[1].split(":")[1]);			
		}
		sRP = args[2];
		sDN = args[3];
		if (args.length>5) {
			sLogsDir = args[5];
			if (!new File(sLogsDir).isDirectory() && !sLogsDir.equalsIgnoreCase("con")) {
				System.out.println("Logs directory \""+sLogsDir+"\" doesn't exist.");
				System.exit(1);
			}
		}
		s = args[4];
		if (s.endsWith("n")) s = "-"+s.replace("n", "");
		iDelay = calltest.toInt(s);
		
		calltest x=new calltest();
		calltest.MyTServer ts = x.new MyTServer();
		e = ts.CheckHARP( sRP, sDN, sTS1, iPort1, sTS2, iPort2, iDelay, sLogsDir );			
		System.out.println( e );
		System.exit(e);

	}

}
