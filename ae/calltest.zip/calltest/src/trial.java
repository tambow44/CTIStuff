import Genesys.ComLib.Pack.Msg;
//import Genesys.ComLib.Pack.PackedMsgLib;
import Genesys.ComLib.TKV.TKVList;
import Genesys.ComLib.TKV.TKVPair;
import calltest.calltest;

public class trial {
	
	public static String sStr(String s1, String s2) {
		if (s1==null) return "";
		return s2+"="+s1+" ";
	}
	public static String sInt(int i, String s) {
		if (i==-1) return "";
		return String.format("%s=d% ",s,i);
	}

	public static void main(String[] args) throws Exception {
		long dtmsStart, t;
		int a;
		String s;
		//byte[] b;
		StringBuilder sAll;
		TKVList kv;
		TKVPair kvp;
		Msg m;
		
		if (args.length<2) {
			System.out.println("TS1:port1 TS2:port2");
			System.exit(1);
		}
		
		calltest x=new calltest();
		calltest.MyTServer ts = x.new MyTServer();
		
		
		dtmsStart = System.currentTimeMillis();
		sAll = new StringBuilder();

		ts.OpenHATS( args[0].split(":")[0], Integer.parseInt(args[0].split(":")[1]), args[1].split(":")[0], Integer.parseInt(args[1].split(":")[1]) );
				
		ts.CloseTS();
		
		for (int i=0; i < ts.dh.getSize(); i++) {
			t = ts.dh.getMs(i);
			s = ts.dh.getText(i);
			if (s.length()>1) sAll.append(s);
			sAll.append( String.format("%dms %s ", t-dtmsStart, ts.dh.getE(i).getEventName() ) );
			if (ts.dh.getE(i).TreatmentParameters!=null) sAll.append("TreatmentParams not null ");
			if (ts.dh.getE(i).Reasons!=null) sAll.append("Reasons not null ");
			if (ts.dh.getE(i).Extensions!=null) sAll.append("Extensions not null ");
			sAll.append(sInt(ts.dh.getE(i).NetworkCallID,"netcallid"));
			sAll.append(sInt(ts.dh.getE(i).NetworkNodeID,"nodeID"));
			sAll.append(sInt(ts.dh.getE(i).ServerRole,"role"));
			sAll.append(sStr(ts.dh.getE(i).ServerVersion,"version"));
			sAll.append(sStr(ts.dh.getE(i).HomeLocation,"homeloc"));
			sAll.append(sStr(ts.dh.getE(i).AccessNumber,"accessnum"));
			sAll.append(sInt(ts.dh.getE(i).InfoStatus,"infostatus"));
			sAll.append(sInt(ts.dh.getE(i).InfoType,"infotype"));
			sAll.append(sInt(ts.dh.getE(i).LocationInfo,"Locinfo"));
			//sAll.append(sInt(ts.dh.getE(i).regCode,"regCode"));
			//sAll.append(sInt(ts.dh.getE(i).ConnID_compatib,"routeType"));
			sAll.append(sInt(ts.dh.getE(i).XReferenceID ,"XReferenceID"));
			sAll.append(sInt(ts.dh.getE(i).XRouteType ,"XRouteType "));
			sAll.append(sInt(ts.dh.getE(i).NodeID,"nodeID"));
			//if (ts.dh.getE(i)..Reasons!=null) sAll.append("Reasons not null ");
			sAll.append("|");
			/*
			if (ts.dh.getE(i).Capabilities!=null) {
				a = ts.dh.getE(i).Capabilities.getValue().length;
				sAll.append(String.format("capabilities lne=%d :",a));
				for (int j=0; j<a; j++) sAll.append(String.format("%d ",ts.dh.getE(i).Capabilities.getValue()[j]));
				sAll.append("|");
			}
			*/
			/*
			if (ts.dh.getE(i).msg!=null) {
				a=ts.dh.getE(i).msg.RetrLen();
				sAll.append(String.format("msg len=%d ",a));
				b = ts.dh.getE(i).msg.RetrBuf();
				sAll.append(String.format("buflen=%d :",b.length));
				for (int j=0; j<a; j++) {
					if (b[j]!=0) sAll.append(String.format("%02X ",b[j]));
				}
				sAll.append("|");
			}
			*/
			if (ts.dh.getE(i).msg!=null) {
				sAll.append("packed msg: ");
				m=ts.dh.getE(i).msg.unpack();
				for (int j=0; j<500; j++) {
					try {
					a=m.getIntAttribValue(j);
					sAll.append(String.format("%d=%04x ",j,a));
					} catch ( Exception e ) { }
				}
				sAll.append("|");
			}
			sAll.append("getAttr: ");
			for (int j=0; j<3048; j++) {
				a = ts.dh.getE(i).getIntAttr(j);
				s = ts.dh.getE(i).getStringAttr(j);
				if ((a!=-1)||(s!=null)) sAll.append(String.format("%d=%d %s ",j,a,s));
			}
			sAll.append("|");
			
			kv = ts.dh.getE(i).UserData;
			if (kv!=null) {
				sAll.append("Userdata: ");
				sAll.append(String.format("kv len=%d ",kv.length()));
				kv.TKVListInitScanLoop();
				for (int j=0; j<10; j++) {
					kvp = kv.TKVListNextPair();
					if (kvp==null) break;
					sAll.append(String.format("%d %s = %s %d ; ", j, kvp.TKVListKey(), kvp.TKVListStringValue(), kvp.TKVListIntValue()));
				}
				sAll.append("|");
			}
			//sAll.append(ts.dh.getE(i).toString()+"|");
		}
		s = sAll.toString().replaceAll("\\|",System.getProperty("line.separator") );
		System.out.println(s);
		System.out.print("fin");
	}
}
