
/*	
 *		Copyright (c) 2012, Eemaan Limited.  All rights reserved.
 * 		Developed for Genesys SDK8.1-DEV course.
 * 
 */
//package com.eemaan.codesamples.psdk;

import java.awt.*;
import java.awt.event.*;

import java.net.*;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import net.miginfocom.swing.MigLayout;

// Common imports for Platform SDK
import com.genesyslab.platform.commons.collections.*;
import com.genesyslab.platform.commons.protocol.*;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.threading.*;

// Specific imports for Protocol
import com.genesyslab.platform.voice.protocol.*;
import com.genesyslab.platform.voice.protocol.tserver.*;
import com.genesyslab.platform.voice.protocol.tserver.events.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.agent.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.party.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.userdata.*;

// Common imports for Application Blocks
import com.genesyslab.platform.applicationblocks.commons.*;
import com.genesyslab.platform.applicationblocks.commons.broker.*;
import com.genesyslab.platform.applicationblocks.commons.protocols.*;


public class ContactSample extends JFrame implements ChannelListener{
	
    /*
     * Constants
     * These constants must be set according to your environment and client. 
     */
	// Unique configuration identifier used by Protocol Manager to 
	// identify a connection.  This string should be unique for each 
	// protocol used in your application.  It might be a good idea 
	// use the name of the server's application object from the 
	// configuration layer, which guarantees uniqueness as well as 
	// clearly identifying which server you are communicating with.
    private static final String CONTACT_SERVER_IDENTIFIER = "MM_Solaris_ContactServer";

    // URI to connect to UCS
    //private static final String CONTACT_SERVER_URI = "tcp://ctilabfw02:9030"; 
    private static String CONTACT_SERVER_URI = "tcp://ctiakfw02:4490";  // AC UCS 
    private static String CLIENT_NAME = "AgentDesktopForVoice";
       
	/*
	 * GUI Components
	 */
    private JTextArea textAreaLog; // Text Field to show all messages
    
    private JButton buttonConnect;
    private JButton buttonDisconnect;
    
    /*
     * Private Members - For Genesys AppBlocks used (Protocol Manager and Message Broker)
     */
    private ProtocolManagementServiceImpl protocolManagementService;
    private EventReceivingBrokerService eventReceivingBrokerService;

    /*
     * Event Handler for all events in the system. Any class that implements 'Action' interface
     * can server as a handler.    
     */
    class UcsEventsHandler implements Action<Message>{
    	public void handle(final Message message) {
    		logMessage("Incoming Message: " + message);
    	}
    }
    
    // Constructor
	public ContactSample(String title){
		super(title);
		
		initializeComponent();
		
		initializePSDKApplicationBlocks();
	}
	
	private void initializePSDKApplicationBlocks() {
        // Setup Application Blocks:

        // Create Protocol Manager Service object
        protocolManagementService = new ProtocolManagementServiceImpl();

        // Create and initialize connection configuration object for TServer.
        UcsConfiguration ucsConfiguration = new UcsConfiguration(CONTACT_SERVER_IDENTIFIER);

        // Set required values
        try {
			ucsConfiguration.setUri(new URI(CONTACT_SERVER_URI));
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
        ucsConfiguration.setClientName(CLIENT_NAME);

        // Register this connection configuration with Protocol Manager
        protocolManagementService.register(ucsConfiguration);

        protocolManagementService.addChannelListener((ChannelListener)this);
        
        // Create and Initialize Message Broker Application Block
        eventReceivingBrokerService = new EventReceivingBrokerService(
                 new SingleThreadInvoker("EventReceivingBrokerService-1"));
		eventReceivingBrokerService.register(
		    new UcsEventsHandler(),
		    new MessageFilter(protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER).getProtocolId())
		);
		
		protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER).setReceiver((MessageReceiverSupport) eventReceivingBrokerService);
	}
	
	private void finalizePSDKApplicationBlocks(){
        
		// Cleanup code
        // Close Connection if opened (check status of protocol object)	
		Protocol protocol = protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER);
        
		if (protocol.getState() == ChannelState.Opened) // Close only if the protocol state is opened
        {
            try {
				protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER).close();
			} catch (ProtocolException e) {
				e.printStackTrace();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }

        // Stop EventBroker - This should release internal message receiving thread
		// Failing to do this would cause the application to keep running
        eventReceivingBrokerService.releaseReceivers();
        
        // Unregister the protocol configuration object
        protocolManagementService.unregister(CONTACT_SERVER_IDENTIFIER);
	}
	
	private void initializeComponent(){

		textAreaLog = new JTextArea();
		textAreaLog.setLineWrap(true);
		textAreaLog.setFont(new Font("Courier New", Font.PLAIN, 11));
		textAreaLog.setAutoscrolls(true);
		
		JScrollPane scrollPane = new JScrollPane(textAreaLog, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		MigLayout layoutButtons = new MigLayout("", "[grow][121.00][104.00][60.00]", "[][][][][][][][][14.00][]");
		JPanel panelButtons = new JPanel(layoutButtons);
		panelButtons.setBackground(Color.LIGHT_GRAY);
			
		// Button Connect
		buttonConnect = new JButton("Connect");
		buttonConnect.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
					connect();
			}
		});
		panelButtons.add(buttonConnect, "cell 2 0,growx");
		
		// Button Disconnect
		buttonDisconnect = new JButton("Disconnect");
		buttonDisconnect.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
					disconnect();
			}
		});
		panelButtons.add(buttonDisconnect, "cell 3 0,growx");

		/*
		 * Attach Data
		 */
		
		// Base Layout
		getContentPane().add(panelButtons,BorderLayout.NORTH );
		getContentPane().add(scrollPane, BorderLayout.CENTER);

		setSize(590, 591);
		}
	
	private void connect(){

		// Open the connection - only when the connection is not already opened
        // Opening the connection can fail and raises an exception
        try {
        	logRequest("connect");
        	Protocol protocol = protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER);
        	
        	if(protocol.getState() == ChannelState.Closed)
        		protocol.beginOpen(); // attempt to open the channel asynchronously
        	
    	} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		}
	}
	
	private void disconnect(){
        try
        {
        	logRequest("disconnect");
        	// Get the protocol associated with this configuration
        	Protocol protocol = protocolManagementService.getProtocol(CONTACT_SERVER_IDENTIFIER); 

        	// Close if protocol not already closed
        	if (protocol.getState() == ChannelState.Opened){
	            // Close the connection asynchronously
	            protocol.beginClose();
	
	            // This method does not have a LinkDisconnected event called for it
	            //OnLinkDisconnected(null);
        	}
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}

	/*
	 * 	RequestAddDocument This request is intended to add a document to an Interaction. This request can be used in 2 modes:
	 *  Link creation mode: UCS only creates an Attachment record to associate an existing Interaction (defined by the InteractionId parameter) to an existing Document (defined by the DocumentId parameter).
	 *	Document creation mode: UCS creates an Attachment record and a Document record and associates them to an existing Interaction (defined by the InteractionId parameter). The Document record is created using the parameters MimeType, TheName, Description, TheSize, Content. UCS returns the DocumentId in response.
	 *	UCS automatically works in �Link creation mode� when a parameter �DocumentId� is present in the request.
	 */
	private void addDocument(){
		
	}
		 
	/*
	 * RequestFindOrCreatePhoneCall This request finds an existing PhoneCall object. If no matching record is found, then a new one is created. 
	 */
	private void findOrCreatePhoneCall(){
		
	}
	
	/*
	 * RequestGetAttributes This request is intended for obtaining the complete list of all Contact Attribute objects associated with this Contact. Contact Attribute objects must be declared in Configuration Server in the Contact Attribute enumerator (this configuration is Tenant specific). By default, the existing Contact Attributes are: AccountNumber, ContactId, CustomerSegment, EmailAddress, FirstName, LastName, PhoneNumber, PIN, and Title. 
	 */
	private void getAttributes(){
		
	}
		
	/*
	 * RequestGetDocument This request is used to return the binary content of a document. 
	 */
	private void getDocument(){
		
	}
	/*
	 * RequestGetInteractionContent This request is intended for delivering the binary content of the interaction. 
	 */
	private void getInteractionContent(){
		
	}
		
	/*
	 * RequestInsert This request is intended for contact creation. No specific limitations related to �required� attributes introduced here but they can be introduced at the client application level. 
	 */
	private void insert(){
		
	}
	
	/*
	 * 	RequestInsertInteraction This request is intended for creation of new interaction in UCS. 
	 */
	private void insertInteraction(){
		
	}
		
	/*
	 * RequestRemoveDocument This request is intended to remove a document. If the related Document is no more referenced by any Attachment (no more associated to any Interaction or StandardResponse), the Document record is also removed from database. 
	 */
	private void removeDocument(){
		
	}
	
	/*
	 * RequestUpdateDocument This request is intended to update a document. 
	 */
	private void updateDocument(){
		
	}
		
	/*
	 * RequestUpdateInteraction This request is intended for updating of interaction attributes and binary content. (non-Javadoc)
	 * @see java.awt.Window#dispose()
	 */
	private void updateInteraction(){
		
	}
	
	@Override
	public void dispose(){
		// close connections, stop threads and release resources
		finalizePSDKApplicationBlocks();
		
		super.dispose();
	}

	public void onChannelOpened(EventObject event) {
		logMessage(event.toString());
	}

	public void onChannelClosed(ChannelClosedEvent event) {
		logMessage(event.toString());
	}

	public void onChannelError(ChannelErrorEvent event) {
		logMessage(event.toString());
	}

	private void logMessage(final String message) {
		EventQueue.invokeLater(new Runnable(){
			public void run() {
				textAreaLog.setText(textAreaLog.getText().concat("Message Received: \n" + message + "\n************************************\n"));
			}	
		});
	}
	
	private void logRequest(final String toLog) {
		EventQueue.invokeLater(new Runnable(){
			public void run() {
				textAreaLog.setText(textAreaLog.getText().concat("Request: \n" + toLog + "\n************************************\n"));
			}	
		});
	}
	
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		
		EventQueue.invokeLater(new Runnable(){

			public void run() {
				final JFrame frame = new ContactSample("UCS");
				
				frame.addWindowListener(new WindowAdapter() {
					
					public void windowClosing(WindowEvent we){
						frame.dispose();
						System.exit(0);
					}
				});
				
				frame.setVisible(true);
			}
		});
	}	
}
