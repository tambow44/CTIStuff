import java.util.Collection;

import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgApplication;
import com.genesyslab.platform.applicationblocks.com.objects.CfgDN;
import com.genesyslab.platform.applicationblocks.com.objects.CfgServer;
import com.genesyslab.platform.applicationblocks.com.objects.CfgSwitch;
import com.genesyslab.platform.applicationblocks.com.queries.CfgDNQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgDNType;
import com.genesyslab.platform.configuration.protocol.types.CfgObjectState;


public class findrps {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    EventBrokerService broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	
	    return ConfServiceFactory.createConfService( protocol, broker);
    }

    public static String getTServers(  final IConfService service, String sSearch, String sDelim ) throws ConfigException, InterruptedException {
    	// Get the TS and TS-backup hosts & ports 
    	// from the first RP we find whose Annex contains the RPChecker section with option named sSearch that is true
    	String s="";
    	CfgDNType typeDN;
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	CfgApplication swa,swb;
    	CfgSwitch  sw;
    	CfgServer serv;
    	
        Collection<CfgDN> DNs = service.retrieveMultipleObjects(CfgDN.class, new CfgDNQuery());

        for (CfgDN DN : DNs) {
        	typeDN = DN.getType();
        	//if ((typeDN==CfgDNType.CFGRoutingPoint)||(typeDN==CfgDNType.CFGExtRoutingPoint)) {
           	if (DN.getState()==CfgObjectState.CFGEnabled) {
                annex = DN.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                s = sectionKvp.getStringKey().trim().toLowerCase();
	                if (s.equals("rpchecker")) {
		                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    if (recordKvp.getStringKey().equals(sSearch)) {
		                       s = recordKvp.getStringValue().trim().toLowerCase();
		                       if ( !(s.equals("false")||s.equals("off")||s.equals("0")||s.equals("no")) ) {
		                    	   sw = DN.getSwitch();
		                    	   swa = sw.getTServer();
		                    	   serv = swa.getServerInfo();
		                    	   s = "noha";
		                    	   swb = serv.getBackupServer();
		                    	   if (swb!=null) s = swb.getServerInfo().getHost().getName()+":"+swb.getServerInfo().getPort();
		                    	   return serv.getHost().getName()+":"+serv.getPort() + sDelim + s;
		                       }
		                    }
		                }
	                }
	            }
        	}
        	
        }
    	return "no"+sDelim+"no";
    }

    public static String getAllRPs(  final IConfService service, String sSearch, String sDelim ) throws ConfigException, InterruptedException {
    	
    	StringBuilder sAll = new StringBuilder();
    	String s="";
    	CfgDNType typeDN;
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	
        // Read configuration objects:
        Collection<CfgDN> DNs = service.retrieveMultipleObjects(CfgDN.class, new CfgDNQuery());
        for (CfgDN DN : DNs) {
        	typeDN = DN.getType();
        	//if ((typeDN==CfgDNType.CFGRoutingPoint)||(typeDN==CfgDNType.CFGExtRoutingPoint)) {
           	if (DN.getState()==CfgObjectState.CFGEnabled) {
                annex = DN.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                s = sectionKvp.getStringKey().trim().toLowerCase();
	                //sAll.append(DN.getNumber()+sDelim);
	                if (s.equals("rpchecker")) {
		                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    if (recordKvp.getStringKey().equals(sSearch)) {
		                       s = recordKvp.getStringValue().trim().toLowerCase();
		                       if (!(s.equals("false")||s.equals("off")||s.equals("0")||s.equals("no")) ) {  
		                    	   sAll.append( DN.getNumber() );
		                    	   sAll.append( sDelim );
		                       }
		                    }
		                }
	                }
	            }
        	}
        }
        return sAll.toString();
    }

    public static void main(String... args) throws Exception {
    	String sDelim = " ", s="";
    	int ec=0;
		if (args.length<4) {
			System.out.println("Params:");
			System.out.println("    RPValue cme-host:cme-port cme-user cme-password [delimiter [get-hosts]]");
			System.out.println();
			System.out.println("For all tenants, for every RP and external RP, look in each RP's Annex");
			System.out.println("for the Section \"RPChecker\".");
			System.out.println("In here, if you find an Option of the name <RPValue> that = true");
			System.out.println("(any value other than \"false\", \"0\", \"off\" or \"no\", ignore case),");
			System.out.println("then this RP will be returned in a delimiter-separated list.");
			System.out.println("The delimiter defaults to space (SP). Use CR if you want new-line.");
			System.out.println("If get-hosts exists (\"yes\"/\"on\"), then first two vals are TS and TS-backup.");
			System.exit(1);
		}
		
		String sRPValue = args[0];
		if (args.length>4) sDelim = args[4];
		if (sDelim.equalsIgnoreCase("cr")) sDelim = System.getProperty("line.separator");
		if (sDelim.equalsIgnoreCase("sp")) sDelim = " ";
		int iPort = toInt(args[1].split(":")[1]);
		try {
			IConfService service = initializeConfigService( "scum", args[1].split(":")[0], iPort, args[2], args[3] );
			s = getAllRPs( service, sRPValue, sDelim );
			if (args.length>5) s = getTServers( service, sRPValue, sDelim ) + sDelim + s;
	        System.out.println(s);
		} catch (RegistrationException e) {
			System.out.println("Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("Bad CME host or port: "+args[1]);
			ec=1;
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
	}
}
