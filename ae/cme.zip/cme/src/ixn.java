// Common imports for Platform SDK
import java.net.URI;
import java.net.URISyntaxException;
import java.util.EventObject;

import com.genesyslab.platform.applicationblocks.commons.Action;
import com.genesyslab.platform.applicationblocks.commons.broker.EventReceivingBrokerService;
import com.genesyslab.platform.applicationblocks.commons.broker.MessageFilter;
import com.genesyslab.platform.applicationblocks.commons.protocols.InteractionServerConfiguration;
import com.genesyslab.platform.applicationblocks.commons.protocols.ProtocolManagementService;
import com.genesyslab.platform.applicationblocks.commons.protocols.ProtocolManagementServiceImpl;
import com.genesyslab.platform.commons.collections.*;
import com.genesyslab.platform.commons.protocol.*;
import com.genesyslab.platform.commons.threading.*;

import com.genesyslab.platform.openmedia.protocol.interactionserver.InteractionClient;
// Specific imports for Protocol
import com.genesyslab.platform.voice.protocol.*;
import com.genesyslab.platform.voice.protocol.tserver.*;
import com.genesyslab.platform.voice.protocol.tserver.events.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.agent.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.party.*;
import com.genesyslab.platform.voice.protocol.tserver.requests.userdata.*;



public  class ixn implements ChannelListener {

	private static String IXN_ID = "ixn";
    private ProtocolManagementServiceImpl mPMService;
    private InteractionServerConfiguration ixnConfig;
    private EventReceivingBrokerService eventReceivingBrokerService;
	
	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("-?\\d+") ? Integer.parseInt(s) : 0 );
	}

    class InteractionServerEventsHandler implements Action<Message>{
    	public void handle(final Message message) {
    		out( "E:"+message.toString() );		
    	}    	
    }

	
	public static int intserver(String s1, String s2, int p) {
		Endpoint ep = new Endpoint( s1, s2, p );
	//InteractionServerProtocol interactionServerProtocol = new InteractionServerProtocol( ep );
	return 4;
	}
	
	public void initIXN( String sServer, int iPort, String sApp ) {
		ixnConfig = new InteractionServerConfiguration(IXN_ID);
		ixnConfig.setClientName(sApp);
		ixnConfig.setClientType(InteractionClient.AgentApplication);
		out("init "+sServer+":"+iPort+" "+sApp);
		URI uri=null;
		try {
			uri = new URI("tcp://"+sServer+":"+iPort);
			ixnConfig.setUri(uri);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		mPMService = new ProtocolManagementServiceImpl();
		mPMService.register(ixnConfig);
		mPMService.addChannelListener((ChannelListener)this);

		eventReceivingBrokerService = new EventReceivingBrokerService(
                new SingleThreadInvoker("EventReceivingBrokerService-1"));
		eventReceivingBrokerService.register(
		    new InteractionServerEventsHandler(),
		    new MessageFilter(mPMService.getProtocol(IXN_ID).getProtocolId())
		);
		
		mPMService.getProtocol(IXN_ID).setReceiver(eventReceivingBrokerService);
	}

	private void finalIXN(){
        out("final");
		// Cleanup code
        // Close Connection if opened
		Protocol protocol = mPMService.getProtocol(IXN_ID);
        if ((protocol != null) && (protocol.getState() == ChannelState.Opened))
        {
            try {
				protocol.close();
			} catch (ProtocolException e) {
				e.printStackTrace();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }

        // Stop EventBroker
        eventReceivingBrokerService.releaseReceivers();
        
        // unregister the protocol configuration object
        mPMService.unregister(IXN_ID);
	}
	
	private void connect(){
		out("connect");
		// Open the connection
        // Opening the connection can fail and raise an exception
        try {
    		mPMService.getProtocol(IXN_ID).beginOpen();
    	} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		}
	}
	
	private void disconnect(){
		out("disconnect");
        try
        {
            // Close the connection
            mPMService.getProtocol(IXN_ID).beginClose();
	    }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
	
	private void out(String s) {
		System.out.println(s);
	}

	public void onChannelClosed(ChannelClosedEvent e) {
		out(e.toString());
	}

	public void onChannelError(ChannelErrorEvent e) {
		out(e.toString());
	}

	public void onChannelOpened(EventObject e) {
		out(e.toString());
	}

	public static void main(String[] args) {
    	String s="", sValue="";
    	int iPort=0, ec=0;
    	
		if (args.length<2) {
			System.out.println("Params:");
			System.out.println("  eventually cme-host:cme-port cme-user cme-password ix-app");
			System.out.println("Temp params:");
			System.out.println("    ixn-server:port ixn-str");
			System.out.println();
			System.exit(1);
		}
		
		iPort = toInt(args[0].split(":")[1]);

		try {
	        //System.out.println("go");
			//IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
	        //ConfServiceFactory.releaseConfService(service);
	        //broker.dispose();
	        // should have a protocol.close() too!
			ixn x = new ixn();
			x.initIXN( args[0].split(":")[0], iPort, args[1] );
			x.connect();
			Thread.sleep(20000);
			x.disconnect();
			x.finalIXN();
			Thread.sleep(1000);
	        
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);

		
	}

}
