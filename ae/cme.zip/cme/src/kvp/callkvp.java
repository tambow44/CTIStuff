package kvp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTransaction;
import com.genesyslab.platform.applicationblocks.com.queries.CfgTransactionQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgTransactionType;

public class callkvp {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    EventBrokerService broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	
	    return ConfServiceFactory.createConfService( protocol, broker);
    }

    public static String CFF(final IConfService service, String sCallTypeList, String sCallCheckOption, String sValue,
    									String sMapping, String sCFF,
    									String sDelim ) throws ConfigException, InterruptedException, ExecutionException {
    	/*
    	 * Go through sCallTypeList List-object and find every Section that has an Object called sCallCheck whose value is sValue
    	 * then use this section to look through the objects in list sMappingList section sMappingSection
    	 * and return all the options whose values match the CallList Section
    	 * e.g.
    	 * Find in list "Calltype" [Bus_Bus] "CallCheck" = "2", gives us "Bus_Bus"
    	 * Now look in "Mapping" [CFF] and return find "Bus_Bus" as an option value, return the option DN "49033211"
    	 */
    	StringBuilder sb = new StringBuilder();
    	HashMap<String, String> map = new HashMap<String, String>();
    	ArrayList<String> al = new ArrayList<String>();
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp;
    	KeyValuePair recordKvp;
    	String s="";
    	
    	CfgTransactionQuery transQ = new CfgTransactionQuery();
    	transQ.setObjectType(CfgTransactionType.CFGTRTList);
    	transQ.setTenantDbid(103);  // 103 is CCS
        Collection<CfgTransaction> colCall = service.retrieveMultipleObjects(CfgTransaction.class, transQ);

        for (CfgTransaction trn : colCall) {
        	if (trn.getName().equalsIgnoreCase(sCallTypeList.trim())) {
                annex = trn.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    if (recordKvp.getStringKey().equalsIgnoreCase(sCallCheckOption))
		                    	if (recordKvp.getStringValue().equalsIgnoreCase(sValue)) al.add(sectionKvp.getStringKey());
                    }
	            }
        	}
        	if (trn.getName().equalsIgnoreCase(sMapping.trim())) {
                annex = trn.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                if (sectionKvp.getStringKey().equalsIgnoreCase(sCFF.trim()))
	                	for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    if (!recordKvp.getStringKey().startsWith("10")) { // we don't want DNs that start with 10
		                    	/* Map keys are unique, so if we have one for this key already (indicated by map.put returning non-null),
		                    	   then append both values. */
		                    	s = map.put(recordKvp.getStringValue(), recordKvp.getStringKey());
		                    	if (s!=null) map.put(recordKvp.getStringValue(), recordKvp.getStringKey()+sDelim+s);
		                    }
	                	}
	            }
        		
        	}
        }
        for (int i=0; i<al.size(); i++ ){
        	sb.append(map.get(al.get(i)));
        	sb.append(sDelim);
        }
    	return sb.toString();
    }
    
    public static void main(String... args) throws Exception {
    	String s="",sDelim=" ";
    	int ec=0;
		if (args.length<8) {
			System.out.println("Params: CMEhost:port user pass Calltype callCheck 2 Mapping CFF [ delim ]");
			System.exit(1);
		}
		
		if (args.length>8) sDelim = args[8];
		if (sDelim.equalsIgnoreCase("cr")) sDelim = System.getProperty("line.separator");
		if (sDelim.equalsIgnoreCase("sp")) sDelim = " ";
		
		int iPort = toInt(args[0].split(":")[1]);
		try {
			IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
			s = CFF( service, args[3], args[4], args[5], args[6], args[7], sDelim );
			ConfServiceFactory.releaseConfService(service);
	        System.out.println(s);
		} catch (RegistrationException e) {
			System.out.println("Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("Bad CME host or port: "+args[1]);
			ec=1;
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
	}
}
