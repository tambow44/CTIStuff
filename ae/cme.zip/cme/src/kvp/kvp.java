package kvp;

import java.util.Collection;
import java.util.concurrent.ExecutionException;

import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTransaction;
import com.genesyslab.platform.applicationblocks.com.queries.CfgTransactionQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgTransactionType;

public class kvp {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    EventBrokerService broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	
	    return ConfServiceFactory.createConfService( protocol, broker);
    }

    public static String CFFWrite(final IConfService service, String sMappingList, String sMappingSection, 
    									String sCallList, String sCallCheck, String sValue, 
    									String sDir ) throws ConfigException, InterruptedException, ExecutionException {
    	/*
    	 * Go through sCallList List-object and find every Section that has an Object called sCallCheck whose value is sValue
    	 * then use this section to look through the objects in list sMappingList section sMappingSection
    	 * and return all the options whose values match the CallList Section
    	 */
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp;
    	
    	CfgTransactionQuery transQ = new CfgTransactionQuery();
    	transQ.setObjectType(CfgTransactionType.CFGTRTList);
    	transQ.setTenantDbid(103);  // 103 is CCS
        Collection<CfgTransaction> colCall = service.retrieveMultipleObjects(CfgTransaction.class, transQ);

        for (CfgTransaction trn : colCall) if (trn.getName().equalsIgnoreCase(sCallList.trim())) {
                annex = trn.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                if (sectionKvp.getStringKey().equalsIgnoreCase(sMappingSection.trim()))
	                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    KeyValuePair recordKvp = (KeyValuePair) recordObj;
		                    if (recordKvp.getStringKey().equalsIgnoreCase(sValue)) return recordKvp.getStringValue();
                    }
	            }      	
        }    	
    	return "";
    }
    
    public static String getKVP1(  final IConfService service, String sList, String sSection, String sOption ) throws ConfigException, InterruptedException, ExecutionException {
    	// Search in ListObject sList, in sSection for sOption, and return its value
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	
    	CfgTransactionQuery transQ = new CfgTransactionQuery();
    	transQ.setObjectType(CfgTransactionType.CFGTRTList);
    	transQ.setTenantDbid(103);  // 103 is CCS
        Collection<CfgTransaction> Trans = service.retrieveMultipleObjects(CfgTransaction.class, transQ);

        for (CfgTransaction Tran : Trans) if (Tran.getName().equalsIgnoreCase(sList.trim())) {
                annex = Tran.getUserProperties();
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                if (sectionKvp.getStringKey().equalsIgnoreCase(sSection.trim()))
	                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    if (recordKvp.getStringKey().equalsIgnoreCase(sOption)) return recordKvp.getStringValue();
                    }
	            }      	
        }
    	return "";
    }

    public static String getKVPs(  final IConfService service, String sListName ) throws ConfigException, InterruptedException {
    	// Convert an entire 
    	StringBuilder sb = new StringBuilder();
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	
    	CfgTransactionQuery transQ = new CfgTransactionQuery();
    	transQ.setObjectType(CfgTransactionType.CFGTRTList);
    	transQ.setTenantDbid(103);  // 103 is CCS
        Collection<CfgTransaction> Trans = service.retrieveMultipleObjects(CfgTransaction.class, transQ);

        for (CfgTransaction Tran : Trans) {
                annex = Tran.getUserProperties();
                if (Tran.getName().equalsIgnoreCase(sListName.trim()))
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	            	sb.append(sectionKvp.getStringKey()+"=====\n");
	                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    sb.append(recordKvp.getStringKey());
		                    sb.append("=");
		                    sb.append(recordKvp.getStringValue());
		                    sb.append("\n");
                    }
	            }      	
        }
    	return sb.toString();
    }

    public static String getAllKVPs(  final IConfService service ) throws ConfigException, InterruptedException {
    	// Get the TS and TS-backup hosts & ports 
    	// from the first RP we find whose Annex contains the RPChecker section with option named sSearch that is true
    	StringBuilder sb = new StringBuilder();
    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	
    	CfgTransactionQuery transQ = new CfgTransactionQuery();
    	transQ.setObjectType(CfgTransactionType.CFGTRTList);
    	transQ.setTenantDbid(103);  // 103 is CCS
        Collection<CfgTransaction> Trans = service.retrieveMultipleObjects(CfgTransaction.class, transQ);

        for (CfgTransaction Tran : Trans) {
                annex = Tran.getUserProperties();
                //s += Tran.getTenant().getName()+": "+Tran.getName()+"====================\n";
                //if (Tran.getName().equalsIgnoreCase("mapping"))
	            for (Object sectionObj : annex) {
	                sectionKvp = (KeyValuePair) sectionObj;
	                sb.append("----"+sectionKvp.getStringKey()+"----\n"); //.trim().toLowerCase();
	                for (Object recordObj : sectionKvp.getTKVValue()) {
		                    recordKvp = (KeyValuePair) recordObj;
		                    sb.append("    "+recordKvp.getStringKey()+"="+recordKvp.getStringValue()+"\n"); //.trim().toLowerCase();
                    }
	            }      	
        }
    	return sb.toString();
    }

    public static void main(String... args) throws Exception {
    	String s="";
    	int ec=0;
		if (args.length<6) {
			System.out.println("Params: CMEhost:port user pass listobject section option");
			System.exit(1);
		}
		
		/*
		if (sDelim.equalsIgnoreCase("cr")) sDelim = System.getProperty("line.separator");
		if (sDelim.equalsIgnoreCase("sp")) sDelim = " ";
		*/
		int iPort = toInt(args[0].split(":")[1]);
		try {
			IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
			//s = getKVPs( service, "mapping" ); "CFF", "48943996"
			s = getKVP1( service, args[3], args[4], args[5] );
			ConfServiceFactory.releaseConfService(service);
	        System.out.println(s);
		} catch (RegistrationException e) {
			System.out.println("Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("Bad CME host or port: "+args[1]);
			ec=1;
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
	}
}
