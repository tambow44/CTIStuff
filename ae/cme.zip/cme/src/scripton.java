import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgScript;
import com.genesyslab.platform.applicationblocks.com.queries.CfgScriptQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgObjectState;
import com.genesyslab.platform.configuration.protocol.types.CfgScriptType;


public class scripton {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    EventBrokerService broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	
	    return ConfServiceFactory.createConfService( protocol, broker);
    }

    public static String enableScript(  final IConfService service, String sScript ) throws Exception {
    	
    	CfgScript sw;

    	CfgScriptQuery SQ = new CfgScriptQuery(service);
    	SQ.setName(sScript);
    	sw = SQ.executeSingleResult();
    	if (sw==null) return "Script "+sScript+" not found";
    	if (sw.getType()!=CfgScriptType.CFGAlarmReaction) return "Script "+sScript+" not Alarm Reaction script";
    	if (sw.getState()==CfgObjectState.CFGEnabled) return "Script "+sScript+" already enabled";
    	sw.setState(CfgObjectState.CFGEnabled);
       	sw.save();
        return "Script now enabled";
    }
    

    public static void main(String... args) throws Exception {
    	int ec=0;
    	String s="";
		if (args.length<4) {
			System.out.println("Params:");
			System.out.println("   cme-host:cme-port cme-user cme-password script");
			System.out.println();
			System.out.println("Enable script (in Configuration/Environment/Scripts).");
			System.exit(1);
		}
		
		int iPort = toInt(args[0].split(":")[1]);
		try {
	        //System.out.println("go");
			IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
			s = enableScript( service, args[3] );
	        System.out.println(s);
		} catch (RegistrationException e) {
			System.out.println("Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("Bad CME host or port: "+args[1]);
			ec=1;
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
		
	}

}

