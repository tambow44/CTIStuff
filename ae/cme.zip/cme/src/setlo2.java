

import com.genesyslab.platform.applicationblocks.com.ConfEvent;
import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTenant;
import com.genesyslab.platform.applicationblocks.com.objects.CfgTransaction;
import com.genesyslab.platform.applicationblocks.com.queries.CfgTenantQuery;
import com.genesyslab.platform.applicationblocks.com.queries.CfgTransactionQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.applicationblocks.commons.broker.Subscriber;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgObjectState;
import com.genesyslab.platform.configuration.protocol.types.CfgTransactionType;


public class setlo2 {
	public final static String DELETE_CODE="-DELETE-";
	
	public static EventBrokerService broker=null;

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("-?\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	    IConfService ics = ConfServiceFactory.createConfService( protocol, broker);
	    //broker.dispose();
	    return ics;
    }

    public static String setListValue(  final IConfService service, String sTenant, String sList, 
    		String sSection, String sOption, String sValue ) throws Exception {

    	KeyValueCollection annex;
    	KeyValuePair sectionKvp,recordKvp;
    	String s;
    	boolean bAdd;
    	
    	CfgTenantQuery tq = new CfgTenantQuery(service);
    	tq.setName(sTenant);
    	CfgTenant ten = tq.executeSingleResult();
    	if (ten==null) return "ERROR: Tenant "+sTenant+" not found";
    	
    	CfgTransactionQuery trq = new CfgTransactionQuery(service);
    	trq.setName(sList);
    	trq.setObjectType(CfgTransactionType.CFGTRTList);
    	trq.setTenantDbid(ten.getDBID());
    	CfgTransaction transaction = trq.executeSingleResult();
    	if (transaction==null) return "ERROR: List "+sList+" not found";
    	if (transaction.getState() != CfgObjectState.CFGEnabled) return "ERROR: List "+sList+" not enabled"; 
    	
    	bAdd = sOption.startsWith("+"); // special case with + allows to create new option
    	if (bAdd) sOption = sOption.substring(1);
    	if (sValue.equals( DELETE_CODE )) bAdd=false;
    	
        annex = transaction.getUserProperties();
        for (Object sectionObj : annex) {
            sectionKvp = (KeyValuePair) sectionObj;
            s = sectionKvp.getStringKey().trim();
            if (s.equalsIgnoreCase(sSection)) {
                for (Object recordObj : sectionKvp.getTKVValue()) {
                    recordKvp = (KeyValuePair) recordObj;
                    if (recordKvp.getStringKey().equalsIgnoreCase(sOption)) {
                    	s = recordKvp.getStringValue().trim();
                    	if (sValue.isEmpty()) return s;
                    	if (sValue.equals( DELETE_CODE )) {
                    		sectionKvp.getTKVValue().remove(sOption);
                    		// no remove in recordKvp
                    	} else {
                    		recordKvp.setStringValue(sValue);
                    	}
                    	transaction.setUserProperties(annex);
                    	transaction.save();
                    	return sTenant+":"+sList+" "+sSection+"/"+sOption+" \""+s+"\"->\""+sValue+"\"";
                    }
                }
                if (!bAdd) return "ERROR: Option "+sOption+" not found";
                sectionKvp.getTKVValue().addString(sOption, sValue);
            	transaction.setUserProperties(annex);
            	transaction.save();
            	return sTenant+":"+sList+" "+sSection+" new "+sOption+" ->\""+sValue+"\"";
            }
        }   	
        return "ERROR: Section "+sSection+" not found";
    }
    

    public static void main(String... args) throws Exception {
    	int ec=0;
    	String s="", sValue="";
		if (args.length<7) {
			System.out.println("Params:");
			System.out.println("   cme-host:cme-port cme-user cme-password tenant list section option [value]");
			System.out.println("The tenant, list and section must all exist.");
			System.out.println("The option must exist, unless it begins with a +. Then it will be created");
			System.out.println("If value doesn't exist, display the current value.");
			System.out.println("If value is "+DELETE_CODE+" delete the option.");
			System.out.println();
			System.exit(1);
		}
		if (args.length>7) sValue = args[7];
		int iPort = toInt(args[0].split(":")[1]);
		try {
	        //System.out.println("go");
			IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
			s = setListValue( service, args[3], args[4], args[5], args[6], sValue );
	        System.out.println(s);
	        if (s.startsWith("ERROR")) ec=1;
	        ConfServiceFactory.releaseConfService(service);
	        broker.dispose();
	        // should have a protocol.close() too!
	        
		} catch (RegistrationException e) {
			System.out.println("ERROR: Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("ERROR: Bad CME host or port: "+args[1]);
			ec=1;
			
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
		
	}

}

