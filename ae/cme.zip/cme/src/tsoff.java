import java.util.Collection;

import com.genesyslab.platform.applicationblocks.com.ConfServiceFactory;
import com.genesyslab.platform.applicationblocks.com.ConfigException;
import com.genesyslab.platform.applicationblocks.com.IConfService;
import com.genesyslab.platform.applicationblocks.com.objects.CfgAgentLogin;
import com.genesyslab.platform.applicationblocks.com.objects.CfgApplication;
import com.genesyslab.platform.applicationblocks.com.objects.CfgDN;
import com.genesyslab.platform.applicationblocks.com.objects.CfgServer;
import com.genesyslab.platform.applicationblocks.com.objects.CfgSwitch;
import com.genesyslab.platform.applicationblocks.com.queries.CfgAgentLoginQuery;
import com.genesyslab.platform.applicationblocks.com.queries.CfgDNQuery;
import com.genesyslab.platform.applicationblocks.com.queries.CfgSwitchQuery;
import com.genesyslab.platform.applicationblocks.commons.broker.BrokerServiceFactory;
import com.genesyslab.platform.applicationblocks.commons.broker.EventBrokerService;
import com.genesyslab.platform.commons.protocol.Endpoint;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.protocol.RegistrationException;
import com.genesyslab.platform.configuration.protocol.ConfServerProtocol;
import com.genesyslab.platform.configuration.protocol.types.CfgAppType;
import com.genesyslab.platform.configuration.protocol.types.CfgDNType;
import com.genesyslab.platform.configuration.protocol.types.CfgObjectState;

import calltest.*;

public class tsoff {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}

    public static IConfService initializeConfigService(
            final String cfgsrvEndpointName,
            final String cfgsrvHost,
            final int    cfgsrvPort,
            final String username,
            final String password)
        throws ConfigException, InterruptedException, ProtocolException, RegistrationException {

	    CfgAppType  clientType         = CfgAppType.CFGSCE;
	    String      clientName         = "default";
	
	    Endpoint cfgServerEndpoint =
	            new Endpoint(cfgsrvEndpointName, cfgsrvHost, cfgsrvPort);
	
	    ConfServerProtocol protocol = new ConfServerProtocol(cfgServerEndpoint);
	    protocol.setClientName(clientName);
	    protocol.setClientApplicationType(clientType.ordinal());
	    protocol.setUserName(username);
	    protocol.setUserPassword(password);
	    protocol.open();
	
	    EventBrokerService broker =
	        BrokerServiceFactory.CreateEventBroker(protocol);
	
	    return ConfServiceFactory.createConfService( protocol, broker);
    }


    public static String getAllAgentLogins(  final IConfService service, String sSwitch, String sDelim ) throws ConfigException, InterruptedException {
    	
    	StringBuilder sAll = new StringBuilder();
    	int iSwitchID=0;
    	CfgSwitch sw;
    	CfgApplication ts;
    	CfgServer serv;
    	
    	// Set up a query to get all enabled agent-logins from sSwitch
    	CfgSwitchQuery SQ = new CfgSwitchQuery(service);
    	SQ.setName(sSwitch);
    	sw = SQ.executeSingleResult();
        iSwitchID = sw.getObjectDbid();
    	ts = sw.getTServer();
 	    serv = ts.getServerInfo();
 	    sAll.append(serv.getHost().getName()+":"+serv.getPort()+" ");
    	CfgAgentLoginQuery ALQuery = new CfgAgentLoginQuery();
    	ALQuery.setSwitchDbid(iSwitchID);
    	//ALQuery.
    	ALQuery.setState(CfgObjectState.CFGEnabled);
        Collection<CfgAgentLogin> ALs = service.retrieveMultipleObjects(CfgAgentLogin.class, ALQuery );

        for (CfgAgentLogin AL : ALs) {
        	sAll.append( AL.getLoginCode() );
        	sAll.append( sDelim );
        }
        return sAll.toString();
    }

    public static String getAllACDDNs(  final IConfService service, String sSwitch, String sSearch, String sDelim ) throws Exception {
    	
    	StringBuilder sAll = new StringBuilder();
    	int iSwitchID=0;
    	CfgSwitch sw;
    	CfgApplication ts;
    	CfgServer serv;
    	String sDN;    	

    	// Set up a query to get all enabled, ACD DNs from sSwitch
    	CfgSwitchQuery SQ = new CfgSwitchQuery(service);
    	SQ.setName(sSwitch);
    	sw = SQ.executeSingleResult();
        iSwitchID = sw.getObjectDbid();
    	ts = sw.getTServer();
 	    serv = ts.getServerInfo();
 	    
    	CfgDNQuery DNQuery = new CfgDNQuery();
    	DNQuery.setSwitchDbid(iSwitchID);
    	DNQuery.setState(CfgObjectState.CFGEnabled);
    	DNQuery.setDnType(CfgDNType.CFGACDPosition);
        Collection<CfgDN> DNs = service.retrieveMultipleObjects(CfgDN.class, DNQuery);

 	    sAll.append(serv.getHost().getName()+":"+serv.getPort());
        for (CfgDN DN : DNs) {
        	sDN = DN.getNumber();
        	if (sDN.startsWith(sSearch)) {
	        	sAll.append( "|" );
            	sAll.append( sDN );
        	}
        }
        return sAll.toString().replaceAll("\\|",sDelim );
    }
    
    public static String killAgents( String slDNs, boolean kill ) throws Exception {
    	/* Go through the comma list slDNs  and log out each agent on that DN 
    	 * the Tserver to use is the first element "host:port"
    	 * */
    	int i, e=0, iPort;
    	long dtmsStart = System.currentTimeMillis();
    	long t;
    	String sTServer, s;
    	StringBuilder sAll = new StringBuilder();

    	calltest x=new calltest();
		calltest.MyTServer mts = x.new MyTServer();
		
		String[] aDN = slDNs.split(",");
		sTServer = aDN[0].split(":")[0];
		iPort = toInt(aDN[0].split(":")[1]);
		//sAll.append(aDN[0]+" ");
		//sAll.append(sTServer+" "+String.valueOf(iPort));
		for (i=1; i<aDN.length; i++) {
			e = mts.logoutAgentFromSwitch( aDN[i], sTServer, iPort, kill);
		}
		i=e;
		
		for ( i=0; i < mts.dh.getSize(); i++) {
			t = mts.dh.getMs(i);
			s = mts.dh.getText(i);
			if (s.length()>1) sAll.append(s);
			//sAll.append( String.format("%s (%dms) %s(%d) ", calltest.toTime(t), t-dtmsStart, mts.dh.getE(i).getEventName(), mts.dh.getE(i).Event ) );
			//if (mts.dh.getE(i).AgentID!=null) sAll.append( "agentID="+mts.dh.getE(i).AgentID+" " );
			sAll.append("|");
		}
    	
    	return sAll.toString().replaceAll("\\|", System.getProperty("line.separator") );
    }

    public static void killAgentsNow( String slDNs, boolean kill ) throws Exception {
    	/* Go through the comma list slDNs  and log out each agent on that DN 
    	 * the Tserver to use is the first element "host:port"
    	 * */
    	int i, b=0, e=0, iPort;
    	long dtmsStart = System.currentTimeMillis();
    	long t;
    	String sTServer, s;
    	StringBuilder sAll = new StringBuilder();

    	calltest x=new calltest();
		calltest.MyTServer mts = x.new MyTServer();
		
		String[] aDN = slDNs.split(",");
		sTServer = aDN[0].split(":")[0];
		iPort = toInt(aDN[0].split(":")[1]);
		for (e=1; e<aDN.length; e++) {
			b = mts.dh.getSize();
			i = mts.logoutAgentFromSwitch( aDN[e], sTServer, iPort, kill);
			sAll.setLength(0);
			for ( i=b; i < mts.dh.getSize(); i++) {
				t = mts.dh.getMs(i);
				s = mts.dh.getText(i);
				if (s.length()>1) sAll.append(s);
				//sAll.append( String.format("%s (%dms) %s(%d) ", calltest.toTime(t), t-dtmsStart, mts.dh.getE(i).getEventName(), mts.dh.getE(i).Event ) );
				//if (mts.dh.getE(i).AgentID!=null) sAll.append( "agentID="+mts.dh.getE(i).AgentID+" " );
				sAll.append("|");
			}
			System.out.println(sAll.toString().replaceAll("\\|", System.getProperty("line.separator") ));
		}
    }

    public static void main(String... args) throws Exception {
    	String sDNPrefix, s="";
    	int ec=0;
    	boolean kill=false;
		if (args.length<5) {
			System.out.println("Params:");
			System.out.println("   cme-host:cme-port cme-user cme-password switch DNprefix [KILL]");
			System.out.println();
			System.out.println("For switch get all ACD DNs, and logout all agents logged in to them.");
			System.out.println("DNprefix specifies DNs that start with it. Put just 0 or 1 for all DNs.");
			System.out.println("If you don't put KILL, it will do a 'dry run' - display all the DNs but not log them out.");
			System.exit(1);
		}
		
		String sSwitch = args[3];
		sDNPrefix = args[4];
		if (sDNPrefix.equals("0")||sDNPrefix.equals("1")) sDNPrefix="";
		if (args.length>=6) if (args[5].equals("KILL")) kill=true; 
		int iPort = toInt(args[0].split(":")[1]);
		try {
	        //System.out.println("go");
			IConfService service = initializeConfigService( "scum", args[0].split(":")[0], iPort, args[1], args[2] );
			s = getAllACDDNs( service, sSwitch, sDNPrefix, "," );
	        System.out.println("Tserver host & port and DNs: "+s);
	        killAgentsNow(s, kill);
		} catch (RegistrationException e) {
			System.out.println("Bad CME username or password");
			ec=1;
		} catch (ProtocolException e) {
			System.out.println("Bad CME host or port: "+args[1]);
			ec=1;
		} catch (Exception e) {  
			System.out.println(e.toString()+" "+e.getMessage()+" "+e.getCause());
			ec=1;
		}
		System.exit(ec);
	}

}
