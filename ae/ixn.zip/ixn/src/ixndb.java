import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ixndb {

	public static int toInt( String s ) {
		// We don' need no steenking parseInt errors 
		if (s==null) return 0;
		return ( s.matches("\\d+") ? Integer.parseInt(s) : 0 );
	}
	  public static Connection getDBConn( String sOraConn ) throws SQLException, ClassNotFoundException {
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		    //return DriverManager.getConnection("jdbc:oracle:thin:@ctiwnrp01:1663:prd63", "MEADMP", "ueke3uw");
		    String[] aORA = sOraConn.split(","); // oraconnect,schema, pass
		    return DriverManager.getConnection( aORA[0],aORA[1],aORA[2] );
	 	}
	 
	public static int processIXNs( String sDB, int iOldest ) throws Exception {
		long lNow;
		long age=0;
		String sSQL = "SELECT assigned_to, " + // 1
				"MIN((assigned_at - TO_DATE('01-01-1970','DD-MM-YYYY'))*86400) as epoch " + // 2
				" FROM interactions WHERE media_type='email' AND state=3 " +
				" GROUP BY assigned_to " +
				" ORDER BY epoch ASC";
		String sAgent="";
		ResultSet rs = null;
		Connection conn = null;
		Statement stmt = null;
		conn = getDBConn(sDB);
		stmt = conn.createStatement();
		stmt.setQueryTimeout(120); // default of infinity
		//ts = new Timestamp(Calendar.getInstance().getTime().getTime());
		lNow = System.currentTimeMillis()/1000;	
		//System.out.println( lNow+" "+sSQL );
		rs = stmt.executeQuery( sSQL );
		while (rs.next()) { 
			sAgent = rs.getString(1);
			age = lNow - rs.getLong(2);
			if (age<=iOldest) if (sAgent!=null) System.out.println( sAgent+" "+age );
			//	if (age<1800) System.out.println(rs.getString(3)+": "+sAgent+" "+rs.getString(8)+
			//	" "+age+" "+rs.getString(4)+" "+rs.getString(5));
		}
		if (rs != null) rs.close();
		if (stmt != null) stmt.close();
		if (conn != null) conn.close();
		return 0;
	}

	public static void main(String[] args) throws Exception {
		if (args.length<1) {
			System.out.println("IXNDB - Interaction DB monitor");
			System.out.println("Params:");
			System.out.println("  IXN jdbc DB & user & passwd (e.g. \njdbc:oracle:thin:@ctiakfw02:1661:prd61,AKLC_IXN,AKLC_IXN");
			System.out.println("  oldest (don't print older than this many seconds)");
			System.exit(1);
		}
		if ( args[0].split(":").length!=6 || args[0].split(",").length!=3 ){
			System.out.println( args[0] );
			System.out.println("  IXN jdbc DB must be this format jdbc:oracle:thin:@ctiakfw02:1661:prd61,AKLC_IXN,AKLC_IXN");
			System.exit(1);			
		}
			
		int iOld = 3600;
		if (args.length>1) {
				iOld = toInt(args[1]);
		}
			
		int e = processIXNs( args[0], iOld );
		System.exit(e);
	}

}
