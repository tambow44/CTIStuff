import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EventObject;
import java.util.Iterator;

import com.genesyslab.platform.applicationblocks.commons.Action;
import com.genesyslab.platform.applicationblocks.commons.broker.EventReceivingBrokerService;
import com.genesyslab.platform.applicationblocks.commons.broker.MessageFilter;
import com.genesyslab.platform.applicationblocks.commons.protocols.ProtocolManagementServiceImpl;
import com.genesyslab.platform.applicationblocks.commons.protocols.TServerConfiguration;
import com.genesyslab.platform.commons.collections.KeyValueCollection;
import com.genesyslab.platform.commons.collections.KeyValuePair;
import com.genesyslab.platform.commons.protocol.ChannelClosedEvent;
import com.genesyslab.platform.commons.protocol.ChannelErrorEvent;
import com.genesyslab.platform.commons.protocol.ChannelListener;
import com.genesyslab.platform.commons.protocol.ChannelState;
import com.genesyslab.platform.commons.protocol.Message;
import com.genesyslab.platform.commons.protocol.Protocol;
import com.genesyslab.platform.commons.protocol.ProtocolException;
import com.genesyslab.platform.commons.threading.SingleThreadInvoker;
import com.genesyslab.platform.voice.protocol.ConnectionId;
import com.genesyslab.platform.voice.protocol.tserver.AddressType;
import com.genesyslab.platform.voice.protocol.tserver.ControlMode;
import com.genesyslab.platform.voice.protocol.tserver.RegisterMode;
import com.genesyslab.platform.voice.protocol.tserver.events.EventAttachedDataChanged;
import com.genesyslab.platform.voice.protocol.tserver.events.EventDialing;
import com.genesyslab.platform.voice.protocol.tserver.events.EventPrimaryChanged;
import com.genesyslab.platform.voice.protocol.tserver.events.EventRinging;
import com.genesyslab.platform.voice.protocol.tserver.events.EventRouteUsed;
import com.genesyslab.platform.voice.protocol.tserver.events.EventServerInfo;
import com.genesyslab.platform.voice.protocol.tserver.events.EventUserEvent;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.RequestRegisterAddress;
import com.genesyslab.platform.voice.protocol.tserver.requests.dn.RequestUnregisterAddress;
import com.genesyslab.platform.voice.protocol.tserver.requests.queries.RequestQueryServer;


public class mondns implements ChannelListener {

    private static String TS_ID="scab";
    private static boolean bEvent = false, bKill;
    private static String CR = System.getProperty("line.separator");
    private ProtocolManagementServiceImpl protocolManagementService;
    private EventReceivingBrokerService eventReceivingBrokerService;
    private static String sDirectory;


	class TServerEventsHandler implements Action<Message>{
    	public void handle(final Message message) {
    		
    		bEvent = true;
    		
    		switch(message.messageId()){
    		/*
	        case EventRinging.ID: {
	            	// Retrieve connection id for this call from the event. This connection id is
	            	// used for all requests pertaining to this call.
	                //EventRinging eventRinging = (EventRinging)message ;
	                //writeKVPs(eventRinging.getThisDN(), eventRinging.getConnID(), eventRinging.getUserData());
	        }
	        break;
	
	        case EventDialing.ID: {
	            	// Retrieve connection id for this call from the event. This connection id is
	            	// used for all requests pertaining to this call.
	            	//EventDialing eventDialing = (EventDialing)message;
	                //writeKVPs(eventDialing.getThisDN(), eventDialing.getConnID(), eventDialing.getUserData());
	        }
	        break;
	            
	        case EventAttachedDataChanged.ID: {
        		//EventAttachedDataChanged eventData = (EventAttachedDataChanged)message;
                //writeKVPs(eventData.getThisDN(), eventData.getConnID(), eventData.getUserData());
        	}
        	break;
	        case EventRouteUsed.ID: {
	        	log("eventRouteUsed");
        		//EventRouteUsed eventUsed = (EventRouteUsed)message;
        		
                //writeKVPs(eventUsed.getThisDN(), eventUsed.getConnID(), eventUsed.getUserData());
        	}
        	break;
        	
        	*/
    		case EventPrimaryChanged.ID: {
	        	log("eventPrimaryChanged:" + message);
    			//EventPrimaryChanged eventPrimaryChanged = (EventPrimaryChanged)message; 
    		}
    		
	        case EventUserEvent.ID: {
	        	log("eventUserEvent:" + message);
        		EventUserEvent eventUserEvent = (EventUserEvent)message;
        		
                writeKVPs(eventUserEvent.getThisDN(), eventUserEvent.getConnID(), eventUserEvent.getUserData(),eventUserEvent.getEventSequenceNumber());
	        	break;
	        }
	        
	        case EventServerInfo.ID: {
	        	EventServerInfo eventInfo = (EventServerInfo)message;
	        	log("Server Info Heart-beat: "+
	        			eventInfo.getApplicationName()+" "+
	        			eventInfo.getServerVersion()+" "+ 
	        			eventInfo.getServerStartTime()+" "+
	        			eventInfo.getTime() );
	        }
	        break;
        	
        	default: {
        		log("" + message);
        	}
	        	
    		}	
    	}
    }
	
	private static void writeKVPs( String sDN, ConnectionId connID, KeyValueCollection userData, Long lSeq ) {
        if (userData == null) return;
        String s;
        Writer writer = null;
        //String sTimeStampFile = sDirectory + "\\" + sDN + "." + nowSec() + ".kvp";
        String sTimeStampFile = sDirectory + "\\" + sDN + "." + String.valueOf(lSeq) + ".kvp";
        
        log("Write file: "+sTimeStampFile );
    	Iterator iter = userData.iterator();
        try {
            writer = new BufferedWriter(new OutputStreamWriter(
                  new FileOutputStream( sTimeStampFile, true ), "utf-8"));
            writer.write( "MyConnID="+connID+CR );
            writer.write( "MyDN="+sDN+CR );
            while(iter.hasNext()) {
                KeyValuePair item = (KeyValuePair)iter.next();
                //item.getValueType().
                s = item.getStringValue();
                if (s==null) s = String.valueOf(item.getIntValue());
                s = item.getStringKey() + "=" + s;
                writer.write( s+CR );
                //log (s);
            }
        } catch (IOException e) {
        	e.printStackTrace();
        } finally {
        	try {writer.close();} catch (Exception ex) {}
        }
    }
	
	private static String nowMS() {
		// Display the ms time in a readable state
        DateFormat SDFormat = new SimpleDateFormat("yyyyMMdd.HHmmss.SSS");
        long t = System.currentTimeMillis();
        return SDFormat.format(new Date(t));
	}
	
	private static String nowSec() {
		// Display the ms time in a readable state
		String s = nowMS();
		s = s.substring( 0, s.lastIndexOf(".") );
        return s;
	}
	
    private static void log( String s ) {
    	System.out.println(nowMS()+": "+s);    	
    }
	
	private void openTServer( String TS1, String TS2 ) {
		log("open Tserver:"+TS1+" & "+TS2);
        // Create Protocol Manager Service object
        protocolManagementService = new ProtocolManagementServiceImpl();

        // Create and initialize connection configuration object for TServer.
        TServerConfiguration tserverConfiguration = new TServerConfiguration(TS_ID);

        try {
			tserverConfiguration.setUri(new URI("TCP://"+TS1));
			if ( TS2.length()>2 ) {
				tserverConfiguration.setWarmStandbyUri(new URI("TCP://"+TS2));
				tserverConfiguration.setWarmStandbyTimeout(10000);
				tserverConfiguration.setWarmStandbyAttempts((short) 2);
			}
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
        tserverConfiguration.setClientName("AE");
        tserverConfiguration.setClientPassword("");

        // Register this connection configuration with Protocol Manager
        protocolManagementService.register(tserverConfiguration);

        protocolManagementService.addChannelListener((ChannelListener)this);
        
        // Create and Initialize Message Broker Application Block
        eventReceivingBrokerService = new EventReceivingBrokerService(
        	new SingleThreadInvoker("EventReceivingBrokerService-1"));
		eventReceivingBrokerService.register(
		    new TServerEventsHandler(),
		    new MessageFilter(protocolManagementService.getProtocol(TS_ID).getProtocolId())
		);
		
		protocolManagementService.getProtocol(TS_ID).setReceiver(eventReceivingBrokerService);
	}
	
	private void finalizePSDKApplicationBlocks(){
		// Cleanup code
        // Close Connection if opened (check status of protocol object)
		log("Finalize PSDK");
		Protocol protocol = protocolManagementService.getProtocol(TS_ID);
        
		if (protocol.getState() == ChannelState.Opened) // Close only if the protocol state is opened
        {
            try {
				protocolManagementService.getProtocol(TS_ID).close(); // synchronous
			} catch (ProtocolException e) {
				e.printStackTrace();
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }

        // Stop EventBroker - This should release internal message receiving thread
		// Failing to do this would cause the application to keep running
        eventReceivingBrokerService.releaseReceivers();
        
        // Unregister the protocol configuration object
        protocolManagementService.unregister(TS_ID);
	}
		
	private void connect(){
		log("connect");
		// Open the connection - only when the connection is not already opened
        // Opening the connection can fail and raises an exception
        try {
        	Protocol protocol = protocolManagementService.getProtocol(TS_ID);
        	
        	if(protocol.getState() == ChannelState.Closed)
        		protocol.open(); // synchronously
    			//protocol.beginOpen(); // asynchronously
        	
    	} catch (ProtocolException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void disconnect(){
		log("disconnect");
        try
        {
        	// Get the protocol associated with this configuration
        	Protocol protocol = protocolManagementService.getProtocol(TS_ID); 

        	// Close if protocol not already closed
        	if (protocol.getState() == ChannelState.Opened){
	            protocol.close();  // synchronously
	            //protocol.beginClose();  // asynchronously
	
	            // This method does not have a LinkDisconnected event called for it
	            //OnLinkDisconnected(null);
        	}
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
	
	private  void register( String sDN ){
		log("register:"+sDN);
        try
        {
            // Create the register address request object for TServer (Voice Platform SDK). 
            RequestRegisterAddress request =
                RequestRegisterAddress.create(
                sDN,										// DN to register
                RegisterMode.ModeShare,					// Share DN info with other apps?
                ControlMode.RegisterDefault,			// Register DN with switch?
                AddressType.DN);						// Type of DN

            // Request asynchronously?
            protocolManagementService.getProtocol(TS_ID).send(request);
        }
        catch (Exception e)
        {
        	e.printStackTrace();
        }
	}

	private void unregister(String sDN){
		log("unregister:"+sDN);
        try {
            // Create the register address request object for TServer. 
            RequestUnregisterAddress request =
                RequestUnregisterAddress.create(
                sDN, 									// DN to unregister
                ControlMode.RegisterDefault);			// Unregister DN with switch?

            // Request asynchronously
            protocolManagementService.getProtocol(TS_ID).send(request);
        } catch (Exception e){
        	e.printStackTrace();
    	}
	}
	
	private void queryServer() {
		log("query server");
        try {
            RequestQueryServer request = RequestQueryServer.create();
            protocolManagementService.getProtocol(TS_ID).send(request);  // asynch
		} catch (IllegalStateException e) {
			e.printStackTrace();
			bKill = true;
        } catch (Exception e){
        	e.printStackTrace();
    	}
	}
	
	private  void regDNfile ( String sFile, boolean bReg ) throws Exception {
		String sLine=null;
		BufferedReader inp=null;
		if (sFile.startsWith("@")) sFile=sFile.substring(1);
		inp = new BufferedReader( new FileReader(sFile)); 
		while ((sLine = inp.readLine()) != null) {
			sLine = sLine.trim();
			if (!".!#/".contains( String.valueOf( sLine.charAt(0) ) )) {
				if (bReg) { register(sLine); } else { unregister(sLine); }
			}
		}
		inp.close();
		
	}

	public mondns( String sTS1, String sTS2, String sDir, String sDelay, String[] DNs )throws Exception {
		super();
		int iFWDelay = 300; // wake up every 300 secs (5 mins) if nothing happens
		long lStop, lNow;
		int k,m1,h1,m2,h2,s2;
		
		bKill = false;
		if (sDir.endsWith("\\")) sDir = sDir.substring(0,sDir.length()-1);
		sDirectory = sDir;
		lNow = System.currentTimeMillis();
		if (sDelay.matches("\\d+:\\d+")) {
			// Calculate finish time. The difference between HH:mm now and HH:mm chosen
			h1 = Integer.parseInt(sDelay.split(":")[0]);
			m1 = Integer.parseInt(sDelay.split(":")[1]);
	        Date date = new Date();
	        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	        h2 = Integer.parseInt(sdf.format(date).split(":")[0]);
	        m2 = Integer.parseInt(sdf.format(date).split(":")[1]);
	        s2 = Integer.parseInt(sdf.format(date).split(":")[2]);
	        lStop = ((h1-h2)*60 + (m1-m2))*60 - s2;
	        if (lStop<=0) lStop = lStop + 86400;  // Add a day if the time is in the past
	        lStop = lStop*1000 + lNow;  // convert to ms plus Now
		} else {
			lStop = 10;  // 10 second catch-all for any delay format errors
			if (sDelay.matches("\\d+")) lStop = Long.parseLong(sDelay);
			lStop = lNow + lStop*1000;
		}
		log("Now="+lNow + "  Stop at "+lStop + " in "+( (lStop-lNow)/1000 )+" secs");
		openTServer(sTS1,sTS2);
		Thread.sleep( 250 );
		connect();
		Thread.sleep( 250 );
		if (DNs[4].startsWith("@")) {
			regDNfile(DNs[4], true);
		} else {
			for (int i=4; i<DNs.length; i++) {
				register(DNs[i]);
			}
		}

		queryServer();
		k=0;
		do {
			if (bEvent) k=0;
			bEvent=false;
			k++;
			if (k>iFWDelay) { k=0; queryServer(); }
			Thread.sleep(1000);
			//log(""+System.currentTimeMillis());
		} while ( System.currentTimeMillis() < lStop && !bKill );
		
		if (DNs[4].startsWith("@")) {
			regDNfile(DNs[4], false);
		} else {
			for (int i=4; i<DNs.length; i++) {
				unregister(DNs[i]);
			}
		}
		Thread.sleep( 250 );
		disconnect();
		Thread.sleep( 250 );
		finalizePSDKApplicationBlocks();
	}

	public static void main(String[] args) throws Exception {
		if (args.length<5) {
			System.out.println("MONDNS - Monitor DN 3.01");
			System.out.println("Monitor one or more DNs, catch attached-data KVPs and write to file.");
			System.out.println("Params:");
			System.out.println("   primary-Tserver:port secondary directory delay DN1 [ DN2 [ ... ]]");
			System.out.println("E.g.");
			System.out.println("java -jar mondns.jar ctiwnfw01:3024 no D:\\test 300 1145 1146");
			System.out.println("Notes:");
			System.out.println("1. If there is no secondary Tserver, use 'no' as a place-holder.");
			System.out.println("2. Directory to write the files from each SendUserEvent. Format: DN.unique.kvp");
			System.out.println("   file contains KVPs, one per line, like: abc=1234");
			System.out.println("   No = nor whitespace in KVP name, and additional = are treated as value");
			System.out.println("3. Delay is how long it waits before stopping (in seconds).");
			System.out.println("   If this has a single colon in it, treat as a time (can be next day). e.g. 16:30");
			System.out.println("4. If (only) DN1 has an @ (like @list.txt), treat as file of DNs, one per line.");
			System.out.println("5. Every 5 mins of quiet, it does a query-server to keep a firewall open.");
			System.exit(1);
		}
		
		if ( !args[0].contains(":") || ( !args[1].contains(":") && args[1].length()>2 ) ) {
			System.out.println("Tserver format is host:port, like cctiwnfw01:3024");
			System.exit(1);
		}
		final mondns m = new mondns( args[0], args[1], args[2], args[3], args );	
		System.out.println("end "+nowSec());
		System.exit(0);
	}

	@Override
	public void onChannelClosed(ChannelClosedEvent arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onChannelError(ChannelErrorEvent arg0) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onChannelOpened(EventObject arg0) {
		// TODO Auto-generated method stub
	}

}
