#!/bin/bash
# Unrotate the facile log4j logs
# Version 1
# ae sep-2014
#
# PARAM 1: log directory
# PARAM 2: prefix
#
#  unrotate4j-1 \opt\GCTI\logs\common\infomart gim_etl
#
# When log4j fills a log, it then renames the log file to log.1
# if log.1 exists, it is renamed to log.2, and so on, down to log.100
#
# This behaviour is FACILE. It can't be fixed without recompiling log4j and we don't have the java sources.
#
# So, this cmd file, unrotate4j, renames these facile log files to better filenames. 
# It uses "Nick's format" like gim_etl_20140829_1023.log
# And because the new file is now .log, Nick's tool can compress it
#
# Run it every day or so over the directory with these FACILE logs.
#
if [ -z "$2" ] ; then
  echo "Need parameters log-directory and prefix. For example:"
  echo $0 /opt/GCTI/logs/infomart gim_etl
  exit
fi

logdir=$1
prefix=$2
tmplog=$logdir/unrotate.tmp

c=101
while [ $c -gt 0 ]; do
  c=`expr $c - 1`
  oldlog=$logdir/$prefix.log.$c
  # rename the file to a tmp file just in case log4j does a rotate while we are working
  if [ -f "$oldlog" ] ; then
    mv $oldlog $tmplog
    # Get file mod date
    # ls -E gives the full datetime. The awk print bit gets the 6th and 7th parts (date and time)
    d=$(ls -E $tmplog|awk '{print $6 "_" $7}')
    # remove the : (from time) and - (from date), and the ${d%.*} bit chops out everything from . to end (time crap)
    d=${d//:/}; d=${d%.*}; d=${d//-/}
    # newlog is the name of the new log file (gim_etl.20140620_1234.log)
    newlog=$logdir/$prefix.${d}.log
    echo rename $oldlog to $newlog
    # read -rsp $'Press enter to continue...\n'
    mv $tmplog $newlog
    # There is a very small chance that in the time we are doing the rename, log4j does a rotate (and renames all the logs). 
    # So add 2 back to c so that it carries on and rechecks the last two files
    c=`expr $c + 2`
  fi
done

